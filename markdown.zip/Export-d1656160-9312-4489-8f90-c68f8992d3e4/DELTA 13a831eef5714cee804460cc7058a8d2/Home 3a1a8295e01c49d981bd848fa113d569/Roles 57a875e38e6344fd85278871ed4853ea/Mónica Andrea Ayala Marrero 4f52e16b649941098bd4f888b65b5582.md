# Mónica Andrea Ayala Marrero

Objetivo: ../Objetivos%20ca403ee2eb314396bf5c7b55aaaf9383/Alcanzar%20un%20nivel%202%20de%20madurez%20del%20CMMI%205a5e6ca4ccf344499893ba968179e4c2.md, ../Objetivos%20ca403ee2eb314396bf5c7b55aaaf9383/Alcanzar%20minimo%20nivel%20Jedi%20en%20las%20competencias%20del%20a2f082904e7c4ed4bfae6535125a8b88.md
Periodo: Primer periodo
Rol: Program Manager