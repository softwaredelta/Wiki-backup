# Ian Paulo García Gonzáles

Periodo: Primer periodo
Rol: Architecture Owner