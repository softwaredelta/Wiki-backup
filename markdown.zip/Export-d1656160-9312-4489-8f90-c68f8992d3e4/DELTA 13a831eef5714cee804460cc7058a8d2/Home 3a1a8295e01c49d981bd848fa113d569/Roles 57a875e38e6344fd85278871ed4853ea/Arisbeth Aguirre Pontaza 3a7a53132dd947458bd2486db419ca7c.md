# Arisbeth Aguirre Pontaza

Periodo: Primer periodo
Rol: Product Owner