# Rodrigo Muñoz Guerrero

Periodo: Primer periodo
Rol: Product Owner