# Jorge Guerrero Díaz

Periodo: Primer periodo
Rol: Team Leader