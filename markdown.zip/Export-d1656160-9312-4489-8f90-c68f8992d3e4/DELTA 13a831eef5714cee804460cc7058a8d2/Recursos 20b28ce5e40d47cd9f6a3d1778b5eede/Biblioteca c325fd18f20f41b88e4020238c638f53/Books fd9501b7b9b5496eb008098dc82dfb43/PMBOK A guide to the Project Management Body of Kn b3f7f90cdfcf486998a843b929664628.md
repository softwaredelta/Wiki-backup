# PMBOK: A guide to the Project Management Body of Knowledge

Files & media: Project_Management_Institute_-_A_Guide_to_the_Project_Management_Body_of_Knowledge-Project_Management_Institute_(2001).pdf
Idioma: English
Tags: Procesos, Project Management