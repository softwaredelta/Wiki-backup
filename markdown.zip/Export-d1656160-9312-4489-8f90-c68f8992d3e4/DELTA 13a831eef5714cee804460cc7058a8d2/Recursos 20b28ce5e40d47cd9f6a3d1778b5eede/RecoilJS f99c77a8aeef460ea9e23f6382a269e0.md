# RecoilJS

Created by: Kenny Eduard Vercaemer González
Last edited by: Fermín Méndez García
Tags: Technology, Todo
URL: https://recoiljs.org/docs/introduction/installation