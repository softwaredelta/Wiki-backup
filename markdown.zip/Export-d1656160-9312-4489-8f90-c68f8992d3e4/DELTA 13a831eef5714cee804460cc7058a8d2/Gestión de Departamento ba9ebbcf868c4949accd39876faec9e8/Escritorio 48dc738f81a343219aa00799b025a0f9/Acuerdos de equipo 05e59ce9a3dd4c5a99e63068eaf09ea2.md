# Acuerdos de equipo

<aside>
💡 Este documento detalla los acuerdos que el **Departamento de Desarrollo DELTA** tendrá a lo largo del semestre, cada miembro del departamento se compromete a los acuerdos aquí descritos. De igual forma se describe que pasará en caso de que se incumpla algún acuerdo. Estos acuerdos pueden ser modificados en un futuro si se encuentra que no es la manera de trabajo que funciona mejor para el Departamento.

</aside>

[Acuerdos](Acuerdos%20de%20equipo%2005e59ce9a3dd4c5a99e63068eaf09ea2/Acuerdos%20b9ff5a4cc6a64bd4be0bc0ac856a0818.md)