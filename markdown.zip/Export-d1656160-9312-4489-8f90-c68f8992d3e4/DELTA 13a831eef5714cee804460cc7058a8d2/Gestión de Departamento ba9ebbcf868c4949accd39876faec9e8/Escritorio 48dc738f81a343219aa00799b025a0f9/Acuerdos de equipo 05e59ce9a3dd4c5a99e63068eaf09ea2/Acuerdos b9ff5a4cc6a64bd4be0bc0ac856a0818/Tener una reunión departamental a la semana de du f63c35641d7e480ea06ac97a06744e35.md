# Tener una reunión departamental a la semana de duración de 1 a 2 horas.

Tags: Reunion, To do

## Objetivo

## Acuerdo

Tener una reunión departamental a la semana de duración de 1 a 2 horas.

## Monitoreo

[Seguimiento A01](Tener%20una%20reunio%CC%81n%20departamental%20a%20la%20semana%20de%20du%20f63c35641d7e480ea06ac97a06744e35/Seguimiento%20A01%201c2c286481584b96b3db4fbe7487553c.md)

## Matriz de cambios

[Cambios](Tener%20una%20reunio%CC%81n%20departamental%20a%20la%20semana%20de%20du%20f63c35641d7e480ea06ac97a06744e35/Cambios%20d62e7bc4c61f4b31afbd105e60b9a8a9.md)