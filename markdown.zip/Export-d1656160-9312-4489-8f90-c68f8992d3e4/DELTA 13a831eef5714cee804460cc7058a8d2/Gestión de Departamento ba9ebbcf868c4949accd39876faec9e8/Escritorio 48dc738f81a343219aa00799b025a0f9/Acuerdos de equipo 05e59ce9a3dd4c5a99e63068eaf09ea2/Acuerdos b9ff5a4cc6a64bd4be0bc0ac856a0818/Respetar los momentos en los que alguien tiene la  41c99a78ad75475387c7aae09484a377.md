# Respetar los momentos en los que alguien tiene la palabra durante las juntas y trabajos en equipo. No se prohíben las charlas entre miembros durante las juntas, pero se espera que no interfieran con la atención de los demás y que no desvíen el curso de la conversación. Esto aplica de la misma manera durante las clases impartidas por los profesores.

Tags: Reunion, To do, Valores