# Todo lo que se trabaje deberá de ser en donde se ha definido que se trata el proceso, sea en Google Drive (Fuente de Verdad), Notion (para la wiki), Github (código, issues).

Tags: Comunicación, Procesos, To do