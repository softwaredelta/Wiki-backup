# Reconocer los roles de los distintos miembros de los equipos.

Tags: Confianza, Procesos, To do