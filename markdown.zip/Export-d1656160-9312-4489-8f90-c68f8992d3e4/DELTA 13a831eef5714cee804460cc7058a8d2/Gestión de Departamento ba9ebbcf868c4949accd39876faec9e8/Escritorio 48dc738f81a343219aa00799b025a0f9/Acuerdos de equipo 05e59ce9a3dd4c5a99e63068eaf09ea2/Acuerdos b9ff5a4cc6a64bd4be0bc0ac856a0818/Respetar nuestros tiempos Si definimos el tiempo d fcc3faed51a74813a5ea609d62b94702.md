# Respetar nuestros tiempos. Si definimos el tiempo de la reunión velaremos por cumplirlo, se haya o no se haya completado el trabajo, con la excepción si todos los reunidos deciden lo contrario.

Tags: Reunion, To do