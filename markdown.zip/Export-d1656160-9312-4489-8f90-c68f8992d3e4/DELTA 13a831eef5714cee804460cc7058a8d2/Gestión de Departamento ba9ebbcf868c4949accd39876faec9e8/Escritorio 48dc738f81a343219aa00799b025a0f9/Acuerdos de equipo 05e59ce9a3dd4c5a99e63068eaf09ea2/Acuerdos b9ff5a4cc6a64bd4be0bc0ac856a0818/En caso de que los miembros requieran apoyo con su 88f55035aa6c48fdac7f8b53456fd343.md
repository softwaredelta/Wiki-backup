# En caso de que los miembros requieran apoyo con sus actividades, se espera que las comuniquen adecuadamente ya sea con profesores, miembros de la comunidad de apoyo o colegas.

Tags: Comunicación, To do, Valores