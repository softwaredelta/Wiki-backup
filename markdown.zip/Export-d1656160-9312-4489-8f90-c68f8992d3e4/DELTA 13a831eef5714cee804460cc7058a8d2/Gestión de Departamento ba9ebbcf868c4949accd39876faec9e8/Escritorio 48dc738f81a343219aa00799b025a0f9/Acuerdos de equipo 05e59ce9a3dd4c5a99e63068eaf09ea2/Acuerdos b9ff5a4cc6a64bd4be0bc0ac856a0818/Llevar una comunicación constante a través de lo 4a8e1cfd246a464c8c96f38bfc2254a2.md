# Llevar una comunicación constante a través de los medios adecuados, especialmente al momento de realizar cambios. Se debe notificar a los afectados por el cambio, al igual que debe documentarse el cambio en los lugares apropiados.

Tags: Comunicación, Procesos, To do