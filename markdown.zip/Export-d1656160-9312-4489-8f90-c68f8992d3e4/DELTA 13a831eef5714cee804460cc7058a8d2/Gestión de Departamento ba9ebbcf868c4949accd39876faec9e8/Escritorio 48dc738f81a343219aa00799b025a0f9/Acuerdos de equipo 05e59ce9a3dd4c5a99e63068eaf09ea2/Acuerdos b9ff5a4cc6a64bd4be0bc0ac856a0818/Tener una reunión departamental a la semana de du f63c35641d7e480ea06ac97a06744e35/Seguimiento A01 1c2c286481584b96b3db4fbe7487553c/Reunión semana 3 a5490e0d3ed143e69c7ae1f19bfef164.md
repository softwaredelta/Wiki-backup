# Reunión semana 3

Hecho: No