# Notificar si vas a faltar a alguna junta o responsabilidad, para ello se deben de utilizar los canales de comunicación apropiados (WhatsApp y Discord).

Tags: Comunicación, Procesos, Reunion, To do