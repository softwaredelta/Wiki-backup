# Comunicarse de manera respetuosa, de igual manera, comunicar si consideras que una acción fue una falta de respeto, ataque personal o si preferirías que no se realice cierta acción al interactuar contigo. ¿Qué sucede si hay faltas de respeto?

Tags: Comunicación, Confianza, To do, Valores