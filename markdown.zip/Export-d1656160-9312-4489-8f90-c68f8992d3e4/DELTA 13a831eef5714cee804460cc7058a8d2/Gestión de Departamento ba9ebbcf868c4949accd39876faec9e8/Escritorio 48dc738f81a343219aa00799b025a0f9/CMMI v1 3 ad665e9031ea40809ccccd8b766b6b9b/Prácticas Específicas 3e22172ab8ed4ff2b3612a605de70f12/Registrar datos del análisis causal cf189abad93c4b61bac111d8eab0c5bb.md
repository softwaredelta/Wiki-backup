# Registrar datos del análisis causal

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Tratar%20las%20causas%20de%20los%20resultados%20seleccionados%20738b186f8e3d4aa782d83adced1ee3cb.md
Número de Práctica: 2.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Ana%CC%81lisis%20Causal%20y%20Resolucio%CC%81n%2059de40358f97422ab98406c5a9fffa87.md