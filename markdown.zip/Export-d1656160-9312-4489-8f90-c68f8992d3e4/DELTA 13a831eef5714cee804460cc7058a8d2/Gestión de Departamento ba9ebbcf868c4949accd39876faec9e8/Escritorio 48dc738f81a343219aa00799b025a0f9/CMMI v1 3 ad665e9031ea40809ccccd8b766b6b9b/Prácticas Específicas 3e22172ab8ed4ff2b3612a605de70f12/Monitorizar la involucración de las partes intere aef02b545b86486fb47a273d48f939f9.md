# Monitorizar la involucración de las partes interesadas

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Monitorizar%20el%20proyecto%20frente%20al%20plan%206835cf7d75ef405bb195ca9c5216564e.md
Número de Práctica: 1.5
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Monitorizacio%CC%81n%20y%20Control%20del%20Proyecto%20432710662d134b619e76c5e620fdf2ea.md