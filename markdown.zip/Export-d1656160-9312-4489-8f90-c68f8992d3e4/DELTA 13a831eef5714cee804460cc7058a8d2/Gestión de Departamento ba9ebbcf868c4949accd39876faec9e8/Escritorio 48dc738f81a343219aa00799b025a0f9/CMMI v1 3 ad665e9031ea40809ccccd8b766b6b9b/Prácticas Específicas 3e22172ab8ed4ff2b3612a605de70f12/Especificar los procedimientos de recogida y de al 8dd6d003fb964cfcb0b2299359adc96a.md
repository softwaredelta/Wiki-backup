# Especificar los procedimientos de recogida y de almacenamiento de datos

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Alinear%20las%20actividades%20de%20medicio%CC%81n%20y%20ana%CC%81lisis%208c1184dab82a48de89f8371ea799410b.md
Número de Práctica: 1.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Medicio%CC%81n%20y%20Ana%CC%81lisis%20a20346de4ab7497d9b6418ed812c97ce.md