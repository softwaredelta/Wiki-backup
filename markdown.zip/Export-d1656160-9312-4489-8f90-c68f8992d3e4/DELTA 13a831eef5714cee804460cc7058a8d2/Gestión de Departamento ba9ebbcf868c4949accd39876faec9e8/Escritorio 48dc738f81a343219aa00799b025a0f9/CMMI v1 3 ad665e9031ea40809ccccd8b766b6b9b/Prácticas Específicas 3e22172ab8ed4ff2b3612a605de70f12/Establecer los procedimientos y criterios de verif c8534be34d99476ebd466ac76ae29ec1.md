# Establecer los procedimientos y criterios de verificación

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Preparar%20la%20verificacio%CC%81n%20e13a35996559439287590ac09444691b.md
Número de Práctica: 1.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Verificacio%CC%81n%203fdad80d98f94ba1aad596ff9b90cb19.md