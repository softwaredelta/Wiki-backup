# Incorporar las experiencias en los activos de proceso de la organización

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Desplegar%20los%20activos%20de%20proceso%20de%20la%20organizacio%2008dc5ad56368443fbcbc713241e18f0c.md
Número de Práctica: 3.4
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Enfoque%20en%20Procesos%20de%20la%20Orgnanizacio%CC%81n%204b83a0e6d3664c01845496697fa04969.md