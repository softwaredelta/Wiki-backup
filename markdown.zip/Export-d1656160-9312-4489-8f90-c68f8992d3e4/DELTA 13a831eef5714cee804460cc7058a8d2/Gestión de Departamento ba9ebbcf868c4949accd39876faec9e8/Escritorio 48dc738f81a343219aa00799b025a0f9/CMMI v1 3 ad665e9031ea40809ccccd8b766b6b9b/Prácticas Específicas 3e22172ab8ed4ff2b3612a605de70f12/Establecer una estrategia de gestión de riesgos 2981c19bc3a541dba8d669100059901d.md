# Establecer una estrategia de gestión de riesgos

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Preparar%20la%20gestio%CC%81n%20de%20riesgos%20e7aced8c746541b5817f0f272cc72762.md
Número de Práctica: 1.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Riesgos%200e43fc88193f4ed3ae6d0be1c77b9e53.md