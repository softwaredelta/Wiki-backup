# Realizar la verificación

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Verificar%20los%20productos%20de%20trabajo%20seleccionados%2066b881171c6c4a6395f3674c6bca08e0.md
Número de Práctica: 3.1
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Verificacio%CC%81n%203fdad80d98f94ba1aad596ff9b90cb19.md