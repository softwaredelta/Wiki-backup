# Mantener los objetivos de negocio

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Gestionar%20el%20rendimiento%20del%20negocio%20d4f97aeb384b48f9841ec129c0d4e959.md
Número de Práctica: 1.1
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20del%20Rendimiento%20de%20la%20Organizacio%CC%81n%201165d66f9cb147e193a68fe224299ffd.md