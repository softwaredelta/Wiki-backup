# Comunicar y resolver las no conformidades

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Proporcionar%20una%20visio%CC%81n%20objetiva%209d48cbd6fc73462ca834202444506473.md
Número de Práctica: 2.1
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Aseguramiento%20de%20la%20Calidad%20del%20Proceso%20y%20del%20Prod%20b70a2ad4a479438889e2e7857d54fce2.md