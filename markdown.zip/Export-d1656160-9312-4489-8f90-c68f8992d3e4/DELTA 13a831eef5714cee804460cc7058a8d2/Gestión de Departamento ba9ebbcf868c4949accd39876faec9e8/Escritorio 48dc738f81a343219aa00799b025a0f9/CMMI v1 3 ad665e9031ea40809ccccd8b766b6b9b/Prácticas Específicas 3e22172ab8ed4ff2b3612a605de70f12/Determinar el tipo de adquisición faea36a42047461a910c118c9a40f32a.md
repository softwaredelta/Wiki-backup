# Determinar el tipo de adquisición

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Establecer%20acuerdos%20con%20proveedores%20be3ff60a391b44ddb7f41a3467e14a07.md
Número de Práctica: 1.1
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Acuerdos%20con%20Proveedores%2004468e4302d54e828933fd7148021c6d.md