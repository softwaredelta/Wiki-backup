# Almacenar los datos y los resultados

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Proporcionar%20los%20resultados%20de%20la%20medicio%CC%81n%20f4d79ee2811948f0b452c5b985700717.md
Número de Práctica: 2.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Medicio%CC%81n%20y%20Ana%CC%81lisis%20a20346de4ab7497d9b6418ed812c97ce.md