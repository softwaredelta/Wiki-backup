# Seleccionar los productos para la validación

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Preparar%20la%20validacio%CC%81n%20172281aad7674e5caa1e47d9a320927c.md
Número de Práctica: 1.1
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Validacio%CC%81n%207324084657ba466ebf6029b99fec09ef.md