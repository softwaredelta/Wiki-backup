# Analizar el rendimiento de proceso y establecer las líneas base de rendimiento de proceso

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Establecer%20las%20li%CC%81neas%20base%20y%20los%20modelos%20de%20rendi%20a096fba5561c440ea86db16c3c0acd5c.md
Número de Práctica: 1.4
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Rendimiento%20de%20Procesos%20de%20la%20Organizacio%CC%81n%20420c4870d73849e4b1025dedda4fc60a.md