# Evaluar objetivamente los productos de trabajo

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Evaluar%20objetivamente%20los%20procesos%20y%20los%20productos%20eec582d9772a46299be1ac105584a17c.md
Número de Práctica: 1.2
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Aseguramiento%20de%20la%20Calidad%20del%20Proceso%20y%20del%20Prod%20b70a2ad4a479438889e2e7857d54fce2.md