# Conciliar los niveles de trabajo y de recursos

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Obtener%20el%20compromiso%20con%20el%20plan%20c5c0bcdb778f4d2b98dab5ce163fa0da.md
Número de Práctica: 3.2
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Planificacio%CC%81n%20del%20Proyecto%206dba5b9a080c4ef0a4babec2ebb5d62f.md