# Establecer la biblioteca de activos de proceso de la organización

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Establecer%20los%20activos%20de%20proceso%20de%20la%20organizaci%20a0faddf18c504bfa9b383ad019c6b80e.md
Número de Práctica: 1.5
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Definicio%CC%81n%20de%20Procesos%20de%20la%20Organizacio%CC%81n%2028dda79c8db24412a531517bc4be0604.md