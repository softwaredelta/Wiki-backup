# Seleccionar los resultados a analizar

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Determinar%20las%20causas%20de%20los%20resultados%20selecciona%207192001e208a401b97942b2c94f0b72c.md
Número de Práctica: 1.1
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Ana%CC%81lisis%20Causal%20y%20Resolucio%CC%81n%2059de40358f97422ab98406c5a9fffa87.md