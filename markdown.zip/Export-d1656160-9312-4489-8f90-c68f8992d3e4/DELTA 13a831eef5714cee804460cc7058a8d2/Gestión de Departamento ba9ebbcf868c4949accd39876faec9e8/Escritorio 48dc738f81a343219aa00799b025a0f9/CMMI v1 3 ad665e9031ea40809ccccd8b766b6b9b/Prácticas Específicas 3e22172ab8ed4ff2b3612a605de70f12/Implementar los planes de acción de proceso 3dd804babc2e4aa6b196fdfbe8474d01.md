# Implementar los planes de acción de proceso

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Planificar%20e%20implementar%20las%20acciones%20de%20proceso%202ef4dce7d5cb4a9abf727d33a067a9d1.md
Número de Práctica: 2.2
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Enfoque%20en%20Procesos%20de%20la%20Orgnanizacio%CC%81n%204b83a0e6d3664c01845496697fa04969.md