# Resolver las cuestiones de coordinación

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Coordinar%20y%20colaborar%20con%20las%20partes%20interesadas%20r%203b5db03a64e84473828b36c9be7cb5a6.md
Número de Práctica: 2.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20Integrada%20del%20Proyecto%20e1c9f609064a4a979d7af88ba350a848.md