# Realizar la validación

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Validar%20el%20producto%20o%20los%20componentes%20del%20producto%204589f26b647e472aae7c494e2b9c88af.md
Número de Práctica: 2.1
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Validacio%CC%81n%207324084657ba466ebf6029b99fec09ef.md