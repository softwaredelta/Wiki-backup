# Seleccionar los subprocesos y los atributos

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Preparar%20la%20gestio%CC%81n%20cuantitativa%20dcc5d73ba08e4b509b74171709683822.md
Número de Práctica: 1.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20Cuantitativa%20del%20Proyecto%20dba236ec00424cc0bb52728fcbc441a7.md