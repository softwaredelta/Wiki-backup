# Establecer los conceptos y los escenarios de operación

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Analizar%20y%20validar%20los%20requisitos%20f0b009a81cda4e3198b8044b42710fa5.md
Número de Práctica: 3.1
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Desarrollo%20de%20Requisitos%2020b29831aa74464482be4d49fddde7fd.md