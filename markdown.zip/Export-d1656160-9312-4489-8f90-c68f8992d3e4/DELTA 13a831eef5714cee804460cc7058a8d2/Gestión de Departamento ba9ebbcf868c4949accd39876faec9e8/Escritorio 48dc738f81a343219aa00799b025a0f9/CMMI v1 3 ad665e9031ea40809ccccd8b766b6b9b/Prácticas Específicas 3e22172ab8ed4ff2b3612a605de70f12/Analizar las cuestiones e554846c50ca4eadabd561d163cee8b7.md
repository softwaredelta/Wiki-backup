# Analizar las cuestiones

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Gestionar%20las%20acciones%20correctivas%20hasta%20su%20cierre%20ff675f8f42144074b3b55ffc5faa150f.md
Número de Práctica: 2.1
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Monitorizacio%CC%81n%20y%20Control%20del%20Proyecto%20432710662d134b619e76c5e620fdf2ea.md