# Evaluar, clasificar y priorizar los riesgos

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Identificar%20y%20analizar%20los%20riesgos%20eb5254f8e570445f8ed13018a5aa6e94.md
Número de Práctica: 2.2
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Riesgos%200e43fc88193f4ed3ae6d0be1c77b9e53.md