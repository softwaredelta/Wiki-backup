# Identificar los riesgos del proyecto

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Desarrollar%20un%20plan%20de%20proyecto%208879362cdf974eba8db5921b9c0ea5a2.md
Número de Práctica: 2.2
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Planificacio%CC%81n%20del%20Proyecto%206dba5b9a080c4ef0a4babec2ebb5d62f.md