# Identificar las soluciones alternativas

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Evaluar%20las%20alternativas%202d5103a39d904086a0e0cf27c4951109.md
Número de Práctica: 1.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Ana%CC%81lisis%20de%20Decisiones%20y%20Resolucio%CC%81n%20adaa2a5f225b48b2b2f2c1560728e582.md