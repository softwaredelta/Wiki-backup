# Evaluar la eficacia de la formación

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Proporcionar%20formacio%CC%81n%20b157e4f845874958bfa5eb67413d1ef4.md
Número de Práctica: 2.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Formacio%CC%81n%20en%20la%20Organizacio%CC%81n%209f260d1ca04a47d6aa0348a86757c682.md