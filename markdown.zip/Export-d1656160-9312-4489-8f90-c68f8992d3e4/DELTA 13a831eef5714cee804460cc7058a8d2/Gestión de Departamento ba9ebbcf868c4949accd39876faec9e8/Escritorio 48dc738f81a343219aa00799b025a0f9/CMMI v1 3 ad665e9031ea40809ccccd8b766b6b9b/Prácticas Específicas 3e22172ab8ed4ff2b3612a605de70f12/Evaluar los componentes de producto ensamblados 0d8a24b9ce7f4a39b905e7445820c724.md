# Evaluar los componentes de producto ensamblados

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Ensamblar%20los%20componentes%20del%20producto%20y%20entregar%20%201cd37cd6eeee4cb6a81cda68bd377b0a.md
Número de Práctica: 3.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Integracio%CC%81n%20del%20Producto%2086cd953694034d4eae9de8f0aafa84d1.md