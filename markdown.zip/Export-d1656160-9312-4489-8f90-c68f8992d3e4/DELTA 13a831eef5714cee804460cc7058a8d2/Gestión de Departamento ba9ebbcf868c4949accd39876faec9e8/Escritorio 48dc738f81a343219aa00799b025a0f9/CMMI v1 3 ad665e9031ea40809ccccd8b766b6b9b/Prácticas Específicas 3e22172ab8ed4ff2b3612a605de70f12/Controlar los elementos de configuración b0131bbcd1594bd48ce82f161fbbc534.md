# Controlar los elementos de configuración

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Seguir%20y%20controlar%20los%20cambios%20a537c807da014a66b10e1e24da179c39.md
Número de Práctica: 2.2
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Configuracio%CC%81n%20499615b0e10f48b28021c1595603e9fd.md