# Contribuir a los activos de proceso de la organización

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Utilizar%20el%20proceso%20definido%20del%20proyecto%20e4965b7558264baea56a8507594bea82.md
Número de Práctica: 1.7
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20Integrada%20del%20Proyecto%20e1c9f609064a4a979d7af88ba350a848.md