# Identificar los requisitos de interfaz

Meta Específica: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Desarrollar%20los%20requisitos%20del%20producto%20bc0bf41dc7434d92bf28445389041a9a.md
Número de Práctica: 2.3
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Desarrollo%20de%20Requisitos%2020b29831aa74464482be4d49fddde7fd.md