# Análisis de Decisiones y Resolución

Abreviación: DAR
Book Link: https://resources.sei.cmu.edu/asset_files/whitepaper/2010_019_001_28782.pdf#page=222
Metas Específicas: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Evaluar%20las%20alternativas%202d5103a39d904086a0e0cf27c4951109.md
Nivel de Madurez: 3
Propósito: El propósito del Análisis de Decisiones y Resolución (DAR) es analizar las posibles decisiones utilizando un proceso de evaluación formal que evalúa las alternativas identificadas, frente a unos criterios
establecidos.
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Seleccionar%20las%20soluciones%201a9e53b7cd66440f9ae799bc5b1cf774.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Identificar%20las%20soluciones%20alternativas%206d7b73b7666e4411a5a731d13906222c.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20las%20gui%CC%81as%20para%20el%20ana%CC%81lisis%20de%20decisio%2022a54dea57014e3a9503aa776b6de5e4.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Seleccionar%20los%20me%CC%81todos%20de%20evaluacio%CC%81n%2053a5382f028a41e59be851b77d2b2be1.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20los%20criterios%20de%20evaluacio%CC%81n%2028f8fb1641a0472fa8b92a3fd4dec2ab.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Evaluar%20las%20soluciones%20alternativas%205594fb9c12e04facb940a303a9fc3eba.md