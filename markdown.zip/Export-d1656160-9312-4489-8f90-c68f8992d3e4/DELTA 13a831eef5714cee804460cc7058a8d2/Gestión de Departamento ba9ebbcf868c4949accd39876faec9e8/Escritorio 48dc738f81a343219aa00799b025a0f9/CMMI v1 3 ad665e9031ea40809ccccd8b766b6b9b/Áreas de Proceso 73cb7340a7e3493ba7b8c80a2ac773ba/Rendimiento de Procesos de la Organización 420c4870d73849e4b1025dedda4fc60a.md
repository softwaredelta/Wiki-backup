# Rendimiento de Procesos de la Organización

Abreviación: OPP
Book Link: https://resources.sei.cmu.edu/asset_files/whitepaper/2010_019_001_28782.pdf#page=313
Metas Específicas: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Establecer%20las%20li%CC%81neas%20base%20y%20los%20modelos%20de%20rendi%20a096fba5561c440ea86db16c3c0acd5c.md
Nivel de Madurez: 4
Propósito: El propósito del Rendimiento de Procesos de la Organización (OPP) es
establecer y mantener una comprensión cuantitativa del rendimiento
de los procesos seleccionados del conjunto de procesos estándar de
la organización para dar soporte a la consecución de los objetivos de
calidad y de rendimiento de proceso, y para proporcionar datos, líneas
base y modelos de rendimiento de proceso con los que gestionar cuantitativamente los proyectos de la organización
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20los%20objetivos%20de%20calidad%20y%20rendimiento%20%20a6ad274b1bea4e5097d75cabe45e43c0.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20las%20medidas%20de%20rendimiento%20de%20proceso%20e5106f679cd64620b957179c2759053a.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Seleccionar%20los%20procesos%20fe8a6988f4ae45868e7b409f2e85e5b9.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Analizar%20el%20rendimiento%20de%20proceso%20y%20establecer%20la%201649870177494bbba6143e34e762a739.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20los%20modelos%20de%20rendimiento%20de%20proceso%203f810660083a44c5a5db7266c2fdebdb.md