# Análisis Causal y Resolución

Abreviación: CAR
Book Link: https://resources.sei.cmu.edu/asset_files/whitepaper/2010_019_001_28782.pdf#page=200
Metas Específicas: ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Determinar%20las%20causas%20de%20los%20resultados%20selecciona%207192001e208a401b97942b2c94f0b72c.md, ../Metas%20Especi%CC%81ficas%2001a59630d53145479e64a6d0e43d64e0/Tratar%20las%20causas%20de%20los%20resultados%20seleccionados%20738b186f8e3d4aa782d83adced1ee3cb.md
Nivel de Madurez: 5
Propósito: El propósito de Análisis Causal y Resolución (CAR) es identificar las
causas de los resultados seleccionados y actuar para mejorar el rendimiento de proceso.
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Seleccionar%20los%20resultados%20a%20analizar%20eeee4a76d8614a4d8202056c3c9e919e.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Analizar%20las%20causas%2064ae19be5c214faab903bdde16d626e6.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Implementar%20las%20propuestas%20de%20accio%CC%81n%201a1ccc0a2b9f4207accfd4dc56fe1ff3.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Evaluar%20el%20efecto%20de%20las%20acciones%20implementadas%20d2b983d21bd1413ea420ba0670d0e9a2.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Registrar%20datos%20del%20ana%CC%81lisis%20causal%20cf189abad93c4b61bac111d8eab0c5bb.md