# Determinar las oportunidades de mejora de procesos

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20las%20necesidades%20de%20proceso%20de%20la%20organi%20c8a6884890a44e4ca415f028d2065dfd.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Evaluar%20los%20procesos%20de%20la%20organizacio%CC%81n%20fa957e362d3546f88b4b58aa19c13fea.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Identificar%20las%20mejoras%20de%20procesos%20de%20la%20organiza%20cf53ab9acecf435d907c2639c40e9125.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Enfoque%20en%20Procesos%20de%20la%20Orgnanizacio%CC%81n%204b83a0e6d3664c01845496697fa04969.md