# Establecer las líneas base

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Identificar%20los%20elementos%20de%20configuracio%CC%81n%204635dbea72704735919fcf580e728c33.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20un%20sistema%20de%20gestio%CC%81n%20de%20configuracio%CC%81%206f8cb123a7164a40897a29e36fbdda78.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Crear%20o%20liberar%20las%20li%CC%81neas%20base%205d530ee7e9e3407d8f28e1750cee659b.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Configuracio%CC%81n%20499615b0e10f48b28021c1595603e9fd.md