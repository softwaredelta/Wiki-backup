# Establecer acuerdos con proveedores

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20acuerdos%20con%20proveedores%20a07cc5e1a0b343afb38f4ee306e463f1.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Determinar%20el%20tipo%20de%20adquisicio%CC%81n%20faea36a42047461a910c118c9a40f32a.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Seleccionar%20a%20los%20proveedores%20173eddd498d444559b5a8173aa692854.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Acuerdos%20con%20Proveedores%2004468e4302d54e828933fd7148021c6d.md