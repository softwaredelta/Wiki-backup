# Realizar las revisiones entre pares

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Preparar%20las%20revisiones%20entre%20pares%20b1f0fbb43b5748d7908892239285bb34.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Realizar%20las%20revisiones%20entre%20pares%2067de18c844704652bd4164a97b1ac4f8.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Analizar%20los%20datos%20de%20las%20revisiones%20entre%20pares%20a9b7a21d72a140318df29192747fbf8a.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Verificacio%CC%81n%203fdad80d98f94ba1aad596ff9b90cb19.md