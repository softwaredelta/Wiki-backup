# Seleccionar soluciones de componentes de producto

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Desarrollar%20soluciones%20alternativas%20y%20los%20criterio%20a838c2c7dd0a428da981e567bcefb960.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Seleccionar%20las%20soluciones%20de%20componentes%20de%20produ%20b16616f1fce74a1b9b5a04da170f35af.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Solucio%CC%81n%20Te%CC%81cnica%201d4c1df599364dbba61ba4e9e297d453.md