# Proporcionar una visión objetiva

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Comunicar%20y%20resolver%20las%20no%20conformidades%201a93cdbdbf7847a8b7b337ce808a9961.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20los%20registros%208d3ce9cc24c848dc98f3e1501b2535d6.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Aseguramiento%20de%20la%20Calidad%20del%20Proceso%20y%20del%20Prod%20b70a2ad4a479438889e2e7857d54fce2.md