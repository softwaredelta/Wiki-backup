# Preparar la gestión de riesgos

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Determinar%20las%20fuentes%20y%20las%20categori%CC%81as%20de%20riesgo%208c979d3a6fa44ef099d57066f21c39bc.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Definir%20los%20para%CC%81metros%20de%20riesgos%208f65e384f9364f56b39584adfe13e561.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20una%20estrategia%20de%20gestio%CC%81n%20de%20riesgos%202981c19bc3a541dba8d669100059901d.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Riesgos%200e43fc88193f4ed3ae6d0be1c77b9e53.md