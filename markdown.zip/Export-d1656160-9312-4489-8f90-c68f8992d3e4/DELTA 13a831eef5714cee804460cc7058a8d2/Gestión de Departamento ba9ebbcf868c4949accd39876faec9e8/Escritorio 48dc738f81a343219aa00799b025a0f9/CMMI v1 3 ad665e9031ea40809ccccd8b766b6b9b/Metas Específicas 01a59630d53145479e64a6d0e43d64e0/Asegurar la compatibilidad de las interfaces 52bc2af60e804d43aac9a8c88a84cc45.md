# Asegurar la compatibilidad de las interfaces

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Revisar%20la%20completitud%20de%20las%20descripciones%20de%20las%20d9e956846f754a95b70f10d760ec34fe.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Gestionar%20las%20interfaces%2017239e6ded534676a226dc2da47d6ea7.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Integracio%CC%81n%20del%20Producto%2086cd953694034d4eae9de8f0aafa84d1.md