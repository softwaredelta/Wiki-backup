# Proporcionar formación

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Impartir%20la%20formacio%CC%81n%202bf6bf91ddc04706a59d0d3e2b257edc.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20los%20registros%20de%20formacio%CC%81n%20aecca666a8bf44e4b5cc31bf59e36f29.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Evaluar%20la%20eficacia%20de%20la%20formacio%CC%81n%2030af201dd7fe49b99e46ab1e63084594.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Formacio%CC%81n%20en%20la%20Organizacio%CC%81n%209f260d1ca04a47d6aa0348a86757c682.md