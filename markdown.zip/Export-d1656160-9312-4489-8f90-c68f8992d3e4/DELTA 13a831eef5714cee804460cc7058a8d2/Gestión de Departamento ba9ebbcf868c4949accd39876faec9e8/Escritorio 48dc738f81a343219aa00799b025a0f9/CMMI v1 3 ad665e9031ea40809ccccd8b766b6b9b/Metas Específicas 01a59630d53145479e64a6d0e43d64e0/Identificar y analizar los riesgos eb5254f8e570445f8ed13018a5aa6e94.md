# Identificar y analizar los riesgos

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Identificar%20los%20riesgos%200a2d29800fdc4c14b1110f773f1fbe27.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Evaluar,%20clasificar%20y%20priorizar%20los%20riesgos%2059b100bca7554109aeb8a1ea4f2f3625.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Riesgos%200e43fc88193f4ed3ae6d0be1c77b9e53.md