# Coordinar y colaborar con las partes interesadas relevantes

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Gestionar%20la%20involucracio%CC%81n%20de%20las%20partes%20interesa%2015915bbd2ac7483cb47a539658380f95.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Gestionar%20las%20dependencias%202c5a4416021048a3922426185c4c8dd5.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Resolver%20las%20cuestiones%20de%20coordinacio%CC%81n%20c782db8881a74e608e7b57163c1a87dc.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20Integrada%20del%20Proyecto%20e1c9f609064a4a979d7af88ba350a848.md