# Gestionar las acciones correctivas hasta su cierre

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Analizar%20las%20cuestiones%20e554846c50ca4eadabd561d163cee8b7.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Llevar%20a%20cabo%20las%20acciones%20correctivas%20a636527ac65e4669b3cc0495c091ddbd.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Gestionar%20las%20acciones%20correctivas%20c75e73b173e64a66b10bd57a92516a18.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Monitorizacio%CC%81n%20y%20Control%20del%20Proyecto%20432710662d134b619e76c5e620fdf2ea.md