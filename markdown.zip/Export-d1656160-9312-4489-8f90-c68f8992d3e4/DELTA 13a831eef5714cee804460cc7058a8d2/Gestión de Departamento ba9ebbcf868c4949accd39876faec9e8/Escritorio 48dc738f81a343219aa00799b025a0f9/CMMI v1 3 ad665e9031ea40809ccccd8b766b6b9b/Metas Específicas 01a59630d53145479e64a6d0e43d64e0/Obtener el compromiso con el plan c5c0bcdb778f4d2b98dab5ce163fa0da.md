# Obtener el compromiso con el plan

Número de meta: 3
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Revisar%20los%20planes%20que%20afecten%20al%20proyecto%20c1f7454138d74812a0795af738771eab.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Conciliar%20los%20niveles%20de%20trabajo%20y%20de%20recursos%2052a72ba342244cb1a515aa6e0eb6412e.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Obtener%20el%20compromiso%20con%20el%20plan%20695204fee95a47fcb4ab0f8dd3ec7324.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Planificacio%CC%81n%20del%20Proyecto%206dba5b9a080c4ef0a4babec2ebb5d62f.md