# Prepararse para la integración  del producto

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20una%20estrategia%20de%20integracio%CC%81n%20c929ce91a4e64783805b93c8971fbe5e.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20el%20entorno%20de%20integracio%CC%81n%20del%20producto%20ac953d96198e44c09339700b21a68837.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20los%20procedimientos%20y%20criterios%20de%20integ%203fa3156ea1784b8ba524fc2f2bc91289.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Integracio%CC%81n%20del%20Producto%2086cd953694034d4eae9de8f0aafa84d1.md