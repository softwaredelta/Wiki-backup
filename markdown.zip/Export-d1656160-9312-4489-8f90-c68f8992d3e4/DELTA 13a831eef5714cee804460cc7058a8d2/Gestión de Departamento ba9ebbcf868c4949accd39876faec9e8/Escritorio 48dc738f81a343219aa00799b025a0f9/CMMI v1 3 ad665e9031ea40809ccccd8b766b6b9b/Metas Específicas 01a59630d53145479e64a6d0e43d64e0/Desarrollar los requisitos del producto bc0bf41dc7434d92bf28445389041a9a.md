# Desarrollar los requisitos del producto

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20los%20requisitos%20de%20producto%20y%20de%20compone%20340fada0ee6b4cf4aeb7ae7bf440155e.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Asignar%20los%20requisitos%20de%20componente%20de%20producto%209e75faa59b334c46961760fc4e3b1d97.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Identificar%20los%20requisitos%20de%20interfaz%20487cb15271f5436799ad972b8850c006.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Desarrollo%20de%20Requisitos%2020b29831aa74464482be4d49fddde7fd.md