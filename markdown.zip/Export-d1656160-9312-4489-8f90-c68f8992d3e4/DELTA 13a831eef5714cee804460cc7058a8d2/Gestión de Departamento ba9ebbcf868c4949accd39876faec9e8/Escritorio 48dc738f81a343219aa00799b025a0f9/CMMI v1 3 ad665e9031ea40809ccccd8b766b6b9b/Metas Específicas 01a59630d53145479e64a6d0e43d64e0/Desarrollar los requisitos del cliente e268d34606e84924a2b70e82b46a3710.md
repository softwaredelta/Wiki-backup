# Desarrollar los requisitos del cliente

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Educir%20las%20necesidades%20efd60b2cee9b4a69bf969c1d66d23e4d.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Transformar%20las%20necesidades%20de%20las%20partes%20interesa%20911f9ac2224b4d69a529ea8628815fad.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Desarrollo%20de%20Requisitos%2020b29831aa74464482be4d49fddde7fd.md