# Tratar las causas de los resultados seleccionados

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Implementar%20las%20propuestas%20de%20accio%CC%81n%201a1ccc0a2b9f4207accfd4dc56fe1ff3.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Evaluar%20el%20efecto%20de%20las%20acciones%20implementadas%20d2b983d21bd1413ea420ba0670d0e9a2.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Registrar%20datos%20del%20ana%CC%81lisis%20causal%20cf189abad93c4b61bac111d8eab0c5bb.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Ana%CC%81lisis%20Causal%20y%20Resolucio%CC%81n%2059de40358f97422ab98406c5a9fffa87.md