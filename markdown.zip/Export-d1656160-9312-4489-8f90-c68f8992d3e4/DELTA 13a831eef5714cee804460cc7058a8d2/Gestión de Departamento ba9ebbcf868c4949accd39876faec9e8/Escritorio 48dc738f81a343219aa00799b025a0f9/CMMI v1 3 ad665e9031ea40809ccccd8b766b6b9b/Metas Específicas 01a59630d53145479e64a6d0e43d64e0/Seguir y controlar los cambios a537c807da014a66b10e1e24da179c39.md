# Seguir y controlar los cambios

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Seguir%20las%20peticiones%20de%20cambio%20e9b9ef6d7fe24e4e9ab538ce77d4c9dd.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Controlar%20los%20elementos%20de%20configuracio%CC%81n%20b0131bbcd1594bd48ce82f161fbbc534.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Configuracio%CC%81n%20499615b0e10f48b28021c1595603e9fd.md