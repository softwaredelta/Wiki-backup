# Planificar e implementar las acciones de proceso

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20los%20planes%20de%20accio%CC%81n%20de%20proceso%20c49f29f461f3443e82660ef26bba85af.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Implementar%20los%20planes%20de%20accio%CC%81n%20de%20proceso%203dd804babc2e4aa6b196fdfbe8474d01.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Enfoque%20en%20Procesos%20de%20la%20Orgnanizacio%CC%81n%204b83a0e6d3664c01845496697fa04969.md