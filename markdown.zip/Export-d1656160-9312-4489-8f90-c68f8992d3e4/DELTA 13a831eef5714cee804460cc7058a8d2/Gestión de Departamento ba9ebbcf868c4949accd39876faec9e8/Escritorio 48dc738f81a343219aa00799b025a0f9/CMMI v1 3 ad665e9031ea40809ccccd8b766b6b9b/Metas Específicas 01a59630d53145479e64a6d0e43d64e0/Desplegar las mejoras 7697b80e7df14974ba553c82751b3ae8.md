# Desplegar las mejoras

Número de meta: 3
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Panificar%20el%20despliegue%20c6ecf1177ae145b6ae611c6ebf414edc.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Gestionar%20el%20despliegue%2089c2d1bbaf8a44cb93bd0b427b348b10.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Evaluar%20los%20efectos%20de%20la%20mejora%20c3af0ce153bc4393862e235656bacc4f.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20del%20Rendimiento%20de%20la%20Organizacio%CC%81n%201165d66f9cb147e193a68fe224299ffd.md