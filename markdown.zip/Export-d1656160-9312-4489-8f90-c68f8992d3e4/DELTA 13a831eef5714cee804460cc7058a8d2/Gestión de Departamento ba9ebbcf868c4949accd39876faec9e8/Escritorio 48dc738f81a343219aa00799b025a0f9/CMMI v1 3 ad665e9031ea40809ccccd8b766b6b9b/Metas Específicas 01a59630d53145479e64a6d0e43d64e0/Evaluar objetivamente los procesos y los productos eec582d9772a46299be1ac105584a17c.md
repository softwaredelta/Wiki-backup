# Evaluar objetivamente los procesos y los productos de trabajo

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Evaluar%20objetivamente%20los%20procesos%20cd3a5b830fb14691bc4ea4363f98974f.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Evaluar%20objetivamente%20los%20productos%20de%20trabajo%2001914c4bec044e2e825242595befc1da.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Aseguramiento%20de%20la%20Calidad%20del%20Proceso%20y%20del%20Prod%20b70a2ad4a479438889e2e7857d54fce2.md