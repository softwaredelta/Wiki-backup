# Establecer la integridad

Número de meta: 3
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Establecer%20los%20registros%20de%20gestio%CC%81n%20de%20configurac%20f9b4fb68122342b69d880b1f3b3b3369.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Realizar%20auditori%CC%81as%20de%20configuracio%CC%81n%202afef92fe4a0485b99f1a6c7ab6972a4.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Configuracio%CC%81n%20499615b0e10f48b28021c1595603e9fd.md