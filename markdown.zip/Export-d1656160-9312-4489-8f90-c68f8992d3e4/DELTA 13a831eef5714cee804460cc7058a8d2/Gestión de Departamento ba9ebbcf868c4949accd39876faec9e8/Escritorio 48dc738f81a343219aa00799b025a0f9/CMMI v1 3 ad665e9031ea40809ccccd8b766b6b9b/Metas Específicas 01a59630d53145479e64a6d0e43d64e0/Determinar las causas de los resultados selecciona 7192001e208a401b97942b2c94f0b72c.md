# Determinar las causas de los resultados seleccionados

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Seleccionar%20los%20resultados%20a%20analizar%20eeee4a76d8614a4d8202056c3c9e919e.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Analizar%20las%20causas%2064ae19be5c214faab903bdde16d626e6.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Ana%CC%81lisis%20Causal%20y%20Resolucio%CC%81n%2059de40358f97422ab98406c5a9fffa87.md