# Mitigar los riesgos

Número de meta: 3
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Desarrollar%20los%20planes%20de%20mitigacio%CC%81n%20de%20riesgos%20ffc8bd5cf90a435d9d44d22f996d0a32.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Implementar%20los%20planes%20de%20mitigacio%CC%81n%20de%20riesgos%20b6df9f8306e64c16b7fd734c7be3fda9.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Riesgos%200e43fc88193f4ed3ae6d0be1c77b9e53.md