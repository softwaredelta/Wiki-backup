# Verificar los productos de trabajo seleccionados

Número de meta: 3
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Realizar%20la%20verificacio%CC%81n%20e2bdd5b3685e4e69bbb7cbedcbc8869f.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Analizar%20los%20resultados%20de%20la%20verificacio%CC%81n%201778358984fd481daf47962c2eb88699.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Verificacio%CC%81n%203fdad80d98f94ba1aad596ff9b90cb19.md