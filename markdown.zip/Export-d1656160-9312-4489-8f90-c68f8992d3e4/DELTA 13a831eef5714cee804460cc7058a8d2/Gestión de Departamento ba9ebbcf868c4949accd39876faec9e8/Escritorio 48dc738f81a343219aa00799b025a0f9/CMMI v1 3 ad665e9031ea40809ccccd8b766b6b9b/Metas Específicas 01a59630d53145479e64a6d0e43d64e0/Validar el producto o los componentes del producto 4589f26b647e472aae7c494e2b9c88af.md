# Validar el producto o los componentes del producto

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Realizar%20la%20validacio%CC%81n%2033f8737408944b9484d37f6b703f6f50.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Analizar%20los%20resultados%20de%20la%20validacio%CC%81n%2036100b255a7b4ad288e513939bf2f3da.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Validacio%CC%81n%207324084657ba466ebf6029b99fec09ef.md