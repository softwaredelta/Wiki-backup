# Gestionar el rendimiento del negocio

Número de meta: 1
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Mantener%20los%20objetivos%20de%20negocio%20782fc37f2cc94199beff3cfe3b65b381.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Analizar%20los%20datos%20de%20rendimiento%20de%20proceso%205a1aaff6c87c4ceb802cd0c6ee7f42b3.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Identificar%20las%20a%CC%81reas%20potenciales%20para%20la%20mejora%2060692d886cdd4132ae7b17f5ce361d85.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20del%20Rendimiento%20de%20la%20Organizacio%CC%81n%201165d66f9cb147e193a68fe224299ffd.md