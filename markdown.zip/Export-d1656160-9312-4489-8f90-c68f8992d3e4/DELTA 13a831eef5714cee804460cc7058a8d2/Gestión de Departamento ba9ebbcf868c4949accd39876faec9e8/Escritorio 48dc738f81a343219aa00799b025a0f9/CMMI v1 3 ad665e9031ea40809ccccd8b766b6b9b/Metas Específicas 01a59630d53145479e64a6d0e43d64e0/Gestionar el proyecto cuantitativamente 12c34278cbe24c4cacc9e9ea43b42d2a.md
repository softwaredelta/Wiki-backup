# Gestionar el proyecto cuantitativamente

Número de meta: 2
Prácticas Específicas: ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Monitorizar%20el%20rendimiento%20de%20los%20subprocesos%20sele%20aadca78fabb8400f98d3c0aabe6c947b.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Gestionar%20el%20rendimiento%20del%20proyecto%20eb42855ef5d046cd8ec580996b0d056a.md, ../Pra%CC%81cticas%20Especi%CC%81ficas%203e22172ab8ed4ff2b3612a605de70f12/Realizar%20el%20ana%CC%81lisis%20de%20las%20causas%20rai%CC%81z%20f3360c0c38834ea7b22c605a61e033d9.md
Área de Proceso: ../A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20Cuantitativa%20del%20Proyecto%20dba236ec00424cc0bb52728fcbc441a7.md