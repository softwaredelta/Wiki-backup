# Como mover un archivo de Drive a nuestra wiki en Notion

Must Read: No
Tags: Documentación

1. Ingresa a tu unidad en Drive y busca el archivo deseado.
2. Descarga el archivo a tu computadora.
3. En Notion, da click en el botón para agregar una página.
    
    ![Untitled](Como%20mover%20un%20archivo%20de%20Drive%20a%20nuestra%20wiki%20en%20N%20e3c9ac4a62694e7ca604582508f6a448/Untitled.png)
    
4. Da click en importar, y selecciona google docs, después selecciona el archivo que descargaste.

![Untitled](Como%20mover%20un%20archivo%20de%20Drive%20a%20nuestra%20wiki%20en%20N%20e3c9ac4a62694e7ca604582508f6a448/Untitled%201.png)