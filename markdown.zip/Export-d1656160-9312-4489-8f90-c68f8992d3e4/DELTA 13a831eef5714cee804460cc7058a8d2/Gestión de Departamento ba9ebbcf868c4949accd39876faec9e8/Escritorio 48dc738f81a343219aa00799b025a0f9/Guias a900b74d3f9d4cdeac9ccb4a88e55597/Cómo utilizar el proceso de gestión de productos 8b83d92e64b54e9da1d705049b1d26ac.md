# Cómo utilizar el proceso de gestión de productos de trabajo del departamento si no he usado Notion

Must Read: No
Tags: Documentación, TODO

## Transición de Drive a Notion

**La respuesta corta**:

[Escritorio](../../Escritorio%2048dc738f81a343219aa00799b025a0f9.md)

Todos son libres de manejar y crear los documentos en esta sección. Escritorio es nuestro nuevo drive.

Crea carpetas, páginas, tablas, lo que se te ocurra, utiliza sentido común y responsabilidad para no borrar datos de otras personas.

## Gestión de Cambios

Para componentes más importantes como nuestros activos de proceso y productos de trabajo concluidos (estas son nuestras evidencias) utilizamos una carpeta controlada.

Para actualizar la información en esta sección o agregar nuevos componentes, nos regimos por procesos como:

[Proceso para la gestión de productos de trabajo del departamento](../../Controlado%2022e4d144a8f047fb836aa77da202a397/Procesos%20(controlado)%20fac78b4699564ea0915cdcb6bf4132b2/Proceso%20para%20la%20gestio%CC%81n%20de%20productos%20de%20trabajo%20d%208d24822f55034276831ccfef9f324c9b.md)

[Proceso para la gestión de los activos de proceso del departamento](../../Controlado%2022e4d144a8f047fb836aa77da202a397/Procesos%20(controlado)%20fac78b4699564ea0915cdcb6bf4132b2/Proceso%20para%20la%20gestio%CC%81n%20de%20los%20activos%20de%20proceso%20bfe76154c6ef4f3fb5f1342b8530d5b0.md)