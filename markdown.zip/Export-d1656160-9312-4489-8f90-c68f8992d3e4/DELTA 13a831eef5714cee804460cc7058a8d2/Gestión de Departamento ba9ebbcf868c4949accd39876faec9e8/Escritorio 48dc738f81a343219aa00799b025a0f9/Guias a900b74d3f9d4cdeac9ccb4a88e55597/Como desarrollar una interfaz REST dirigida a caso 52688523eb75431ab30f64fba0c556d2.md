# Como desarrollar una interfaz REST dirigida a casos de uso en comparación a recursos

Must Read: No
Tags: Backend, Desarrollo, TODO