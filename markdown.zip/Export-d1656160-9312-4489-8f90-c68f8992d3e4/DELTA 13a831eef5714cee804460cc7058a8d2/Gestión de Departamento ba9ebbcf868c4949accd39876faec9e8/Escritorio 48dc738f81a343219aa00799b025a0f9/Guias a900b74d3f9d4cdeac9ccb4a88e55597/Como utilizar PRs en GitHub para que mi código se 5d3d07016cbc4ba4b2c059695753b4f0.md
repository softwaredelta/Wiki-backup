# Como utilizar PRs en GitHub para que mi código sea integrado en el producto

Must Read: No
Tags: Configuración, Desarrollo, TODO