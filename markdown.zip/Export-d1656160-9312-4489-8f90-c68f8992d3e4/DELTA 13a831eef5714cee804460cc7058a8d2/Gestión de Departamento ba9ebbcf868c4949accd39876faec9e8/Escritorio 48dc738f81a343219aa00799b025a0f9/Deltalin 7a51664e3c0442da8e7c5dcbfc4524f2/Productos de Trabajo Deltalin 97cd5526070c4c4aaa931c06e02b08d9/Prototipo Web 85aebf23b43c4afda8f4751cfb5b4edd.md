# Prototipo Web

Assign: Arisbeth Aguirre Pontaza, Olivia Araceli Morales Quezada, Jorge Guerrero Díaz
Description: Prototipo en Web, que cubre las pantallas de Login, Administracion de Usuarios y Puntos de Venta y Preguntas
Status: In progress
Tag: Diseños