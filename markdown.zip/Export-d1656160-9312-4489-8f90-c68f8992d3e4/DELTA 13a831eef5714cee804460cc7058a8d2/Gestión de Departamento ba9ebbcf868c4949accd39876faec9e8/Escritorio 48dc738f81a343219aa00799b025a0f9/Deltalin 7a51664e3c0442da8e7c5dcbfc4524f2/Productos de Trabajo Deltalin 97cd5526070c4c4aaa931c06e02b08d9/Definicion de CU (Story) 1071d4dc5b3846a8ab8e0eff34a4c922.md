# Definicion de CU (Story)

Status: Not started