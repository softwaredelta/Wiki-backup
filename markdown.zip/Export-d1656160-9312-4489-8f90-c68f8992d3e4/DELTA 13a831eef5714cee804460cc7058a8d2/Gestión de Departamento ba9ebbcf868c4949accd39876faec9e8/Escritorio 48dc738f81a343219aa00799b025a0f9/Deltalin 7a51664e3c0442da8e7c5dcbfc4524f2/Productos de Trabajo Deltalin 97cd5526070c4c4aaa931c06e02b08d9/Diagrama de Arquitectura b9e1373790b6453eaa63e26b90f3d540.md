# Diagrama de Arquitectura

Assign: Emiliano Vásquez Olea
Description: Propuestas actuales de tecnologías a utilizar en el desarrollo del proyecto de Michelín. Aún se requieren más componentes.
• Unity
• React
• Tailwind CSS
• Fastify
• mySQL
Control de Versiones:
• GitHub
• Plastic SCM???
Status: Review
Tag: Maps

![Diagrama de Arquitectura.png](Diagrama%20de%20Arquitectura%20b9e1373790b6453eaa63e26b90f3d540/Diagrama_de_Arquitectura.png)