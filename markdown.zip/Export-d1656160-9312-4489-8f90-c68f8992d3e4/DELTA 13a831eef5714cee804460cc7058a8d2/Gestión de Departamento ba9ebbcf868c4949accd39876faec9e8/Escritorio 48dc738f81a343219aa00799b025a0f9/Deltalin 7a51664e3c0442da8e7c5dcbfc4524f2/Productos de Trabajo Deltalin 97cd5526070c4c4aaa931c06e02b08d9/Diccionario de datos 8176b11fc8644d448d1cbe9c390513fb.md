# Diccionario de datos

Assign: Cristian Rico, Andres, Fabián Enrique Avilés Cortés
Status: Not started