# Prototipo Movil

Assign: Ricardo Nuñez Alanis
Description: Propuestas del diseño movil en figma, donde se ven las patañas de log in, seleccion de recorrido, exterior, interior y partes del cuestionario
Status: In progress
Tag: Diseños

[https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FNncie0oGhxO3XoHBZOtfVc%2FAltoNivelMichelin%3Fnode-id%3D0%3A1%26t%3D5mxoWEJs9fKANJ17-1](https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FNncie0oGhxO3XoHBZOtfVc%2FAltoNivelMichelin%3Fnode-id%3D0%3A1%26t%3D5mxoWEJs9fKANJ17-1)