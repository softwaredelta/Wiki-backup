# Minuta Delta Dinámica de equipo 22 de febrero

## Resumen

Se llevó a cabo una reunión para discutir los acuerdos de trabajo, integración y trabajo en equipo

# Objetivo

Llevar a cabo una lluvia de ideas para llegar a acuerdos grupales sobre el trabajo, convivencia y nuestra forma de trabajo.

## ¿Quién?

Mónica propuso y dirigió la dinámica de equipo

Alfredo llevó la redacción de los acuerdos en el área de lluvia de ideas 2.0

## Acuerdos

Se generaron acuerdos en el [documento de figma](https://www.figma.com/file/Fc4oQqmy2sco7dFfveXxvM/Acuerdos-de-Equipo?node-id=0%3A1) de Mónica

## Observaciones

El padrino planteó dos preguntas retóricas

¿Qué haremos cuando los acuerdos no se cumplan?

¿Qué haremos para que los acuerdos se cumplan?