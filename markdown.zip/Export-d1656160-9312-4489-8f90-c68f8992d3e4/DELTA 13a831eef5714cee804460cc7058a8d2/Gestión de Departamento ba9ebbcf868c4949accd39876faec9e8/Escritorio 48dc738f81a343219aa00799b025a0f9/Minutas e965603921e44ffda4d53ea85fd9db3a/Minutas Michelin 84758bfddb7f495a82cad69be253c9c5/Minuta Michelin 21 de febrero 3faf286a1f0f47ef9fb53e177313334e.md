# Minuta Michelin 21 de febrero

# Resumen

La primera reunión con el socio formador en donde llegamos a tener mas claro el objetivo del proyecto, se llego a un acuerdo para las reuniones semanales los martes, y a compartir ciertos recursos necesarios. 

# Objetivo

Tener la primera reunión como equipo con el socio-formador, aclarar diferentes dudas y recabar información para definir la necesidad, objetivos y comenzar a trabajar con requisitos del sistema.

## ¿Quién?

Aris y Andrés fueron los principales encargados de la reunión.

Ricardo y Emiliano hicieron preguntas adicionales al socio.

Todo el equipo trabajando con Michelín estuvo presente.

## ¿Qué?

Se tuvo una reunión por medio de Zoom con Maurice, comenzando a las 12 PM. Se utilizaron las preguntas especificadas en el siguiente documento:

[Preguntas para el socio](https://docs.google.com/document/d/1bkajwRsvU_tcpTiw_zzrB7ZSREljOijWUF4qQ-DruLg/edit?usp=share_link)

Además de otros comentarios que surgieron durante la reunión.

# Acuerdos

Se agendaron reuniones recurrentes para los martes, y una el viernes 24 de febrero para presentar el objetivo, alcance, módulos y prototipo.

# Conclusiones

Se logró obtener mucha de la información necesaria, agendar siguientes reuniones, y solicitar varios recursos importantes para el desarrollo del proyecto.

## Observaciones (opcional)

Posterior a la sesión se identificaron otras dudas para la siguiente sesión. Hubo una actitud acelerada por parte del equipo durante la sesión.