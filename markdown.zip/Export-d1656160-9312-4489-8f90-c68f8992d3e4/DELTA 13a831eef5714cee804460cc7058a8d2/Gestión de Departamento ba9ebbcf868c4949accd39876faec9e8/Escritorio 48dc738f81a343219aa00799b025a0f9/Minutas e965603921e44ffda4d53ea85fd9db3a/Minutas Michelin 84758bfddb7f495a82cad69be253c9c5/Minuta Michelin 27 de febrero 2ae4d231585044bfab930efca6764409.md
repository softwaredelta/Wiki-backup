# Minuta Michelin 27 de febrero

# Objetivo

Definir el cronograma de actividades para la semana del 27 de febrero

## ¿Quién?

Estuvieron presentes en la reunión Andrés, Aris, Oli, Jorge y Emiliano

Emiliano redactó en el calendario y la minuta

## ¿Qué?

Se asignaron los encargados de cada una de las actividades elegidas para la semana, junto con estimaciones para sus fechas de inicio y fin.

## Acuerdos (opcional)

Asignados y fechas de entrega para las actividades

# Conclusiones

Se definió la información necesaria, aunque no asistieron todos los miembros del equipo.

😎