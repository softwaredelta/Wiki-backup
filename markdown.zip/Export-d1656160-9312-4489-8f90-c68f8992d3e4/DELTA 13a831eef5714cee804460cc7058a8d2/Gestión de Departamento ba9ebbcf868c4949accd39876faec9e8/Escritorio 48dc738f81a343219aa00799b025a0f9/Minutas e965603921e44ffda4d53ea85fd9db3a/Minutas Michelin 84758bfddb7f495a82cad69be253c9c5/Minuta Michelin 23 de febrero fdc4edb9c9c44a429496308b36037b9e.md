# Minuta Michelin 23 de febrero

## Resumen

Trabajo en equipo, preparar la presentacion de propuesta para el socio, se trabajo en la definicion del MVP y alcance de nuestro proyecto. 

# Objetivo

Seguir definiendo módulos e historias de usuario, además de priorizarlo.

## ¿Quién?

Ricardo: Propuestas de Interfaz

Emiliano: Requisitos no funcionales

Olivia, Cristián, Fabían, Jorge, Andrés y Arisbeth: Historias de usuario y MOSCOW.

## ¿Qué?

Se discutieron y propusieron Módulos para la aplicación, posteriormente se desarrollaron historias de usuario y se priorizaron utilizando MOSCOW.

Se trabajó en propuestas de interfaz para la aplicación móvil (iPad).

Se preguntaron dudas sobre requisitos no funcionales.

## Acuerdos (opcional)

Se acordó que a partir del martes, la próxima semana nos enfocaremos en estudiar el CMMI y en gestionar el equipo.

Se acordó que los jueves el equipo se reunirá para comer helado y así mejorar la relación en el equipo.

Jorge se comprometió a desarrollar historias de usuario de Administración de Puntos de Venta.

# Conclusiones

Aterrizar objetivos y requisitos para que estos puedan alinearse con lo que el cliente requiere es un poco más tardado de lo que uno podría esperar.