# Minuta Michelin 20 de febrero

# Resumen

Organización del calendario y las actividades a realizar por cada miembro a lo largo de la semana, y se preparo la presentación para el socio formador del día siguiente.

# Objetivo

Organizar el calendario, las actividades a realizar y los responsables de las mismas. Y revisar las preguntas al socio formador para el día martes.

## ¿Quién?

Team Leader: Jorge

Product Owner: Aris

Equipo : Ricardo, Emiliano, Cris, Oli, Fabian, Andres

## ¿Qué?

Verificamos las actividades del calendario y realizamos las asignaciones de los responsables, colaborando con los integrantes para verificar que sean asignaciones en donde puedan y quieran trabajar.

Se repasaron los puntos para la reunión con el socio del día martes 21 de febrero. Y se verificó que todos tuviéramos todas las bases.

## Acuerdos

Cada actividad en donde no todos los integrantes se vean involucrados, deberá de ser compartida por los miembros responsables ante el resto del equipo para mantener informados a todos.

# Conclusiones

Los miembros del equipo Michelin han tenido una participación muy activa, lo cual fomenta un trabajo continuo y efectivo.