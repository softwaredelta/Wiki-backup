# Minutas Departamentales

[Minuta Delta 16 Febrero](Minutas%20Departamentales%208d810c8e772248e3aed9f8e60ffad3e7/Minuta%20Delta%2016%20Febrero%206357e9ba811845ed96071154b578c682.md)

[Minuta Delta 17 febrero](Minutas%20Departamentales%208d810c8e772248e3aed9f8e60ffad3e7/Minuta%20Delta%2017%20febrero%2052f7d8a3bbdf4bbcb685ce08129fd8e7.md)

[Minuta Delta Dinámica de equipo 22 de febrero](Minutas%20Departamentales%208d810c8e772248e3aed9f8e60ffad3e7/Minuta%20Delta%20Dina%CC%81mica%20de%20equipo%2022%20de%20febrero%20668abc617be74063b5c90c3c44d73179.md)

[Retrospectiva 24 de febrero](Minutas%20Departamentales%208d810c8e772248e3aed9f8e60ffad3e7/Retrospectiva%2024%20de%20febrero%200a0864cb77b74a0dbde4155de602c08c.md)