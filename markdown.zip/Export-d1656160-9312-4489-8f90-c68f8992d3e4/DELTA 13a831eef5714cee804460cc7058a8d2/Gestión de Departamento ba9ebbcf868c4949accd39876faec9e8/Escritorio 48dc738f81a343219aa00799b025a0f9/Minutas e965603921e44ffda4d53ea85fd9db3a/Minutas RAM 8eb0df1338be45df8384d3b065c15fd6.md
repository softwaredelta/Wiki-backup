# Minutas RAM

[Minuta RAM 20 febrero](Minutas%20RAM%208eb0df1338be45df8384d3b065c15fd6/Minuta%20RAM%2020%20febrero%207cfc85eb7fac4c0f96d20e6a94109f48.md)

[Minuta RAM 21 de febrero](Minutas%20RAM%208eb0df1338be45df8384d3b065c15fd6/Minuta%20RAM%2021%20de%20febrero%206427cce8b4c0423db37324787f1451c9.md)

[Minuta RAM 21 de febrero bis](Minutas%20RAM%208eb0df1338be45df8384d3b065c15fd6/Minuta%20RAM%2021%20de%20febrero%20bis%20511d128682c44e71951955b7c9987933.md)

[Minuta RAM 23 de febrero ](Minutas%20RAM%208eb0df1338be45df8384d3b065c15fd6/Minuta%20RAM%2023%20de%20febrero%2011741d08367e4c6a93b96aae6beb75aa.md)

[Minuta RAM 24 febrero](Minutas%20RAM%208eb0df1338be45df8384d3b065c15fd6/Minuta%20RAM%2024%20febrero%20101226b0772d47f7ab4f6e3da9725b2d.md)