# Untitled

Acrónimos: CM, SG1
CMMI : 2
Completado: No
Prácticas: Establish and maintain a configuration management and change management system for controlling work products.