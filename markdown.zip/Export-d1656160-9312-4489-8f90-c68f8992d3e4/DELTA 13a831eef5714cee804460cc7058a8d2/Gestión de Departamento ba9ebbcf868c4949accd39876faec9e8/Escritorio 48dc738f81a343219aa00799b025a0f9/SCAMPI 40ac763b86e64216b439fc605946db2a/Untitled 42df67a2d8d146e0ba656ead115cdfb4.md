# Untitled

Acrónimos: REQM, SG1
CMMI : 2
Completado: No
Prácticas: Obtain commitment to the requirements from the project participants.
⚙️ Documentación: ../CMMI%20v1%203%20ad665e9031ea40809ccccd8b766b6b9b/A%CC%81reas%20de%20Proceso%2073cb7340a7e3493ba7b8c80a2ac773ba/Gestio%CC%81n%20de%20Requisitos%20aff5fe5e86724d46adc1bdff35e278e5.md