# Untitled

Acrónimos: REQM, SG1
CMMI : 2
Completado: No
Prácticas: Maintain bidirectional traceability among the requirements and the project plans and work products.