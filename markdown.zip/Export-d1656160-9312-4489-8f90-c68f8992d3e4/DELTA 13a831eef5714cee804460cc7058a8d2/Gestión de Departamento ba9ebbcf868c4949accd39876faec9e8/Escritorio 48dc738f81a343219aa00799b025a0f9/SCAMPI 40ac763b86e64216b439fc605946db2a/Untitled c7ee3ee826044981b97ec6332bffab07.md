# Untitled

Acrónimos: PMC, SG2
CMMI : 2
Completado: No
Prácticas: Take corrective action on identified issues.