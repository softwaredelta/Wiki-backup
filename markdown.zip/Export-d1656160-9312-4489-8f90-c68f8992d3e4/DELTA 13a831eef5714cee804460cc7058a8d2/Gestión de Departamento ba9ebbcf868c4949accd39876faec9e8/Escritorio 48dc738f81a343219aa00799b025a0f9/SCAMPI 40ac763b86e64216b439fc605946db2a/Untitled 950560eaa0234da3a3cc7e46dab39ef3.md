# Untitled

Acrónimos: PMC, SG1
CMMI : 2
Completado: No
Prácticas: Monitor the management of project data against the project plan.