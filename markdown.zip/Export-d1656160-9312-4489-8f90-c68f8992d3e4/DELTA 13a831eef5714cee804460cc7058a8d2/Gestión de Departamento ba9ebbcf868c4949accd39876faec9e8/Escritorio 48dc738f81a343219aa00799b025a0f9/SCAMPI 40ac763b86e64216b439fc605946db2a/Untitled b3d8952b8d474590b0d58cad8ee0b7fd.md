# Untitled

Acrónimos: CM, SG3
CMMI : 2
Completado: No
Prácticas: Perform configuration audits to maintain integrity of the configuration baselines.