# Untitled

Acrónimos: PP, SG2
CMMI : 2
Completado: No
Prácticas: Plan for the management of project data.