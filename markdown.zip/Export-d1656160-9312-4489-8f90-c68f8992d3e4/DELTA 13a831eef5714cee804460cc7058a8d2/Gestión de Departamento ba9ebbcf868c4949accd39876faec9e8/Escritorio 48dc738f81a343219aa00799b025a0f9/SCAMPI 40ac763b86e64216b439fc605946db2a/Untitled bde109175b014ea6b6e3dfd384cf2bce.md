# Untitled

Acrónimos: PP, SG1
CMMI : 2
Completado: No
Prácticas: Define the project life-cycle phases upon which to scope the planning effort.