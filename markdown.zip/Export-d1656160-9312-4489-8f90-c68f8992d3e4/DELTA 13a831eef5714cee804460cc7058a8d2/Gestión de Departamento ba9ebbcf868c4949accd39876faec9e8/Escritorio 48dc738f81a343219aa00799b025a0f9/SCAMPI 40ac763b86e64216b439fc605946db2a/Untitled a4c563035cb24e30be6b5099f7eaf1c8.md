# Untitled

Acrónimos: PPQA, SG2
CMMI : 2
Completado: No
Prácticas: Communicate quality issues and ensure resolution of noncompliance issues with the staff and managers.