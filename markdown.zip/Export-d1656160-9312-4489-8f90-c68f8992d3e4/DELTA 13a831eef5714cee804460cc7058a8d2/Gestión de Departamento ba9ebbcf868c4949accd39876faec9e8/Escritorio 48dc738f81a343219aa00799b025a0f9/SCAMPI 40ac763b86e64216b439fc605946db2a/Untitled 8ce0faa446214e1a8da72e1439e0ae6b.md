# Untitled

Acrónimos: PMC, SG1
CMMI : 2
Completado: No
Prácticas: Monitor risks against those identified in the project plan.