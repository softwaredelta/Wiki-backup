# Grupo Asesores RAM Business Rules

## Ramos de Seguros

## Negocios PAI

## Contratos, arrastres y producción

## Porcentajes de ubicación y pago

## Cálculo de bonos (agentes y agencia)