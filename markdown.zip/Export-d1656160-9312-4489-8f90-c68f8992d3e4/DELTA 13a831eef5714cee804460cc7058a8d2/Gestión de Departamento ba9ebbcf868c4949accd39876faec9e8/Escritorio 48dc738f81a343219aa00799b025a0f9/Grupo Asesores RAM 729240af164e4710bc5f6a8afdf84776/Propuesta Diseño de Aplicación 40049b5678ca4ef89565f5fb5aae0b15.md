# Propuesta Diseño de Aplicación

[https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FbBoLNzlrideevYMrwQ18vl%2FPrototipo-RAM%3Fnode-id%3D0%3A1%26t%3Dm2YNhsKIyBLRAMXG-0](https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FbBoLNzlrideevYMrwQ18vl%2FPrototipo-RAM%3Fnode-id%3D0%3A1%26t%3Dm2YNhsKIyBLRAMXG-0)

## Enlace:

[https://www.figma.com/file/bBoLNzlrideevYMrwQ18vl/Prototipo-RAM?node-id=0%3A1&t=m2YNhsKIyBLRAMXG-0](https://www.figma.com/file/bBoLNzlrideevYMrwQ18vl/Prototipo-RAM?node-id=0%3A1&t=m2YNhsKIyBLRAMXG-0)