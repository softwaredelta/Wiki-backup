# Política de puntualidad y respeto de tiempos

Descripción: Como miembro del departamento existe la responsabilidad individuald de llegar a tiempo a las juntas y reuniones acordadas. El tiempo de reunión establecido debe de respetarse, es decir, no ser ni menos ni más. Esto es solo permisible si todos los reunidos deciden lo contrario.
Número: 2