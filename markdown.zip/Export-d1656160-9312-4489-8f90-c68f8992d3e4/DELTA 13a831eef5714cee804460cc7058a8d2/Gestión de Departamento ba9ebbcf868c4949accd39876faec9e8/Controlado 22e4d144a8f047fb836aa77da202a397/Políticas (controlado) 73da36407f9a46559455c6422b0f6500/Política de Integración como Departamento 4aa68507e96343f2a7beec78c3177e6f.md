# Política de Integración como Departamento

Descripción: Como miembro de un proyecto particular del departamento, hay un compromiso a estar integrados con todo el departamento Delta. Es decir, el departamento Delta es un departamento unido, no dos equipos completamente separados. Todos somos compañeros y una misma red de apoyo.
Número: 5