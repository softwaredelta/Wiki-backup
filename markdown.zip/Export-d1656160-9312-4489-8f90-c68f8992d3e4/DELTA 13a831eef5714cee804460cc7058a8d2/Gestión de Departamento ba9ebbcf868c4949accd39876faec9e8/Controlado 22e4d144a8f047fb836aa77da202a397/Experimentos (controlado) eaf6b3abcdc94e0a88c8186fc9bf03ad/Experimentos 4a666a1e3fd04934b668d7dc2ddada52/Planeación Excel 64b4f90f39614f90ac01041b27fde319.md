# Planeación Excel

Estado: En progreso
Fecha inicio: February 18, 2023
Grupo: Departamento
Tags: monitorización

**Objetivo:** Llevar una organización con entregables semanales para la etapa de Planeación, Análisis y Diseño.

**Involucrados:** Program Manager actual (Mónica).

**Proceso:**

1. Se crea un calendario grupal al igual que un calendario para cada proyecto.
2. El formato es en Excel y se calendariza semana a semana.
3. Cada equipo puede usar el formato proveído por el PM para estimar sus horas y asignar a personas a cada tarea.
4. El PM se encarga de ver que todo esté yendo al día con cada equipo.
5. El PM sugiere un formato para cada entregable pero el salón entero debe de estar de acuerdo antes de proceder.

**Control de cambios:**

| ¿Quién? | Fecha | Modificación | Versión |
| --- | --- | --- | --- |
| Mónica | 19/02/23 | Creación del experimento | v1.0 |
|  |  |  |  |
|  |  |  |  |