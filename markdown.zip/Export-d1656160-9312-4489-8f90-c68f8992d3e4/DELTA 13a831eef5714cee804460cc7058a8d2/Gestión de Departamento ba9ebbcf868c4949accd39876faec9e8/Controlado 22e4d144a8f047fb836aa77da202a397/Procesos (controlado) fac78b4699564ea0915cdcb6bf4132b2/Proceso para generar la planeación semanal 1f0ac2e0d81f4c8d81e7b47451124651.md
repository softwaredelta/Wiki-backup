# Proceso para generar la planeación semanal

Número: 4
Propósito: Tener un backlog de tasks a realizar para cada proyecto en el que se pueda estimar tiempo y esfuerzo, se pueda representar de manera gráfica dicho esfuerzo, se asignen las tareas y se mida el progreso semanal.
Tags: Monitorización, Todo

********************************************Objetivos específicos:********************************************

1. Objetivo: [Descripción]

**************************Definiciones:**************************

1. Palabra: [Definición]

******************Casos de uso relevantes:******************

1. Caso de uso: [Descripción]

**************************************Actores relevantes:**************************************

1. Actor: : [Descripción]

****************************************Entradas de proceso:****************************************

1. [Descripción de entrada]

**************************************Salidas de proceso:**************************************

1. [Descripción de salida]

**********************************Pasos de proceso:**********************************

1. [Paso uno]

********************************************Notas y sugerencias para el futuro:********************************************

1. [Nota]

********Historia de autores y cambios:********

1. Fecha Nombre

Ejemplo: 2023/02/23 Mónica Ayala: Definición inicial del proceso