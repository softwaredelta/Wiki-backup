# Minutas para RAM

Grupo: RAM
Tags: monitorización
URL: https://www.notion.so/Minutas-RAM-8eb0df1338be45df8384d3b065c15fd6?pvs=4