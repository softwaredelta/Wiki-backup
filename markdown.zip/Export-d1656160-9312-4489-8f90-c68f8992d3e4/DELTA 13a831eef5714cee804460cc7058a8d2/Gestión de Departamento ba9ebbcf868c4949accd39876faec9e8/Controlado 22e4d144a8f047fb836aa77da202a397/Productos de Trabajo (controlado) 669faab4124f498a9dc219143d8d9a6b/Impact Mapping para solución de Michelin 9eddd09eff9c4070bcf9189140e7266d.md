# Impact Mapping para solución de Michelin

Grupo: Michelin
Tags: external, gestion
URL: https://www.figma.com/file/YPV5buP6Al9ALf9xdybqT6/Impact-Mapping?node-id=0%3A1&t=LQ47FmYMlRbUSNUN-0