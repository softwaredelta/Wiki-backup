# Formato de procesos

Grupo: Departamento
Tags: formato, template

********************************************Objetivos específicos:********************************************

1. Objetivo: [Descripción]

**************************Definiciones:**************************

1. Palabra: [Definición]

******************Casos de uso relevantes:******************

1. Caso de uso: [Descripción]

**************************************Actores relevantes:**************************************

1. Actor: : [Descripción]

****************************************Entradas de proceso:****************************************

1. [Descripción de entrada]

**************************************Salidas de proceso:**************************************

1. [Descripción de salida]

**********************************Pasos de proceso:**********************************

1. [Paso uno]

********************************************Notas y sugerencias para el futuro:********************************************

1. [Nota]

********Historia de autores y cambios:********

1. Fecha Nombre

Ejemplo: 2023/02/23 Mónica Ayala: Definición inicial del proceso

**NOTAS:**

**Según el CMMI se dice que:**

Un proceso definido establece claramente lo siguiente:
•	 Propósito.
•	 Entradas.
•	 Criterios de entrada.
•	 Actividades.
•	 Roles.
•	 Medidas.
•	 Pasos de verificación.
•	 Salidas.
•	 Criterios de salida.

Una diferencia crítica entre un proceso gestionado y un proceso definido es el alcance de aplicación de las descripciones del proceso, de los estándares y de los procedimientos.

Para un proceso gestionado, las descripciones del proceso, los estándares y los procedimientos son aplicables a un proyecto, grupo o función de la organización concretos. Como resultado, los procesos gestionados de dos proyectos de una organización pueden ser diferentes.