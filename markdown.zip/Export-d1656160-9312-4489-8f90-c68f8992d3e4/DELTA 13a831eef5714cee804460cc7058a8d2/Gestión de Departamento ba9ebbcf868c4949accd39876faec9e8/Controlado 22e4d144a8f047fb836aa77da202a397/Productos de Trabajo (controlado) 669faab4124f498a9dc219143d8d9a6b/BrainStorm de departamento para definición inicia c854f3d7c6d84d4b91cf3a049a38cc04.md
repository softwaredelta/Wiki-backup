# BrainStorm de departamento para definición inicial de Acuerdos del Departamento

Grupo: Departamento
Tags: external
URL: https://www.figma.com/file/Fc4oQqmy2sco7dFfveXxvM/Acuerdos-de-Equipo?node-id=0%3A1&t=7g6Nru8mLOI16bHb-0