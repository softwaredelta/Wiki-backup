# Impact Mapping para solución de Asesores Grupo RAM

Grupo: RAM
Tags: external, requisitos
URL: https://www.figma.com/file/84B4nmkuIgJskXHJhHZYt8/IMPACT-MAPPING-RAM?node-id=0%3A1&t=cc8EgTWwzmk6Nant-0