# Gestión de Departamento

Para cualquier documento o trabajo en proceso, utiliza:

[Escritorio](Gestio%CC%81n%20de%20Departamento%20ba9ebbcf868c4949accd39876faec9e8/Escritorio%2048dc738f81a343219aa00799b025a0f9.md)

Para los activos de proceso, evidencias de trabajo, y componentes definidos, utiliza:

[Controlado](Gestio%CC%81n%20de%20Departamento%20ba9ebbcf868c4949accd39876faec9e8/Controlado%2022e4d144a8f047fb836aa77da202a397.md)