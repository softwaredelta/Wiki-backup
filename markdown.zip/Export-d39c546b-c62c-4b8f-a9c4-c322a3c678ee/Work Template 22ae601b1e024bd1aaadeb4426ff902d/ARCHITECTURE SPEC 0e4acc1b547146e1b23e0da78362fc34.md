# ARCHITECTURE SPEC

Accountable: Jordana Betancourt Menchaca
Blocked by: FR%20SPEC%2015b7d767baaa4f2f95350cd44524ba58.md, NFR%20SPEC%20a228595e7a0c44a8b5a37d23a9bff521.md
Informed: Ian García González
Plan: March 3, 2023 → March 7, 2023
Responsible: Kenny Eduard Vercaemer González
Status: Needs Review