# 3

Acrónimos: OPD, SG1
Completado: No
Prácticas: Establish and maintain the tailoring criteria and guidelines for the organization's set of standard processes.