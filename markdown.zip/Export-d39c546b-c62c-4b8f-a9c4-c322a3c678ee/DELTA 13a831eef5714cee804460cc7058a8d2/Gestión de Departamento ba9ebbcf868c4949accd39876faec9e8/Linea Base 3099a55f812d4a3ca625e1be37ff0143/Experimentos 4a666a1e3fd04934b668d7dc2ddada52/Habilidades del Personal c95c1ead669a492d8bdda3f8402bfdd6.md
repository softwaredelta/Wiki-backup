# Habilidades del Personal

Estado: En progreso
Fecha evaluación: March 17, 2023
Fecha inicio: March 6, 2023
Grupo: Departamento
Hipótesis: Tener un registro de las habilidades y conocimientos para ver el crecimiento del personal.
Responsable(s): Jorge Guerrero Díaz, Jordana Betancourt Menchaca
Tags: Bienestar, Monitorización
¿Se probó la hipótesis?: No

## Involucrados:

1. Program Managers
2. Team Members (Deltalin y Deltaram)

## Descripción**:**

1. Registrar las habilidades iniciales del personal Delta
    1. Utilizando un excel cada individuo se califica
    2. Definir un sistema de niveles en base a comprensión e intensión
2. Medir el crecimiento de cada individuo en base a la comprensión y tiempo invertido y permitir una autogestión y análisis personal
3. Tener un historial de objetivos y ver como se van logrando

[Personal](https://docs.google.com/spreadsheets/d/1LhaZhQyQWytCVCF5mt17HllIMMBmFdiMu2bsCWZ6iA0/edit?usp=drivesdk)

## **Criterios de éxito**

Ver que el personal realiza una autoevaluación, y ver si los niveles incrementan durante las semanas.

## **Resultado**

## **Control de cambios:**

[Manejo de versiones](Habilidades%20del%20Personal%20c95c1ead669a492d8bdda3f8402bfdd6/Manejo%20de%20versiones%20d12c2e317508412abf9a7166b21b68ab.md)