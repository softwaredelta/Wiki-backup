# Retrospectiva semanal

Estado: En progreso
Fecha evaluación: March 10, 2023
Fecha inicio: March 3, 2023
Grupo: Michelin
Hipótesis: Al terminar la semana, evaluar en que se trabajo y como se trabajo para detectar fallas y buscar mejoras para que la siguiente semana sea mejor
Responsable(s): Arisbeth Aguirre Pontaza
Tags: Integración, Monitorización, No definido
¿Se probó la hipótesis?: No

## Involucrados

1. Team Members de Michelin
2. Informed: PMs

## Descripción

[Retrospectiva Semanal](../../Escritorio%2048dc738f81a343219aa00799b025a0f9/Deltalin%207a51664e3c0442da8e7c5dcbfc4524f2/Proceso%20para%20retrospectivas%20(semanal)%20ff7c9fb3a4554eaaba7bb0e5c7bdbc69.md)

## **Criterios de éxito**

1. Actualización en la sección de acuerdos de trabajo dentro de Deltalin.

## **Resultado**

## Historial **de cambios**

[Manejo de versiones (2)](Retrospectiva%20semanal%2040b356e80a6948f9acb8ddbd119bc217/Manejo%20de%20versiones%20(2)%205197814f41724cccb451d9af7c7d484c.md)

###