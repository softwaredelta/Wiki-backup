# Política de reuniones departamentales

Descripción: Semanalmente se tendrán reuniones departamentales de mínimo una hora para avisar de lo que ha estado pasando y como van los equipos.
Número: 8
Tipo: Plan departamental