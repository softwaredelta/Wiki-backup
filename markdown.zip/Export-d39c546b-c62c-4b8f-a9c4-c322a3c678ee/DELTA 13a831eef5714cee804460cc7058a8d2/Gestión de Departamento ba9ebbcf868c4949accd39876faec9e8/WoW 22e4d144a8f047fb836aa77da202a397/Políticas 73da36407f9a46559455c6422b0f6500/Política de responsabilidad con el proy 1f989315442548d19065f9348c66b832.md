# Política de responsabilidad con el proy

Descripción: Se espera que los miembros reconozcan cuando sus actividades dejan de aportar al proyecto y que tengan la madurez para comunicar y buscar otras actividades que puedan aportar al equipo.
Número: 13