# Política de forma de trabajo con el Calendario de Planeación

Descripción: Como miembro del departamento me comprometo a revisar diariamente el avance de mi proyecto en el calendario de planeación, actualizarlo de ser necesario y comprender mi responsabilidad con las tareas que se me sean asignadas.
Número: 7
Tipo: Plan departamental