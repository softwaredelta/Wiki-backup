# Política de comunicación en caso de imprevisto

Descripción: Como miembro del departamento en caso de faltar a una reunión, responsabilidad o tener un impedimento notificarlo por los canales de comunicación (WhatsApp, Discord)
Número: 3
Tipo: Convivencia