# Política de comprensión y extensión de ayuda hacia los miembros de Delta.

Descripción: Se espera que los miembros que cuenten con conocimientos sobre las distintas tecnologías compartan sus conocimientos con amabilidad, comprensión y respeto en caso de que alguien les pida consejo.
Número: 10