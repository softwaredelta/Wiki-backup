# Política del reconocimiento de roles y no puestos.

Descripción: Reconocer los roles de los distintos miembros de los equipos, es decir, reconocer que cada miembro de Delta tiene distinta responsabilidad. Sin embargo, reconocer que no somos “jefes” ni seguimos una jerarquía estricta: son roles, no puestos. Aparte, los roles son cambiantes.
Número: 12