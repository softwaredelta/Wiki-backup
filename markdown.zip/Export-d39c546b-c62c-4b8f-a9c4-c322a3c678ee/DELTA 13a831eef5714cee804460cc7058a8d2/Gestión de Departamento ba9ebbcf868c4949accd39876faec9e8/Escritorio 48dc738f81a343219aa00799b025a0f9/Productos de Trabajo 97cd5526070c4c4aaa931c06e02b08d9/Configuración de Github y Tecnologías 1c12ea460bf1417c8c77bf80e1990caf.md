# Configuración de Github y Tecnologías

Assign: Emiliano Vásquez Olea
Description: Write a useful description of the item
Proyecto: Deltalin
Status: In progress

## Configuración actual de repositorio de Michelin

- Limitado el acceso a rama Main
- Agrega .gitignore de Node (Aplicación Web)

---

[Manejo de Versiones](Configuracio%CC%81n%20de%20Github%20y%20Tecnologi%CC%81as%201c12ea460bf1417c8c77bf80e1990caf/Manejo%20de%20Versiones%2024d78a5df8e14ac282691d982b55ca1b.md)