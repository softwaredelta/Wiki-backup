# Impact Mapping para Solución

Assign: Rodrigo Muñoz Guerrero
Description: Figma dónde se realizó proceso de impact mapping para identificar soluciones
Proyecto: RAM
Status: Done
Tags: Fase: Análisis
Tipo de Producto: Impact Mapping
URL: https://www.figma.com/file/84B4nmkuIgJskXHJhHZYt8/IMPACT-MAPPING-RAM?node-id=0%3A1&t=cc8EgTWwzmk6Nant-0

---

[Manejo de Versiones](Impact%20Mapping%20para%20Solucio%CC%81n%20164c6e0d0f9c4e8daa1028d120bd6acc/Manejo%20de%20Versiones%2010b3aac5410846b2b1805dfaca4d61db.md)