# Calendario en Google Sheets

Assign: Monica Ayala, Olivia Araceli Morales Quezada
Description: Planeación en Google Sheets
Proyecto: Departamento
Status: Not started
Tags: Gestión
Tipo de Producto: Planeación Calendario
URL: https://docs.google.com/spreadsheets/u/1/d/1HZrmGn_cKk6wFRo-s0_ZsMpfMxow5rXOvBgHTPeQA0U/edit#gid=27041093

Link a la planeación elaborada en Google Sheets.

[Calendario: Planeación General](https://docs.google.com/spreadsheets/d/1HZrmGn_cKk6wFRo-s0_ZsMpfMxow5rXOvBgHTPeQA0U/edit#gid=27041093)

Link a la página que lo define como experimento:

[Planeación Google Sheets](../../Linea%20Base%203099a55f812d4a3ca625e1be37ff0143/Experimentos%204a666a1e3fd04934b668d7dc2ddada52/Planeacio%CC%81n%20Google%20Sheets%2064b4f90f39614f90ac01041b27fde319.md)

Definición del proceso: 

[Proceso para generar la planeación semanal](../../WoW%2022e4d144a8f047fb836aa77da202a397/Procesos%20fac78b4699564ea0915cdcb6bf4132b2/Proceso%20para%20generar%20la%20planeacio%CC%81n%20semanal%201f0ac2e0d81f4c8d81e7b47451124651.md)