# Formato Validación de Propuesta

Assign: Rodrigo Muñoz Guerrero, Monica Ayala
Description: Formato para firma de validación de propuesta
Proyecto: RAM
Status: Done
Tags: Fase: Diseño
Tipo de Producto: Formato
URL: https://docs.google.com/document/d/1wx5LKQJvUJMOdyQ2ChuB9vqvR2xJOc_bIbPTxnhueHc/edit

[https://docs.google.com/document/d/1wx5LKQJvUJMOdyQ2ChuB9vqvR2xJOc_bIbPTxnhueHc/edit](https://docs.google.com/document/d/1wx5LKQJvUJMOdyQ2ChuB9vqvR2xJOc_bIbPTxnhueHc/edit)

---

[Manejo de Versiones](Formato%20Validacio%CC%81n%20de%20Propuesta%2047844df7c06b443788aee052b27920d9/Manejo%20de%20Versiones%20ee24853c809e4f52bbe9c32fc8cc194f.md)