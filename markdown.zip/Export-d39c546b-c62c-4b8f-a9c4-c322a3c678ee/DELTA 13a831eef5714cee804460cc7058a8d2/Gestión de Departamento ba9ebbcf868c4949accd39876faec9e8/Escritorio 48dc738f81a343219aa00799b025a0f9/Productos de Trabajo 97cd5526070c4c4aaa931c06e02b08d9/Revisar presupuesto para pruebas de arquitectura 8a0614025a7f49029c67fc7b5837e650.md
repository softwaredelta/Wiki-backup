# Revisar presupuesto para pruebas de arquitectura

Assign: Kenny Eduard Vercaemer González, Rodrigo Muñoz Guerrero
Description: Confirmar si se tiene presupuesto para ejecutar pruebas de arquitectura verdaderas con la infraestructura real
Proyecto: RAM
Status: Not started