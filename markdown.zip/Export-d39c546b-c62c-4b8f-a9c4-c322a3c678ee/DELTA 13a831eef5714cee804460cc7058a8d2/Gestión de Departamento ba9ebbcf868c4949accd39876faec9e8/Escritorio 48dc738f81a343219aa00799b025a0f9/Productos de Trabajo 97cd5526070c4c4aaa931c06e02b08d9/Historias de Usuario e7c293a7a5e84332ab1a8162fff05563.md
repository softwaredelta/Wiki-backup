# Historias de Usuario

Assign: Rodrigo Muñoz Guerrero, Jordana Betancourt Menchaca, Fermín Méndez García, Kenny Eduard Vercaemer González
Description: Especificación de historias de usuario para Grupo RAM
Proyecto: RAM
Status: Review
Tags: Fase: Diseño
Tipo de Producto: Historias de Usuario
URL: https://docs.google.com/spreadsheets/d/1ijuDjWE1UxtgRoeekSNPiPbB5AByjpyzYiSnwvLzQ4Q/edit?usp=share_link

[https://docs.google.com/spreadsheets/d/1ijuDjWE1UxtgRoeekSNPiPbB5AByjpyzYiSnwvLzQ4Q/edit?usp=share_link](https://docs.google.com/spreadsheets/d/1ijuDjWE1UxtgRoeekSNPiPbB5AByjpyzYiSnwvLzQ4Q/edit?usp=share_link)

---

[Manejo de Versiones](Historias%20de%20Usuario%20e7c293a7a5e84332ab1a8162fff05563/Manejo%20de%20Versiones%200062e198cd4e4e65b4953b36ad71880a.md)