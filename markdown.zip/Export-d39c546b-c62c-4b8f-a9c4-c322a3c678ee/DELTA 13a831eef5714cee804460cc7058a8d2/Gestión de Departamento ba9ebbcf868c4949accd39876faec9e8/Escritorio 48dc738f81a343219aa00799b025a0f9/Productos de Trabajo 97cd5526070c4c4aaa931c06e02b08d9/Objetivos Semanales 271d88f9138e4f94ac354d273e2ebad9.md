# Objetivos Semanales

Assign: Jordana Betancourt Menchaca, Rodrigo Muñoz Guerrero, Reno, Ana Karen López Baltazar, Alejandro Mtz. Luna, Erick Alfredo García Huerta, Ian García González, José Ángel Rico Mendieta, Fermín Méndez García, Diego Emilio Barrera Hernández
Description: Write a useful description of the item
Proyecto: RAM
Status: Ongoing
Tags: Misc
Tipo de Producto: Objetivos Semanales
URL: https://www.figma.com/file/NpoL0YUsxMnNUHW6PElikS/Objetivos-semanales?node-id=0%3A1&t=xPtoBviW8FUp8o0r-1

[https://www.figma.com/file/NpoL0YUsxMnNUHW6PElikS/Objetivos-semanales?node-id=0%3A1&t=xPtoBviW8FUp8o0r-1](https://www.figma.com/file/NpoL0YUsxMnNUHW6PElikS/Objetivos-semanales?node-id=0%3A1&t=xPtoBviW8FUp8o0r-1)

[Manejo de Versiones](Objetivos%20Semanales%20271d88f9138e4f94ac354d273e2ebad9/Manejo%20de%20Versiones%20a5c1086dddd147b4a42841e2f0af65cf.md)