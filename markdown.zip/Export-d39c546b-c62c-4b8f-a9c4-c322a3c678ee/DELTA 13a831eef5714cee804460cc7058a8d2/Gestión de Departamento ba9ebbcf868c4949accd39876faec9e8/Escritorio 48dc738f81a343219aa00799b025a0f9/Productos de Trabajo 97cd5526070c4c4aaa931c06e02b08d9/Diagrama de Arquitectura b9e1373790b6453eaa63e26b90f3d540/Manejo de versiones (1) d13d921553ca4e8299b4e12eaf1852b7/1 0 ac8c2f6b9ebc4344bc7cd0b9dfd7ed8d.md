# 1.0

Autor: Emiliano Vásquez Olea
Descripción: Creación de la primera versión de la arquitectura
Revisado: Reviewed
Revisado por:

![Diagrama de Arquitectura.png](1%200%20ac8c2f6b9ebc4344bc7cd0b9dfd7ed8d/Diagrama_de_Arquitectura.png)

## Manejo de versiones