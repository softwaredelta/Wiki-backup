# Propuesta para el Systems Engineering Management Plan

Assign: Monica Ayala, Olivia Araceli Morales Quezada
Description: Propuesta para el SEMP
Proyecto: Departamento
Status: Not started
Tags: Maps
Tipo de Producto: Process Map

# Systems Engineering Management Plan

---

[Manejo de Versiones](Propuesta%20para%20el%20Systems%20Engineering%20Management%20P%2042cb21d3dfd24aca908d110f23963663/Manejo%20de%20Versiones%2056e36856363a4e91bc5980a69dc0ad52.md)