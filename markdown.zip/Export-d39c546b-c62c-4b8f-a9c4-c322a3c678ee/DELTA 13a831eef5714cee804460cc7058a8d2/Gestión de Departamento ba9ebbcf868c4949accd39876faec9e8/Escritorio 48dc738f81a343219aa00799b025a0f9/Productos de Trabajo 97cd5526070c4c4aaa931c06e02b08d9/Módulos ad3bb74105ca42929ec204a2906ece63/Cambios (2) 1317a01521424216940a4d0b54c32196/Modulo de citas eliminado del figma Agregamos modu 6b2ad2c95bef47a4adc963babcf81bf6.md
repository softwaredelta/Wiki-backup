# Modulo de citas eliminado del figma. Agregamos modulo de pagina web movil al figma

Autor: Andres
Fecha: March 2, 2023
Versión: 1.2