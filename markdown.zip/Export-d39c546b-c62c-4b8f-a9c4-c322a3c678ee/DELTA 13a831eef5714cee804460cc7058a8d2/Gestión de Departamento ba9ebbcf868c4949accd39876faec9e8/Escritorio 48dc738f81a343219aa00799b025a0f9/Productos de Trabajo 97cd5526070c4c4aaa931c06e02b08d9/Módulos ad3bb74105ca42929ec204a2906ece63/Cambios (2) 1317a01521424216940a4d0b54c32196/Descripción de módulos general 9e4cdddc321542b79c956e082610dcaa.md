# Descripción de módulos general

Autor: Jorge Guerrero Díaz
Versión: 1.1