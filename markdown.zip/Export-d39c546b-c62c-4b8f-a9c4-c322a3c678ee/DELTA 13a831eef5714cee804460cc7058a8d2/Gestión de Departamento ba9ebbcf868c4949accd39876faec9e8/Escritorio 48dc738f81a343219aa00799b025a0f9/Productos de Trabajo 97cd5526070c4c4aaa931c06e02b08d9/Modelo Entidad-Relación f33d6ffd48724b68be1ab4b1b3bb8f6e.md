# Modelo Entidad-Relación

Assign: Alejandro Mtz. Luna, José Ángel Rico Mendieta, Emiliano Vásquez Olea, Reno, Rodrigo Muñoz Guerrero
Description: Diseño del Modelo Entidad Relación del proyecto
Proyecto: RAM
Status: In progress
Tags: Fase: Diseño
Tipo de Producto: MER
URL: https://excalidraw.com/#room=51eda3dc6b0eb41332c2,9axsS7Sh7PTaIJ1rykVK7Q

[https://excalidraw.com/#room=51eda3dc6b0eb41332c2,9axsS7Sh7PTaIJ1rykVK7Q](https://excalidraw.com/#room=51eda3dc6b0eb41332c2,9axsS7Sh7PTaIJ1rykVK7Q)