# Impact Mapping

Assign: Jorge Guerrero Díaz, Arisbeth Aguirre Pontaza, Fabián Enrique Avilés Cortés, Ricardo Nuñez Alanis, Cristian Rico, Emiliano Vásquez Olea, Andres, Olivia Araceli Morales Quezada
Description: El Impact Mapping nos permite analizar quiénes son los actores involucrados en la necesidad, qué acciones llevan a cabo y nosotros como equipo de desarrollo establecemos un objetivo y los puntos a “atacar”.
Proyecto: Deltalin
Status: Done
Tags: Maps

[https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FYPV5buP6Al9ALf9xdybqT6%2FImpact-Mapping%3Fnode-id%3D0%3A1%26t%3DM1tvWdFvhcdvLcm4-1](https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FYPV5buP6Al9ALf9xdybqT6%2FImpact-Mapping%3Fnode-id%3D0%3A1%26t%3DM1tvWdFvhcdvLcm4-1)

## ********Historial de cambios:********

[Manejo de versiones (2)](Impact%20Mapping%20140cf84ff0ca47069c76419bdab3b720/Manejo%20de%20versiones%20(2)%20e0b5e7dbbf85412ba27b55e928a96dac.md)