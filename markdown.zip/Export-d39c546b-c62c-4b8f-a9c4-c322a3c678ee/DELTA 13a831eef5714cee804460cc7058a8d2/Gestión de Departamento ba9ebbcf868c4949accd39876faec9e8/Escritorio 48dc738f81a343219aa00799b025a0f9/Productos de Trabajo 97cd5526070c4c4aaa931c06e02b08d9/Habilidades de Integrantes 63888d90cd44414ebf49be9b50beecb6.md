# Habilidades de Integrantes

Assign: Jordana Betancourt Menchaca, Reno, Ian García González, Ana Karen López Baltazar, José Ángel Rico Mendieta, Alejandro Mtz. Luna, Fermín Méndez García, Rodrigo Muñoz Guerrero, Erick Alfredo García Huerta, Diego Emilio Barrera Hernández, Kenny Eduard Vercaemer González
Description: Captura de habilidades de integrantes del equipo RAM
Proyecto: RAM
Status: In progress
Tags: Misc
Tipo de Producto: Skill Map
URL: https://docs.google.com/spreadsheets/d/1xFHs5PX02kNhiRXNv3LuX5OtFi42sEvD95QB9KKQmcI/edit?usp=sharing

---

[Skills integrantes RAM](https://docs.google.com/spreadsheets/d/1xFHs5PX02kNhiRXNv3LuX5OtFi42sEvD95QB9KKQmcI/edit?usp=drivesdk)

[Manejo de Versiones](Habilidades%20de%20Integrantes%2063888d90cd44414ebf49be9b50beecb6/Manejo%20de%20Versiones%20cab70480d3f345a48b9d811b8f096c4c.md)