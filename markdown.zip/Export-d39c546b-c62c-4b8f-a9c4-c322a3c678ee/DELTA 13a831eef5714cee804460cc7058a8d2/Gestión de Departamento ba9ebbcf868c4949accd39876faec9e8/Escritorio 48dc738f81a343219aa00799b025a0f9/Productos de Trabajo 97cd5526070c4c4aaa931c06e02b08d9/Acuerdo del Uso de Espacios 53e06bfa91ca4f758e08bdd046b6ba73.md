# Acuerdo del Uso de Espacios

Assign: Olivia Araceli Morales Quezada
Description: Tener una negociación con los PMs del otro departamento para llegar un acuerdo sobre el uso del Salón 2001.
Proyecto: Departamento
Status: Ongoing
Tags: Acuerdos, External

TODO:

- [ ]  Contactar a los PMs.
- [ ]  Acordar un horario.
- [ ]  Considerar a los profesores.
- [ ]  Preparar distintos escenarios y argumentos para negociar.