# Diagramas de Arquitectura

Assign: Kenny Eduard Vercaemer González, Ian García González, Jordana Betancourt Menchaca
Description: Diagramas de arquitectura. Se describe la arquitectura general del sistema. Se describe la arquitectura de load balancing del backend.
Proyecto: RAM
Status: Done
Tags: Fase: Diseño
Tipo de Producto: Architecture Diagram
URL: https://lucid.app/lucidchart/2831c9cf-5829-4b57-a78b-8b52a0d55129/edit?viewport_loc=-129%2C-20%2C3002%2C1370%2C0_0&invitationId=inv_3b5bd7af-1389-4270-b097-fd9d7fdeda29

---