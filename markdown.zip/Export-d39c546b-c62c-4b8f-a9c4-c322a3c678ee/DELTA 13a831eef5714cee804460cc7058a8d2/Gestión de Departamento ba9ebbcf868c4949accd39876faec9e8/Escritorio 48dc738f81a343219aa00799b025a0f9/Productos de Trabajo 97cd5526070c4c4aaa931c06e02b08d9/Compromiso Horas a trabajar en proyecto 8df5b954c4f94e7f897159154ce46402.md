# Compromiso Horas a trabajar en proyecto

Assign: Jordana Betancourt Menchaca
Description: Write a useful description of the item
Proyecto: RAM
Status: Review
Tags: Gestión

[Compromiso Horas de Trabajos](https://docs.google.com/document/d/1Cm_L731Q-qedDNed79F-2EhqjF3Fbp7v/edit?usp=sharing&ouid=110807911015810754890&rtpof=true&sd=true)

---

[Manejo de Versiones](Compromiso%20Horas%20a%20trabajar%20en%20proyecto%208df5b954c4f94e7f897159154ce46402/Manejo%20de%20Versiones%20b0d7bdb7e5424fe69b2a6b34e37afa61.md)