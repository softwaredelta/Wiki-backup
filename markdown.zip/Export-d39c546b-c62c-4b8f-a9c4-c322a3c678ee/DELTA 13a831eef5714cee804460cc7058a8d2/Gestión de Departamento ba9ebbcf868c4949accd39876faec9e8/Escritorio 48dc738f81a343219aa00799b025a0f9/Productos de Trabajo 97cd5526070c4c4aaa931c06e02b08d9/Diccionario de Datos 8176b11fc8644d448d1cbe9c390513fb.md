# Diccionario de Datos

Assign: Cristian Rico, Andres, Fabián Enrique Avilés Cortés
Proyecto: Deltalin
Status: Not started

## ********Historial de cambios:********

[Manejo de versiones (2)](Diccionario%20de%20Datos%208176b11fc8644d448d1cbe9c390513fb/Manejo%20de%20versiones%20(2)%2084a11dc677c4452cb3499620c5069e93.md)