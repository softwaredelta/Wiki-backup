# Planear Presentación Cierre de Etapa

Assign: Olivia Araceli Morales Quezada, Mónica Andrea Ayala Marrero
Description: Planear la presentación para el cierre de la primera etapa.
Proyecto: Departamento
Status: Ongoing
Tags: Docs, Fase: Análisis
Tipo de Producto: Presentación

Preguntar a los skateholder de la presentación:

- ¿Para quién va a ser la presentación?Libertad de invitar si o si  socios y profesores.
- ¿Cuánto va a durar? Breve para dar más tiempo a retro, media a 25 min.
- ¿Qué esperan de nosotros? Estado actual del departamento, de que tamaño son los proyecto presupuesto y plan de entrega, necesidad, objetivos y propuesta de soluciones. Ver la evaluación de la forma de trabajo.
- ¿Qué les gustaría ver de nosotros? Una presentación que sea de nosotros, estar gratamente sorprendido. Lalo: Que me dé esperanza.
- Ñ
- ¿Cómo podemos superar sus expectativas ese día? o ¿Causar?(No se si es una buena pregunta) Es una pregunta para nosotros.

Es nuestra presentación, hagámosla nuestra. 

Unos contaron un cuento. Que se vea que es nuestra profesionalmente. 

Definir:

- [ ]  Herramienta de entrega. (Canvas, Genially, Slides, etc…).
- [ ]  Estilo de la presentación.
- [ ]  Contenidos.
- [ ]  Ponentes.

## Links Relevantes

Presentaciones Efectivas por El Padrino:

[Presentaciones efectivas 2](https://docs.google.com/presentation/d/1EbDGrR_LKSb8ltAeAaoda0tJcphdyUVnZK82XTa1qwM/edit?usp=drivesdk)

Proceso de Taro:

[https://taro-it.github.io/docs/procesos/P04-proceso-de-presentaciones](https://taro-it.github.io/docs/procesos/P04-proceso-de-presentaciones)