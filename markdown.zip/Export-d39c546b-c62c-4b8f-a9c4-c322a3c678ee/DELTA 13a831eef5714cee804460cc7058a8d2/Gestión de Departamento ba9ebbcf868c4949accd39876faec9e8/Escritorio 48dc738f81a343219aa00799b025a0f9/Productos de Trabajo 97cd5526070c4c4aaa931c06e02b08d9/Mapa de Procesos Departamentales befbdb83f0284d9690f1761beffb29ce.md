# Mapa de Procesos Departamentales

Assign: Kenny Eduard Vercaemer González
Description: Mapa de todos los procesos y entregables del departamento.
Proyecto: Departamento
Status: In progress
Tags: Procesos
Tipo de Producto: Process Map
URL: https://lucid.app/lucidchart/373af610-b2e9-4416-9e50-a29e3a89663b/edit?viewport_loc=77%2C69%2C3028%2C1381%2C0_0&invitationId=inv_9a4f5168-6af8-4270-9231-4ed5697f7f01

[https://lucid.app/lucidchart/373af610-b2e9-4416-9e50-a29e3a89663b/edit?viewport_loc=77%2C69%2C3028%2C1381%2C0_0&invitationId=inv_9a4f5168-6af8-4270-9231-4ed5697f7f01](https://lucid.app/lucidchart/373af610-b2e9-4416-9e50-a29e3a89663b/edit?viewport_loc=77%2C69%2C3028%2C1381%2C0_0&invitationId=inv_9a4f5168-6af8-4270-9231-4ed5697f7f01)

---

[Manejo de Versiones](Mapa%20de%20Procesos%20Departamentales%20befbdb83f0284d9690f1761beffb29ce/Manejo%20de%20Versiones%2045f78b0e9c9d45ca92ab60402835c2a5.md)