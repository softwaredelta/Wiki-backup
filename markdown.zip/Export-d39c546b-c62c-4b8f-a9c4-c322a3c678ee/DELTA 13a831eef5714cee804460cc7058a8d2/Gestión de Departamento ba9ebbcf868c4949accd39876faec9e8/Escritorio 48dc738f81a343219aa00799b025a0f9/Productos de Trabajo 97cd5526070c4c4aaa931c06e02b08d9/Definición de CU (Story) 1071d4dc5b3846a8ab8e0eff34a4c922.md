# Definición de CU (Story)

Proyecto: Deltalin
Status: Review
Tags: Docs

# Excel de Backlog completo:

[Formato de Requisitos Funcionales - Michelin](https://docs.google.com/spreadsheets/d/1Eme0YIj9GZCc3QCBQehDUGZIgS7aTilZx4oUy35dcGc/edit?usp=drivesdk)

## ********Historial de cambios:********

[Manejo de versiones (2)](Definicio%CC%81n%20de%20CU%20(Story)%201071d4dc5b3846a8ab8e0eff34a4c922/Manejo%20de%20versiones%20(2)%203b4dc433bdf84809a37c2b78d70e86ea.md)