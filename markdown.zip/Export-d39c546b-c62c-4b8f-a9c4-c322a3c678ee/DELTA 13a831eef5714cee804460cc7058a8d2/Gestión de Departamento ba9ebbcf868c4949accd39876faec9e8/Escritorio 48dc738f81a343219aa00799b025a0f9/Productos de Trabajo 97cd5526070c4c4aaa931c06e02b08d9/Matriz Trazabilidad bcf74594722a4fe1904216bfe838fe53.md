# Matriz Trazabilidad

Assign: Andres, Cristian Rico
Description: Write a useful description of the item
Proyecto: Deltalin
Status: Not started
Tags: Docs

# Título

Este es un producto de trabajo del departamento, asegúrate de iniciar la tabla de versiones al terminar.

Cada vez que se genera una versión, debes copiar el contenido del documento y agregarlo a la entrada correspondiente en la tabla de versiones.

Cada cambio deberá ser revisado por algún otro responsable.

Asegúrate también de asignar el tipo de producto de trabajo en las propiedades de arriba, si no existe puedes crear una. Estos tipos de producto estarán relacionados 1 a 1 en el mapa de procesos de la organización.

---

[Manejo de Versiones](Matriz%20Trazabilidad%20bcf74594722a4fe1904216bfe838fe53/Manejo%20de%20Versiones%20a341d76c51884d8280b945e964a7ef0d.md)