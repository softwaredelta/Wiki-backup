# Procesos de Mejora Continua y Seguimiento

Assign: Jorge Guerrero Díaz, Arisbeth Aguirre Pontaza
Description: PMC del CMMI 
Proyecto: Deltalin
Status: In progress
Tags: Formatos, Procesos

# Título

Este es un producto de trabajo del departamento, asegúrate de iniciar la tabla de versiones al terminar.

Cada vez que se genera una versión, debes copiar el contenido del documento y agregarlo a la entrada correspondiente en la tabla de versiones.

Cada cambio deberá ser revisado por algún otro responsable.

Asegúrate también de asignar el tipo de producto de trabajo en las propiedades de arriba, si no existe puedes crear una. Estos tipos de producto estarán relacionados 1 a 1 en el mapa de procesos de la organización.

---

[Manejo de Versiones](Procesos%20de%20Mejora%20Continua%20y%20Seguimiento%20f10ab74d6d934a7fab15738ab28c51e8/Manejo%20de%20Versiones%20273654516efa436589f0fa8dd696725a.md)