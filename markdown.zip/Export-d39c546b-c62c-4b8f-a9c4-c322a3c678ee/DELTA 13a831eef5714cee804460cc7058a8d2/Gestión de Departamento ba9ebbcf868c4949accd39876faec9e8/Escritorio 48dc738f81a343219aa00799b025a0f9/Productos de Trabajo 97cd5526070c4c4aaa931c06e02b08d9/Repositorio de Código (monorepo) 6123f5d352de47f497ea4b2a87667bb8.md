# Repositorio de Código (monorepo)

Assign: Kenny Eduard Vercaemer González, Ian García González
Description: Repositorio en GitHub para gestión de todo código para solución de Grupo RAM
Proyecto: RAM
Status: Done
Tags: Fase: Construcción
Tipo de Producto: Repositorio
URL: https://github.com/softwaredelta/GNP

---

[Manejo de Versiones](Repositorio%20de%20Co%CC%81digo%20(monorepo)%206123f5d352de47f497ea4b2a87667bb8/Manejo%20de%20Versiones%205b2c157eb1404b35bf84ca8a1f4dc899.md)