# Guía de Configuración de Ambiente de Desarrollo

Assign: Kenny Eduard Vercaemer González, Jordana Betancourt Menchaca
Description: Manual de miembro de departamento; cómo configurar el ambiente de desarrollo para solución Grupo RAM
Proyecto: RAM
Status: Not started