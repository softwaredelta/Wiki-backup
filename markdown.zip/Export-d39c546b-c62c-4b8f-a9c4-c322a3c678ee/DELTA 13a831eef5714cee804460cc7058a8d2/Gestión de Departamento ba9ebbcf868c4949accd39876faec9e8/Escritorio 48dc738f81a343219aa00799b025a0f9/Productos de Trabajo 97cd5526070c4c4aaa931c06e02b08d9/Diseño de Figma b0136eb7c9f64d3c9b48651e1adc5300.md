# Diseño de Figma

Assign: Jordana Betancourt Menchaca, Ana Karen López Baltazar, Alejandro Mtz. Luna
Description: Prototipo visual inicial 
Proyecto: RAM
Status: Done
Tags: Diseños, Fase: Diseño, Links
Tipo de Producto: UI Design in Figma
URL: https://www.figma.com/file/bBoLNzlrideevYMrwQ18vl/Prototipo-RAM?node-id=0%3A1&t=m2YNhsKIyBLRAMXG-0

Link al diseño en Figma

[Prototipo RAM](https://www.figma.com/file/bBoLNzlrideevYMrwQ18vl/Prototipo-RAM?node-id=0%3A1&t=m2YNhsKIyBLRAMXG-0)