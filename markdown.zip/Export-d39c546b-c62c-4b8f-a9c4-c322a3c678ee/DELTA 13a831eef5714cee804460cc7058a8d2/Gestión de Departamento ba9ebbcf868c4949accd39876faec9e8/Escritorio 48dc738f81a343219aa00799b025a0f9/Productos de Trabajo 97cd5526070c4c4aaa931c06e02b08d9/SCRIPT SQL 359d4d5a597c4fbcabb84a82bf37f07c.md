# SCRIPT SQL

Assign: Andres, Fabián Enrique Avilés Cortés
Description: Write a useful description of the item
Proyecto: Deltalin
Status: Not started

# Título

Este es un producto de trabajo del departamento, asegúrate de iniciar la tabla de versiones al terminar.

Cada vez que se genera una versión, debes copiar el contenido del documento y agregarlo a la entrada correspondiente en la tabla de versiones.

Cada cambio deberá ser revisado por algún otro responsable.

Asegúrate también de asignar el tipo de producto de trabajo en las propiedades de arriba, si no existe puedes crear una. Estos tipos de producto estarán relacionados 1 a 1 en el mapa de procesos de la organización.

---

[Manejo de Versiones](SCRIPT%20SQL%20359d4d5a597c4fbcabb84a82bf37f07c/Manejo%20de%20Versiones%2097a43b39af7f4629ae496ece745bc173.md)