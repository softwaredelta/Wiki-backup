# Diagrama de Arquitectura

Assign: Emiliano Vásquez Olea
Description: Propuestas actuales de tecnologías a utilizar en el desarrollo del proyecto de Michelín. Aún se requieren más componentes.
• Unity
• React
• Tailwind CSS
• Fastify
• mySQL 
Control de Versiones:
• GitHub
• Plastic SCM???
Proyecto: Deltalin
Status: Review
Tags: Maps

![FotoDiagrama2.png](Diagrama%20de%20Arquitectura%20b9e1373790b6453eaa63e26b90f3d540/FotoDiagrama2.png)

## Manejo de versiones

[Manejo de versiones (1)](Diagrama%20de%20Arquitectura%20b9e1373790b6453eaa63e26b90f3d540/Manejo%20de%20versiones%20(1)%20d13d921553ca4e8299b4e12eaf1852b7.md)