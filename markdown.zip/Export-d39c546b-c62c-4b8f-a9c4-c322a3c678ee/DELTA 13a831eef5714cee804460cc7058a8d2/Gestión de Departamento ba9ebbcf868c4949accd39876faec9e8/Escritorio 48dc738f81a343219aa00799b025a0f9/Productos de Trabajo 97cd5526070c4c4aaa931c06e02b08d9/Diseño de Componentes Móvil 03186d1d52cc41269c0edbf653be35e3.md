# Diseño de Componentes Móvil

Assign: Ricardo Nuñez Alanis, Fabián Enrique Avilés Cortés
Description: Write a useful description of the item
Proyecto: Deltalin
Status: Not started

# Título

Este es un producto de trabajo del departamento, asegúrate de iniciar la tabla de versiones al terminar.

Cada vez que se genera una versión, debes copiar el contenido del documento y agregarlo a la entrada correspondiente en la tabla de versiones.

Cada cambio deberá ser revisado por algún otro responsable.

Asegúrate también de asignar el tipo de producto de trabajo en las propiedades de arriba, si no existe puedes crear una. Estos tipos de producto estarán relacionados 1 a 1 en el mapa de procesos de la organización.

---

[Manejo de Versiones](Disen%CC%83o%20de%20Componentes%20Mo%CC%81vil%2003186d1d52cc41269c0edbf653be35e3/Manejo%20de%20Versiones%203fc4b2c5de9749eb94c0632b0199ba36.md)