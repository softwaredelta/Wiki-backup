# Comité de ética

Assign: Olivia Araceli Morales Quezada
Description: Plantear y desarrollar las bases para consolidar un buen a,biete en el departa
Status: Ongoing