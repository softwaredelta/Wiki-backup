# Definición de Requerimientos

Todo el proceso para definir los requerimientos de nuestro proyecto está aquí:

**************************************************************************************************************************************************************************************A partir de todo lo que hagamos aquí, deberemos definir el proceso de departamento para la gestión de requerimientos…**************************************************************************************************************************************************************************************

# Overview; Proceso de definición de requerimientos

1. Identificación de antecedentes
2. Identificación de necesidad
3. Generación de propuestas
4. Definición de acuerdos y acuerdo con socio
5. Definición de requerimientos no funcionales
6. Definición de historias de usuario
7. Definición de requerimientos de interfaz
8. Definición de requerimientos de información

## Requerimientos Funcionales