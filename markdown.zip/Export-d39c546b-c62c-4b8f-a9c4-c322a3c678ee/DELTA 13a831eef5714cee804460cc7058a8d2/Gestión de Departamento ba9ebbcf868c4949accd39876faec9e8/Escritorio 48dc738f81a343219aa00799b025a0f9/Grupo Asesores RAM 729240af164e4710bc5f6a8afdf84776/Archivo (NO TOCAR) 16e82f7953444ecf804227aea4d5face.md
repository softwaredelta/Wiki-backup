# Archivo (NO TOCAR)

### **********************************************************************************************************************************************************************************************************************************************ESTOS SON ARCHIVOS VIEJOS, MIGRADOS A EL NUEVO PRODUCTOS DE TRABAJO O QUE NO SE UTILIZARON, CONSERVAR AQUI EN CASO DE QUE SE NECESITEN, PERO NO TRABAJAR EN ELLOS O PRESTARLES ATENCION**********************************************************************************************************************************************************************************************************************************************

[Definición de alcance v0.1](Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Definicio%CC%81n%20de%20alcance%20v0%201%2087355bd593394d18b1078fa22d146d0a.md)

[Definición de alcance v0.2](Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Definicio%CC%81n%20de%20alcance%20v0%202%207d80703777494e55ac5aa2b1e7fa447d.md)

[Requerimientos de Interfaz v0.1](Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Requerimientos%20de%20Interfaz%20v0%201%2094578f35854d4e2396799616da2ce980.md)

[Propuesta Diseño de Aplicación](Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Propuesta%20Disen%CC%83o%20de%20Aplicacio%CC%81n%2040049b5678ca4ef89565f5fb5aae0b15.md)

[Reglas de negocio](Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Reglas%20de%20negocio%202ecad8100be348dd97820d25951cf597.md)

[Brainstorm solución de ventas, negocios, contratos, bonos, DA, etc](Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Brainstorm%20solucio%CC%81n%20de%20ventas,%20negocios,%20contrato%20dfc64498892e472fb58ba6311f1cb772.md)

[Historias de Usuario](Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Historias%20de%20Usuario%20863af46b145d4faa9dc797cc5c4e1660.md)

[Formato Requisitos funcionales RAM](https://docs.google.com/spreadsheets/d/1ijuDjWE1UxtgRoeekSNPiPbB5AByjpyzYiSnwvLzQ4Q/edit?usp=sharing)

[Definición de Requerimientos](Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Definicio%CC%81n%20de%20Requerimientos%2025c4385572f745b892747d1ff4d344b0.md)

[Validación de propuesta RAM (editable)](https://docs.google.com/document/d/1wx5LKQJvUJMOdyQ2ChuB9vqvR2xJOc_bIbPTxnhueHc/edit)

[Validación de propuesta RAM.docx](Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Validacin_de_propuesta_RAM.docx)

[Historias de usuario](https://docs.google.com/spreadsheets/d/1haEkJ8bDF3w2R7-z7XgKqIaIf96pSDZGznjTvOMTCEY/edit#gid=0)

[Skills integrantes RAM](https://docs.google.com/spreadsheets/d/1xFHs5PX02kNhiRXNv3LuX5OtFi42sEvD95QB9KKQmcI/edit?usp=sharing)

[Carpeta de One on Ones](https://drive.google.com/drive/folders/1Y1ITPlNCyEh2CmbakeYV2j_pXJZhPUhQ?usp=sharing)