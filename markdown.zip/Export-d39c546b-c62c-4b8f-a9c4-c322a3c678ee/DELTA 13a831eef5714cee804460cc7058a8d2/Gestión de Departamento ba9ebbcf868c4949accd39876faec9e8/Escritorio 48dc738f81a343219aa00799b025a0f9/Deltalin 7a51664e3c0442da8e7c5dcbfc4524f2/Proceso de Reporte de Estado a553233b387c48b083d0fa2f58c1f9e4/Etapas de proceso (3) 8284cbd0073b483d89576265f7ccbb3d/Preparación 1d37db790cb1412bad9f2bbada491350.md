# Preparación

Actividades: Hacer una copia del https://www.notion.so/6b8bc6200ec54319b0573154a17d4ce7 y llenarlo.