# Retrospectivas

### Acuerdos de trabajo

---

- Organizar la repartición de actividades semanales tomando en cuenta los APs de cada actividad.
- Asignar un número máximo de 3 responsables por actividad.
- Delegar tareas de forma que estas se repartan de forma equitativa.
- Si una persona no está asignada a una tarea, tratar de no involucrarse mucho. Esto ayudará a mejorar la estimación de tiempos. Esto no significa que no puede estar ahí o no debe de enterarse de lo que se está haciendo.

### Resumen de retrospectivas semanales

---

[03/03/2023](Retrospectivas%2046ae6ad70d5e470aaf6bc9b441bb3d02/03%2003%202023%20ff01f990e73b49979bcc01e464455a93.md)

## Historial **de cambios**

[Manejo de versiones (3)](Retrospectivas%2046ae6ad70d5e470aaf6bc9b441bb3d02/Manejo%20de%20versiones%20(3)%201232325beaa24149ac3fb89c3a774272.md)