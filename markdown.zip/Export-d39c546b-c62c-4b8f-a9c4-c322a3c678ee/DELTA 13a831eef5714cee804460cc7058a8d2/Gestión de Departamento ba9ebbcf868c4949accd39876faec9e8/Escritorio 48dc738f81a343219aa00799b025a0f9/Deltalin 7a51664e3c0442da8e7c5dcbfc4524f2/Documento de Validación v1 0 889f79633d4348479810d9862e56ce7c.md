# Documento de Validación v1.0

[Michelin Validación de propuesta-1.pdf](Documento%20de%20Validacio%CC%81n%20v1%200%20889f79633d4348479810d9862e56ce7c/Michelin_Validacin_de_propuesta-1.pdf)

**Aceptación del socio (firma)**

El socio validó y firmó el documento el día 24 de febrero de 2023

![AceptacionSocio-24:02:2023.jpg](Documento%20de%20Validacio%CC%81n%20v1%200%20889f79633d4348479810d9862e56ce7c/AceptacionSocio-24022023.jpg)