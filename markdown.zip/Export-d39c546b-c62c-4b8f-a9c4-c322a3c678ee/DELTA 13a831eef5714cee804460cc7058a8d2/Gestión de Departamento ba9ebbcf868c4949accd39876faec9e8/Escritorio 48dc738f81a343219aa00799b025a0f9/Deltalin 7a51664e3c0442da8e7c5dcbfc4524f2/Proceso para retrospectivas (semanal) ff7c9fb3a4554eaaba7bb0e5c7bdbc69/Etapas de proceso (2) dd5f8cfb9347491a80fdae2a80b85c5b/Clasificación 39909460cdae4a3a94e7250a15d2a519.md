# Clasificación

Actividades: Los miembros del equipo clasifican las tareas y prácticas de la semana de acuerdo al éxito que tuvieron