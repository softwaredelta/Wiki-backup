# Retroalimentación

Actividades: Todos los miembros del equipo, uno por uno, comparten sus perspectivas individuales de lo realizado en la semana