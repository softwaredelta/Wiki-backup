# Documentación

Actividades: Se documentan los aciertos y errores que fueron identificados por el equipo y también los acuerdos generados en la reunión
CMMI: PMC