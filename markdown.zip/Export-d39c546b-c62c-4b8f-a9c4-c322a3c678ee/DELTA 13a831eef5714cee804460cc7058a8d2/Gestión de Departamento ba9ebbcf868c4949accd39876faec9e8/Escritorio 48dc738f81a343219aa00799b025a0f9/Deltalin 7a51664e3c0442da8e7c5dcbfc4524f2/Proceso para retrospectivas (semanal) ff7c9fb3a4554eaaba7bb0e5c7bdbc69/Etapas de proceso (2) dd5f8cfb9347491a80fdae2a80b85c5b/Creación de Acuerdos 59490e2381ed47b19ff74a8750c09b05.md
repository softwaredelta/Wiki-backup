# Creación de Acuerdos

Actividades: Los miembros del equipo crean, reafirman o actualizan sus acuerdos de trabajo.