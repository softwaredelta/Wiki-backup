# Modulos

Assign: Jorge Guerrero Díaz
Due: February 27, 2023
Status: Archived

Terminar de redactar los módulos en la sección de trabajos de la wiki.

Modulo Web principalmente

**Hablar de rename de modulo de Correo para Api google