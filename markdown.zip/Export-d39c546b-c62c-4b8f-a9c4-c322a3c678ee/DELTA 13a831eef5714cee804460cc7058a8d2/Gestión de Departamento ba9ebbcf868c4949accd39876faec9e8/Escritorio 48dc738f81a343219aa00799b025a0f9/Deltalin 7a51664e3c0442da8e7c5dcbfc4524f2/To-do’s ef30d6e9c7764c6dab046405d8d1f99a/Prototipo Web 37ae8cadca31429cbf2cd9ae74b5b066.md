# Prototipo Web

Assign: Jorge Guerrero Díaz
Due: February 27, 2023
Status: In Progress

Trabajar en las pantallas de Administracion del figma de web

Link: