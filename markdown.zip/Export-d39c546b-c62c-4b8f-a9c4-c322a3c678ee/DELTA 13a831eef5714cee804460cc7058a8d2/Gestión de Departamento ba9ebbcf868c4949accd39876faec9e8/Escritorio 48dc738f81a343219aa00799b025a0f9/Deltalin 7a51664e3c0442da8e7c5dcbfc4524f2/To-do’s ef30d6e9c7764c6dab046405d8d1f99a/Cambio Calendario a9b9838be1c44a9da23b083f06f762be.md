# Cambio Calendario

Assign: Ricardo Nuñez Alanis, Fabián Enrique Avilés Cortés
Status: Archived

Tomó 1 hora 

Se realizó el cambio al calendario incluyendo las tablas y gráficas necesarias para realizar el cálculo del SPI y CPI, siguiendo la guía proporcionada en:

[Cómo HACER las tablas y las graficas para el cálculo del SPI y CPI](../../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358.md)