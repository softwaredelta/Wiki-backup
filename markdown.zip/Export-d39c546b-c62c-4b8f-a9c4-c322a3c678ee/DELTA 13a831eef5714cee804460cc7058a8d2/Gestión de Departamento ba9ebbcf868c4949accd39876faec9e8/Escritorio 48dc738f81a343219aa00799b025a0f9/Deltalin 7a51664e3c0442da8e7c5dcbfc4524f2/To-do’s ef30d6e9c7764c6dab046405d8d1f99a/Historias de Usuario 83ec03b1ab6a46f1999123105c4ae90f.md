# Historias de Usuario

Status: Not Started

# Módulo de Administración

Administrador crea nuevo usuario

Administrador borra usuario

Administrador modifica usuario

Administrador crea un nuevo equipo

Administrador agrega TBM a un equipo

Manager consulta su equipo

# Módulo de Métricas

Administrador y Manager consultan métricas

Administrador y Manager filtran métricas