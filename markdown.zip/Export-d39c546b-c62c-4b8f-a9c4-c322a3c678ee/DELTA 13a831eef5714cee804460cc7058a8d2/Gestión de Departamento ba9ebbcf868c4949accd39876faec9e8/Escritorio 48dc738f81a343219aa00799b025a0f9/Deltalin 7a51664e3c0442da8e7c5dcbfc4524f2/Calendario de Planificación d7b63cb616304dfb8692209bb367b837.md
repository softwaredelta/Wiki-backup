# Calendario de Planificación

[Calendario: Planeación General](https://docs.google.com/spreadsheets/d/1HZrmGn_cKk6wFRo-s0_ZsMpfMxow5rXOvBgHTPeQA0U/edit?usp=drivesdk)

### ********Historial de cambios:********

[Manejo de versiones (2)](Calendario%20de%20Planificacio%CC%81n%20d7b63cb616304dfb8692209bb367b837/Manejo%20de%20versiones%20(2)%20709955d88f424435a9707f8864e737ca.md)

-