# Sondeo de riesgos con el departamento y equipos

Grupo: Departamento
Tags: análisis
URL: https://docs.google.com/spreadsheets/d/1f3BQOKItZ1KHzMdbKvSrA0auMifAFjAvYuA8AYWhzbg/edit#gid=0

Link al Google Sheets con el resumen de los posibles riesgos analizados por el Departamento Delta, por el equipo Michelin y el equipo Grupo RAM.

[](https://docs.google.com/spreadsheets/d/1f3BQOKItZ1KHzMdbKvSrA0auMifAFjAvYuA8AYWhzbg/edit#gid=0)

Link al Figma con el resumen más visual del sondeo:

[Riesgos](https://www.figma.com/file/NcC4gs6QCpxIonn2s2Vdqv/Riesgos?node-id=0%3A1&t=uH8SQGXBwDMS9x41-1)