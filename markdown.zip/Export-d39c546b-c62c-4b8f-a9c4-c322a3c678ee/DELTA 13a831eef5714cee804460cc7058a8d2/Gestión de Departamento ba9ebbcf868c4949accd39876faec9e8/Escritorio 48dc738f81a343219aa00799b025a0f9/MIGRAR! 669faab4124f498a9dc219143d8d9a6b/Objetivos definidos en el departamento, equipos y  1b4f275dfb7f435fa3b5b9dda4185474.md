# Objetivos definidos en el departamento, equipos y proyectos

Grupo: Departamento
Tags: gestion, monitorización

## Objetivo del Proyecto Michelin

<aside>
🛠 Reducir el tiempo del proceso de auditoría en un 50% mediante la centralización del sistema.

</aside>

## Objetivo del Proyecto Grupo Asesores RAM

<aside>
🛠 Incrementar ventas, bonos y agentes estrella en Grupo Asesores RAM

</aside>