# Minuta Michelin 27 de febrero bis

# Objetivo

Preparar el contenido para la reunión con el socio formador y acordar cómo se llevará a cabo el desarrollo de historias de usuario.

## ¿Quién?

Estuvieron presentes en la reunión Andrés, Aris, Jorge, Emiliano, Cris, Fabián y Ricardo

Aris redactó la minuta

## ¿Qué?

Se trabajó en detalles de la presentación, de prototipos de interfaz y se acordaron formatos para la definición de historias de usuario.

## Acuerdos (opcional)

Se acordaron formatos para especificación de historias de usuario y se confirmó la división presente entre los módulos de la aplicación

# Conclusiones

Se preparó la presentación para el socio formador con éxito