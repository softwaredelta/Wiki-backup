# Minuta RAM 24 febrero

## Resumen

## Objetivo

Brainstorming para saber a como podríamos integrar la nueva información a los modulos que ya se tienen.

## Quién?

Fermin propuso la reunión y llevó la discusión

Kenny explica la información que se recopilo con el socio formador, propuso hacer el brainstorming en Notion 

Jordy propuso hacer entrevista one to one con los miembros del equipo

Rodrigo, Fermin y Reno establecieron una nueva forma de MVP y MLP

## Qué?

### Lo nuevo:

A RAM le importa:

- Integración de negocios: Ventas
- Le importa los bonos

### MVP

- Ventas
- Cursos
- Usuarios

### MLP

- Control de acceso
- Managment
- Prospectos
- Bonos
- Mi progreso
- Ayuda
- Calendario

### Documento de brainstorming

[Brainstorm solución de ventas, negocios, contratos, bonos, DA, etc](../../Grupo%20Asesores%20RAM%20729240af164e4710bc5f6a8afdf84776/Archivo%20(NO%20TOCAR)%2016e82f7953444ecf804227aea4d5face/Brainstorm%20solucio%CC%81n%20de%20ventas,%20negocios,%20contrato%20dfc64498892e472fb58ba6311f1cb772.md)