# Minuta RAM 23 de febrero

## Resumen

Los miembros del equipo se unieron para definir los módulos y el documento de Validación de Propuesta. También para integrar la definición del sistema con el prototipo.

# Objetivo

Terminar de definir los requerimientos para proponerselos al socio formador el día 24/feb/2023

## ¿Quién?

Muñoz y Jordana dirigieron la junta inicialmente al ser quienes comenzaron la reunión. Se utilizó el documento del SRS para comenzar a revisar los requerimientos/propuesta del proyecto.

Alex comenzó a llenar el notion de RAM.

Se comenzó a llenar el formato de Validación de Propuesta.

Se editó y redefinió el documento de SRS

Muñoz se encargo de escribir que NO hace el sistema.

Se acordó que Muñoz se encargaría de imprimir 

Ángel, Jordana y Alex hicieron la presentación

Kenny, Renato, Muñoz, Fermin y Mónica van a ir con RAM a presentar la propuesta.

Se hará el cambio de representante de Mónica a Muñoz.

# Conclusiones

La reunión fue exitosa ya que se detallaron más los requerimientos y construyeron