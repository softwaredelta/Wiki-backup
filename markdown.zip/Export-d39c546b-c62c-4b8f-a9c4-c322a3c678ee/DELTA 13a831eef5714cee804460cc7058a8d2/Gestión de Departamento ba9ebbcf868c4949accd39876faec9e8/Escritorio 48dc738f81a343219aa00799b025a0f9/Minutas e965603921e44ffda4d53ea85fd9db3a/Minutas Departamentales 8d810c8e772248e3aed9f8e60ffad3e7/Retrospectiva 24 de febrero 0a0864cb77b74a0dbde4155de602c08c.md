# Retrospectiva 24 de febrero

# Errores

## Lucky Bastards

- No aplicamos CMMI
- Procrastinar
- Falta de minutas Michelin
- Calendarios
- Definición de módulos

## WTF Dude

- **Forzar procesos**
- Falta de procesos
- Tiempo perdido
- **Juntas ineficientes vs productivas**
- Unificación
- Propuesta económica antes de prueba de arquitectura (RAM)
- Gestión de la configuración
- No delegar
- NPC’s

# Experimentos

## You esceeded AND learned

- Proceso de casos de uso (**Michellin**)
- Notion
- Excel de planeación
- Acuerdos departamento

## You failed but learned

- Proceso de munutas

# Prácticas

## Identify solutions/Continúa haciéndolo

- Whatsapp (comunicación)

## Argh Mala suerte

- PM (se identificó el rol, pero no la carga necesaria).

# Findings

- Definir quiénes toman las minutas
- WBS CMMI
- Proceso de planeación
- Proceso de acuerdos
- Delegar más activiades a pequeños grupos de integrantes
- Happiness door
- Gente se queda sin propósito
- Medición de tiempo

# Problems