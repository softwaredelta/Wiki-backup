# Emiliano Vásquez Olea

Periodo: Primer periodo
Rol: Architecture Owner