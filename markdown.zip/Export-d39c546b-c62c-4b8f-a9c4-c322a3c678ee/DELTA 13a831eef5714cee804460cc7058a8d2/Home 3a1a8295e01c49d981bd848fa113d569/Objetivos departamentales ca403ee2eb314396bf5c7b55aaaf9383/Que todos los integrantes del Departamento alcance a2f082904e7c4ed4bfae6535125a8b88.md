# Que todos los integrantes del Departamento alcancen como mínimo el nivel Jedi en las competencias del periodo.

Estado: Sin iniciar
Periodo: Primer periodo
Roles: ../Roles%2057a875e38e6344fd85278871ed4853ea/Mo%CC%81nica%20Andrea%20Ayala%20Marrero%204f52e16b649941098bd4f888b65b5582.md