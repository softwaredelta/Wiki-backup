# El camino hacia el Lean Startup por Gene Kim

Files & media: El_camino_hacia_el_Lean_Startup.pdf
Tags: DAD, Procesos