# UML Distilled: A brief guide to the standard object modeling language by Martin Fowler

Tags: Diseño, UML