# PMBOK: La guía de los fundamentos para la dirección de proyectos

Files & media: Project_Management_Institute_-_Gua_de_Los_Fundamentos_Para_la_Direccin_de_Proyectos_(2017).pdf
Idioma: Spanish
Tags: Procesos, Project Management