# Consolidar un Departamento de TI y lograr con éxito los proyectos de desarrollo.

Estado: Progreso
Periodo: Semestral