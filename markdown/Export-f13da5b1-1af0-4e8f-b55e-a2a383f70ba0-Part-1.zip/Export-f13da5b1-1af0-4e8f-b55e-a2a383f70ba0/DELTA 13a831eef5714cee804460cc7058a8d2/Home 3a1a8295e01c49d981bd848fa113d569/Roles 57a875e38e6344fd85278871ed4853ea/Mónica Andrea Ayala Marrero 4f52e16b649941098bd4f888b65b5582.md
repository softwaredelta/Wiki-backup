# Mónica Andrea Ayala Marrero

Objetivo: ../Objetivos%20departamentales%20ca403ee2eb314396bf5c7b55aaaf9383/Alcanzar%20el%20nivel%202%20de%20madurez%20del%20CMMI%205a5e6ca4ccf344499893ba968179e4c2.md, ../Objetivos%20departamentales%20ca403ee2eb314396bf5c7b55aaaf9383/Que%20todos%20los%20integrantes%20del%20Departamento%20alcance%20a2f082904e7c4ed4bfae6535125a8b88.md
Periodo: Primer periodo
Rol: Program Manager