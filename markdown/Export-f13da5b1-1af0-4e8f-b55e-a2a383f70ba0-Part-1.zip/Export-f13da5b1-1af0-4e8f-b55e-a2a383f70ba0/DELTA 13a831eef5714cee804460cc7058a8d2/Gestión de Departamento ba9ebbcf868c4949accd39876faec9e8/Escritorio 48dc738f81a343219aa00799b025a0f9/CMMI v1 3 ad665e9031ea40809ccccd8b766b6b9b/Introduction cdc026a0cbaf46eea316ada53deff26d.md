# Introduction

![Untitled](Introduction%20cdc026a0cbaf46eea316ada53deff26d/Untitled.png)

| Nivel | Niveles de Capacidad | Niveles de Madurez |
| --- | --- | --- |
| Nivel 0 | Incompleto |  |
| Nivel 1 | Realizado | Inicial |
| Nivel 2 | Gestioando | Gestionado |
| Nivel 3 | Definido | Definido |
| Nivel 4 |  | Gestionado Cualitativamente |
| Nivel 5 |  | En Optimización |

## Niveles de Capacidad

************************Incompleto:************************ Un proceso que no se realiza o se hace de manera incompleta.

********************Realizado:******************** Un proceso que se lleva a cabo para producir productos de trabajo.

**********************Gestionado:********************** Un proceso realizado que se planifica y ejecuta de acuerdo con la política. Existe disciplina y los procesos se mantienen durante periodos de presión.

******************Definido:****************** Es un proceso gestionado, que se adapta a partir del conjunto de procesos estándares de la organización, de acuerdo a la guía de adaptación de la organización.

## Niveles de Madurez

**Tabla con los requisitos de niveles de capacidad por área de proceso para alcanzar determinados niveles de madurez.**

![Untitled](Introduction%20cdc026a0cbaf46eea316ada53deff26d/Untitled%201.png)

**Relación de las áreas de proceso enfocadas a la Gestión de Procesos (OPD, OPF, OPM, OT, OPP)**

![Untitled](Introduction%20cdc026a0cbaf46eea316ada53deff26d/Untitled%202.png)

![Untitled](Introduction%20cdc026a0cbaf46eea316ada53deff26d/Untitled%203.png)