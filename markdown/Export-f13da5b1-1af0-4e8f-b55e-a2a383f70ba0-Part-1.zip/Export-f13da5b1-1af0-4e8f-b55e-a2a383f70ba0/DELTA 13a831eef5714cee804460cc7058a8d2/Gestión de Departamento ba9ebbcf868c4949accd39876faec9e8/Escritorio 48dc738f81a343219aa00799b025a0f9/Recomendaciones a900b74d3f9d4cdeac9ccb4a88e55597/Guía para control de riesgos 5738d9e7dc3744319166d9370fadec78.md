# Guía para control de riesgos

Autor: Fermín Méndez García, Erick Alfredo García Huerta
Date: March 3, 2023
ID: 5
Must Read: No
Tags: Documentación, Riesgos

IMPORTANTE:

Si realizas un **cambio** en la **matriz de riesgos** no olvides registrar el cambio de versiones en productos de trabajo:

[PRODUCTO DE TRABAJO MATRIZ DE RIESGOS](../Productos%20de%20Trabajo%2097cd5526070c4c4aaa931c06e02b08d9/Mapa%20de%20Procesos%20Departamentales%20befbdb83f0284d9690f1761beffb29ce/Matriz%20de%20Riesgos%20b0583163cd7c47e28de93fd62c4e7620.md)

**Esta guía tienes dos partes que responde a las siguientes situaciones.**

1. Encontré un nuevo riesgo ¿Cómo lo registro? 
2. ¿Cómo actualizo el estado de un riesgo? 

## [Matriz de Riesgo](https://docs.google.com/spreadsheets/d/1f3BQOKItZ1KHzMdbKvSrA0auMifAFjAvYuA8AYWhzbg/edit?usp=sharing)s

[Riesgos](https://docs.google.com/spreadsheets/d/1f3BQOKItZ1KHzMdbKvSrA0auMifAFjAvYuA8AYWhzbg/edit?usp=drivesdk)

## 1- Encontré un nuevo riesgo ¿Cómo lo registro?

**Objetivo:** Describir la forma de documentar y atender un riesgo.

Si **identificas** alguna **situación** que puede poner algún **proyecto en riesgo**, ************************LEE ESTA GUÍA************************.

Imaginemos, soy miembro del proyecto Michelin y me di cuenta que el cliente tiene dos necesidades. Una es la que el cliente QUIERE resolver y la otra la que NECESITA. Estamos por empezar la etapa de desarrollo. Como equipo de desarrollo ya lo convencimos de qué es lo mejor para su empresa. El aceptó, pero creo que a último momento va a querer que cambiemos el enfoque del proyecto. 

Acabo de identificar un riesgo. Ahora vamos a documentarlo.

Vayamos a la [MATRIZ DE RIESGOS](https://docs.google.com/spreadsheets/d/1f3BQOKItZ1KHzMdbKvSrA0auMifAFjAvYuA8AYWhzbg/edit?usp=sharing).

**Paso 1**: Leer todos los riesgo del departamento para confirmar que el riesgo NO está identificado.

![Untitled](../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Gui%CC%81a%20para%20control%20de%20riesgos%20131d45fd5be74c50a9f43f6946857a99/Untitled.png)

**Paso 2**: Ir al final del excel y comenzar a documentar.

![Untitled](../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Gui%CC%81a%20para%20control%20de%20riesgos%20131d45fd5be74c50a9f43f6946857a99/Untitled%201.png)

En este caso tendremos que llenar el ID como RSK_38, la fecha actual y un título significativo del riesgo. 

![Untitled](../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Gui%CC%81a%20para%20control%20de%20riesgos%20131d45fd5be74c50a9f43f6946857a99/Untitled%202.png)

Seleccionas el proyecto al que pertenece y seleccionas una delas 4 categorías.

### **Detalle de las categorías:**

Ciclo de vida de software: Si tiene que ver con alguna etapa de análisis, diseño, desarrollo o despliegue. Es decir, lo que va en el ciclo de vida básicamente.

Arquitectura: Si es un peligro que afecte a la estructura del proyecto, como no poder soportar los requisitos no funcionales, etc.

QA: Si es un peligro que afecte la calidad del proyecto o reduzca en algún sentido la confiabilidad y estabilidad del mismo.

Requerimientos: Riesgos relacionados con la identificación, seguimiento y desarrollo del área de Ingeniería de Requisitos.

Calendario: Aquellos peligros relacionados con el cumplimiento de fechas, planeación de juntas y otros riesgos logísticos que puedan presentarse en situaciones relacionadas con fechas.

Seguridad: Riesgos relacionados con la seguridad informática de los proyectos, tales como vulnerabilidades de seguridad u otros problemas que puedan poner en peligro la integridad, accesibilidad y confiabilidad de la información.

Cultura de equipo: Tiene que ver con las actitudes y acciones de los miembros del equipo que pueden afectar su forma de trabajo

Salud del equipo: Peligros relacionados con la salud física y mental de los miembros del equipo que puedan afectar el desarrollo del proyecto.

En este caso corresponde al ciclo de vida de software por la definición de requerimientos.

![Untitled](../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Gui%CC%81a%20para%20control%20de%20riesgos%20131d45fd5be74c50a9f43f6946857a99/Untitled%203.png)

### Probabilidad e impacto

La probabilidad es una aproximación de qué tan probable es que este riesgo se vuelva un problema. En este acaso, digamos que el cliente se ve muy terco y le tanteamos un 70% de riesgo y es algo que pone en mucho riesgo el proyecto, le asignamos un 8. En esta escala 0 es , no hay impacto y 10 significa que el proyecto fracasa.

![Untitled](../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Gui%CC%81a%20para%20control%20de%20riesgos%20131d45fd5be74c50a9f43f6946857a99/Untitled%204.png)

### Magnitud y riesgo real

El *riesgo real y la magnitud* es un cálculo automático para poder filtrar los riesgos y dar atención a los más importantes. **NO** tienes que tocar el campo *riesgo real ni magnitud.*

### Umbral

Hay que definir un umbral de activación. Responde a la pregunta **¿Cuándo se materializa el riesgo?**

En este caso es fácil, el cliente pide agregar un requisito que no se contempló en el alcance.

### **Valor de monitoreo**

Por el momento no vamos a llenar este espacio. Esta área se llena siguiendo la siguiente celda, una vez se realice una segunda o tercera revisión de la matriz de riesgos, el valor de monitoreo deberá llenarse en función de si el riesgo se ha materializado o no.

### Tiempo de monitoreo

Representa cada cuánto se va a volver a revisar este riesgo. Toma en cuenta que todos los riesgos tienen tiempos de revisión distintos.

En este caso, ya que cada semana tenemos juntas con los socios formadores, este riesgo debe revisarse cada semana.

![Untitled](../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Gui%CC%81a%20para%20control%20de%20riesgos%20131d45fd5be74c50a9f43f6946857a99/Untitled%205.png)

### ¿El riesgo está activo?

Esta área se refiere al estado del riesgo.

Riesgo controlado: Si la medida del monitoreo no sobrepasa el umbral de activación.

SOS: Si el monitoreo a sobrepasado el umbral de activación.

Desconocido: Si identificaste el riesgo, pero no sabes ni cómo medirlo ni como tratarlo. 

Nota: En caso de llegar al SOS ó Desconocido notifica a los gestores de riesgos. (En este caso Fredy o Fermín).

### Plan de mitigación

Esta área se refiere a si hay algún documento que apoye a reducir o controlar el riesgo, en caso de que no haya, puede plantearse la creación de uno con los gestores de riesgo (Fredy y Fermín) y anotarse, pero señalar que es un documento a futuro con un *****. Por ejemplo el documento de alcance:

![Untitled](../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Gui%CC%81a%20para%20control%20de%20riesgos%20131d45fd5be74c50a9f43f6946857a99/Untitled%206.png)

Una vez escribes el título presiona ctrl + k para insertar el hipervínculo.

![Untitled](../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Gui%CC%81a%20para%20control%20de%20riesgos%20131d45fd5be74c50a9f43f6946857a99/Untitled%207.png)

### Plan de respuesta

El plan de respuesta es una breve descripción de cómo de debe llevar a cabo las acciones de mitigación del proyecto. Pregúntate: ¿quién tiene que iniciarlo?, ¿a quién(es) debe notificar? y ¿qué acciones se deben  llevar a cabo?

### Responsable

Esta zona marca quién es el responsable de llevar a cabo el plan de acción. Sólo puede haber un responsable de por cada riesgo, en caso de dudas contactar a los gestores de riesgos (Fredy y Fermín).

En este caso, el Product Owner es el responsable de mantener el enfoque del proyecto, por lo tanto es el responsable de llevar a cabo el plan de respuesta.

![Untitled](../../WoW%2022e4d144a8f047fb836aa77da202a397/Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Gui%CC%81a%20para%20control%20de%20riesgos%20131d45fd5be74c50a9f43f6946857a99/Untitled%208.png)

### Notas

Observaciones que se tengan que hacer respecto al problema, si es buena idea corroborar algo con un profesor o alguna persona pueda tener información relevante respecto al riesgo.

En este caso no es necesario agregar ninguna nota.

### Fecha de la última revisión

Este campo corresponde a la última vez que se revisó el riesgo y se debe actualizar con cada revisión siguiendo el tiempo de monitoreo.

En el ejemplo, como el tiempo de monitoreo es cada semana, la fecha de la última revisión debe cambiar semanalmente.

### Persona que revisó

Por último se tiene que llevar un registro de quién hizo la revisión del riesgo y se modifica con cada nueva revisión. Se debe tomar en cuenta que todos los miembros afectados por el riesgo son responsables de su revisión.

[Manejo de versiones ](Gui%CC%81a%20para%20control%20de%20riesgos%205738d9e7dc3744319166d9370fadec78/Manejo%20de%20versiones%203cfa509656894a008177a537f3d1eb62.md)