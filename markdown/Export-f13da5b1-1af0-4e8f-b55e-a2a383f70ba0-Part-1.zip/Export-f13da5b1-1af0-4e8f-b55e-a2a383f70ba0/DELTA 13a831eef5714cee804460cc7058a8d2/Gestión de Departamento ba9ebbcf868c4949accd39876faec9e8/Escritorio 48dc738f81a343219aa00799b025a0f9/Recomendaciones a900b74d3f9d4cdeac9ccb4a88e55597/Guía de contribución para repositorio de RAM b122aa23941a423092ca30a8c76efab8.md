# Guía de contribución para repositorio de RAM

Must Read: Yes
Tags: Configuración, Desarrollo, RAM, TODO