# Proceso para Definir Historias de Usuario

Autor: Rodrigo Muñoz Guerrero
Date: March 10, 2023
ID: 8
Must Read: No
Tags: Documentación, HU

## ********************************************Objetivo:********************************************

Tener una guía para definir historias de usuario de manera completa y adecuada a la necesidad del cliente.

## ****************************************Entradas de proceso:****************************************

- Juntas con socio formador para entender sus procesos y necesidad
- Entendimiento de la necesidad del cliente

## Términos:

Historia de Usuario: Formato de definición de requisitos funcionales enfocado en la empatía con el cliente. Formato de una historia de usuario (Yo como… [Quién] Quiero… [Descripción] Para… [Razón / Valor que aporta])

## **********************************Pasos de proceso:**********************************

[Etapas de proceso (2)](Proceso%20para%20Definir%20Historias%20de%20Usuario%206ce67387d8cb4397b5169687d1d7749a/Etapas%20de%20proceso%20(2)%208a9a4009e8724af0ac54724c54ca67b6.md)

## **************************************Salidas de proceso:**************************************

## Monitorización o Métricas**************************************:**************************************

## ********************************************Notas y sugerencias para el futuro:********************************************

## ********Historial de cambios:********

[Manejo de versiones (1)](Proceso%20para%20Definir%20Historias%20de%20Usuario%206ce67387d8cb4397b5169687d1d7749a/Manejo%20de%20versiones%20(1)%2001aedc5b2b91477f8f5a2c367244c1c3.md)