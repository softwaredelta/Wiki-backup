# TICKETS EP4: Como utilizar Promise.all para optimizar queries

Must Read: Yes
Tags: Calidad, Desarrollo, Tickets

## Problemática

## Solución

## Resultado

### Episodio anterior

[TICKETS EP3: Ejemplo de varias técnicas](TICKETS%20EP3%20Ejemplo%20de%20varias%20te%CC%81cnicas%20d18caa22229d4a7db1eef8200c92c0c1.md)

### Episodio siguiente