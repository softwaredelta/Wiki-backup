# Presentaciones

# Presentación 24 de febrero

Presentación para el Socio formador que cuenta con nuestro objetivo, alcance, módulos a implementar y nuestras primeras propuestas

[Presentación Viernes 24](https://docs.google.com/presentation/d/1SgWwEHlR-8d6IHtXyDtvbrtRzPtklWEpF6j9LtcqG3Q/edit?usp=drivesdk)

# Presentación 28 de febrero

Presentación para el socio formador de la propuesta Web y cambios de propuesta móvil

[Presentación Viernes 24](https://docs.google.com/presentation/d/1SgWwEHlR-8d6IHtXyDtvbrtRzPtklWEpF6j9LtcqG3Q/edit?usp=drivesdk)

# Presentación 6 de marzo

Presentación para el socio formador para aclarar unas Reglas de negocio, seguimiento de las licencias de desarrollador

[Presentación Martes 7 marzo](https://docs.google.com/presentation/d/1SWa7zDEmM1Lw7VI-cadxkIwWSuoBI8isSaSier_y9Z8/edit?usp=drivesdk)