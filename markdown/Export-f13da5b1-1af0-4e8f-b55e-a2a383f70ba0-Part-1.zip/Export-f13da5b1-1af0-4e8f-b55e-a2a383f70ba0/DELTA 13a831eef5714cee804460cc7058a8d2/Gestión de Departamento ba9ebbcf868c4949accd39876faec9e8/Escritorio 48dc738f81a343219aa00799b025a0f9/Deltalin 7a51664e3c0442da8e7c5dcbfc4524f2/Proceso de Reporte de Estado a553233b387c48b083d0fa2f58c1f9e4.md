# Proceso de Reporte de Estado

### ********************************************Objetivo:********************************************

Informar a los miembros del departamento y stakeholders el estado de salud en el que se encuentran los proyectos y el departamento en general.

### ****************************************Entradas de proceso:****************************************

1. Calendario de Actividades Semanal y las métricas del mismo.
2. Backlog de cada proyecto.

### **********************************Pasos de proceso:**********************************

[Etapas de proceso (3)](Proceso%20de%20Reporte%20de%20Estado%20a553233b387c48b083d0fa2f58c1f9e4/Etapas%20de%20proceso%20(3)%208284cbd0073b483d89576265f7ccbb3d.md)

### **************************************Salidas de proceso:**************************************

1. Actualización de lista de acuerdos de trabajo

### Monitorización o Métricas**************************************:**************************************

### ********************************************Notas y sugerencias para el futuro:********************************************

### ********Historial de cambios:********

[Manejo de versiones (2)](Proceso%20de%20Reporte%20de%20Estado%20a553233b387c48b083d0fa2f58c1f9e4/Manejo%20de%20versiones%20(2)%20743158765aa74dbb9ddc3e96c2bf7a0b.md)