# Recursos del Socio Formador

# Guía de Identificación

Estándares de los colores y tipografía de la empresa Michelín

[GUÍA_IDENTIFICACIÓN_MICHELIN_2020.pdf](Recursos%20del%20Socio%20Formador%20a2f557e20a8a44afb6bffc699a2f2b3f/GUA_IDENTIFICACIN_MICHELIN_2020.pdf)

# Ejemplo de PDF entregable al cliente

Ejemplo del reporte que genera el TBM al finalizar su recorrido de auditoria en cualquier punto de venta, contiene las preguntas y secciones a evaluar.

[Ejemplo de PDF entregable al cliente con resultados.pdf](Recursos%20del%20Socio%20Formador%20a2f557e20a8a44afb6bffc699a2f2b3f/Ejemplo_de_PDF_entregable_al_cliente_con_resultados.pdf)

# Bibendum

Poses e Imágenes de la mascota Bibendum de la empresa Michelin para su uso.

[Poses Bibendum templates v.1.pptx.pdf](Recursos%20del%20Socio%20Formador%20a2f557e20a8a44afb6bffc699a2f2b3f/Poses_Bibendum_templates_v.1.pptx.pdf)

# Link a Carpeta de Drive

Acceso unicamente a los miembros de Delta dados de alta en la unidad compartida de Drive

[Carpeta de Drive](https://drive.google.com/drive/folders/1XXsjmb5tOgjY92UeiUcBFt53QaLUJ3Sh?usp=share_link)