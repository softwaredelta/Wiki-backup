# Proceso para retrospectivas (semanal)

### ********************************************Objetivo:********************************************

Escuchar la retroalimentación que los miembros del equipo tiene sobre el trabajo realizado a lo largo de la semana para identificar los aciertos y errores que se tuvieron.

### ****************************************Entradas de proceso:****************************************

1. Perspectivas individuales de los miembros del equipo sobre el sprint o bien la semana de trabajo.
2. Calendario de Actividades Semanal.

### **********************************Pasos de proceso:**********************************

[Etapas de proceso (2)](Proceso%20para%20retrospectivas%20(semanal)%20ff7c9fb3a4554eaaba7bb0e5c7bdbc69/Etapas%20de%20proceso%20(2)%20dd5f8cfb9347491a80fdae2a80b85c5b.md)

### **************************************Salidas de proceso:**************************************

1. Actualización de lista de acuerdos de trabajo

### Monitorización o Métricas**************************************:**************************************

La monitorización se llevara a cabo en [Acuerdos de Trabajo](Retrospectivas%2046ae6ad70d5e470aaf6bc9b441bb3d02.md)

### ********************************************Notas y sugerencias para el futuro:********************************************

1. Refinar proceso de creación de acuerdos

### ********Historial de cambios:********

[Manejo de versiones (1)](Proceso%20para%20retrospectivas%20(semanal)%20ff7c9fb3a4554eaaba7bb0e5c7bdbc69/Manejo%20de%20versiones%20(1)%208470aefeb53d4cb98b360e37d21af053.md)