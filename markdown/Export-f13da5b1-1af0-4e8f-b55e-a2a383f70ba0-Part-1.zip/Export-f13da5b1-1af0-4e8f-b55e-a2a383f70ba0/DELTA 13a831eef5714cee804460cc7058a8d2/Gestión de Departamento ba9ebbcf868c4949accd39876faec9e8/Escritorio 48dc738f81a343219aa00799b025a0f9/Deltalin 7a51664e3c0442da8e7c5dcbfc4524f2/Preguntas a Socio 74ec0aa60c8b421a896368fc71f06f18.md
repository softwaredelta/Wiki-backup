# Preguntas a Socio

- [x]  ¿Qué datos deberían de ir en Métricas?
- [x]  ¿Cuál es el modelo de iPad que utilizan?

 Cuantos al mes de su equipo (meses, contar) por zona

Promedio de calificación de puntos de venta (api)

Recorrido promedio en tiempo

Suma de recorridos totales por mes

Gráfica lineal de recorridos por zona

Día?

Recorrido promedio (tiempo)

- [ ]  ¿Les gustaría filtrar los resultados de los puntos de venta? (Estado / Zona)
- [ ]  Preguntar sobre área de TI (Recomendación de Abraham).
    - [ ]  En caso de no poderte localizar, ¿habría alguien con el podamos comunicarnos? Con respecto a dudas técnicas, ¿Estas también deberían de comentarse contigo?

- [ ]  Preguntar cada cuánto debe de borrarse el historial.
- [ ]  ¿Es posible que en el futuro podamos tener contacto con un TBM?