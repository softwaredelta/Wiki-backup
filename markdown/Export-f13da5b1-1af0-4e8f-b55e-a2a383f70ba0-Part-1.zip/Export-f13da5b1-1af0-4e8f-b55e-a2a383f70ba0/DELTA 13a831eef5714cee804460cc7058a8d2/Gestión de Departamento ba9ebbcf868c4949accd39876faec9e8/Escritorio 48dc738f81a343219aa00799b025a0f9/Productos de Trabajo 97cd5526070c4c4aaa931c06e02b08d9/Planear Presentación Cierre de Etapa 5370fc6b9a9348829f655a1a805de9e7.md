# Planear Presentación Cierre de Etapa

Assign: Olivia Araceli Morales Quezada, Mónica Andrea Ayala Marrero, Monica Ayala, Jorge Guerrero Díaz, Jordana Betancourt Menchaca
Propósito: Planear la presentación para el cierre de la primera etapa.
Proyecto: Departamento
Status: In progress
Tags: Docs, Fase: Análisis
Tipo de Producto: Presentación

## Recopilación

Preguntar a los skateholder de la presentación:

- ¿Para quién va a ser la presentación? Hay libertad de invitar a quien sea. Sí o sí a socios y profesores.
- ¿Cuánto va a durar? Breve para dar más tiempo a retro, media a 25 min.
- ¿Qué esperan de nosotros?
    - Lalo
        
        Estado actual del departamento, de que tamaño son los proyecto presupuesto y plan de entrega, necesidad, objetivos y propuesta de soluciones. Ver la evaluación de la forma de trabajo. 
        
    - Padrino
        
        Ver el avance en la presentación del plan de cada proyecto, de los proyectos. 
        
    - Alex
        
        Era caos quiero ver que ya haya orden dentro de ese caos.
        
    - Carlos
        
        Objetivos smart bien definidos y necesidades bien identificadas.
        
    - Claud
    - Denisse
        
        R: que los proyectos estén completamente aterrizador ver la cara de satisfacción de los socios , leguaje no técnico, personas diferentes participando. 
        
- ¿Qué les gustaría ver de nosotros?
    - Lalo
        
        Que me dé esperanza.  Una presentación que sea de ustedes, estar gratamente sorprendido.
        
    - Padrino
        
        El aprendizaje a lo largo de las semanas enfocadas en esas tareas
        
    - Alex
        
        Independientemente del nivel que no solo sea Roa, el nivel que obtenemos el porque ese nivel. Que se vea y cada uno entienda que el nivel no es número.
        
    - Carlos
        
        Objetivos smart bien definidos y necesidades bien identificadas.
        
    - Claud
    - Denisse
        
        R: unión departamental, si van todos, que no se quede en que algunos presentan y otros solo no, que interactúan con los socios para encaminar a un proyecto exitoso. 
        
    - Abraham
        
        
    
- ¿Cómo podemos superar sus expectativas ese día?
    - Lalo
        
         Es una pregunta para ustedes. Es nuestra presentación, hagámosla nuestra. 
        
    - Padrino
        
        “Sorpréndanme!!!” - Ego, Ratatuille (2007)
        
    - Alex
        
        Ya este organizando con un plan que estemos siguiendo y todos lo entiendan.
        
    - Carlos
        
        Que superen las expectativas. Mostrando más que avance consolidación como departamento. 
        
    - Claud
    - Denisse
        
        R: 
        

Unos contaron un cuento. Que se vea que es nuestra profesionalmente. 

Definir:

- [x]  Herramienta de entrega. (Canvas, Genially, Slides, etc…).
- [ ]  Estilo de la presentación.
- [ ]  Contenidos.
- [ ]  Ponentes.

## Estructura

- **Introducción**
    - Saludo a la audiencia.
        
        Buenas tardes, quiero agradecer su tiempo y la atención que nos brindan.
        
    - Anunciar el objetivo de la presentación y los temas más destacados.
        
        El día de hoy presentaremos nuestros avances como departamento. [extender poquito]
        
    - Presentarse brevemente
        
        Me presento, yo soy [fulano de tal y perenganito] y dirigiré(mos) esta exposición.
        
- **Nudo**
    - Seleccionar y editar el contenido.
        1. Delta fluvial como analogía (storytelling rápido). 
        2. Contar la historia de cómo escogimos el nombre.
        3. Presentar a cada equipo.
    - Desarrollar líneas argumentales.
        1. Permítanme explicar las imágenes que están viendo, ¿alguien sabe lo que es una delta fluvial?
        Queremos iniciar con una definición y un pequeño spoiler. Las imágenes que están viendo son deltas fluviales, estas son accidentes geográficos formados en las desembocaduras de los ríos por los sedimentos. Provocan la división del río en múltiples brazos que forman canales activos, todos ellos apuntan al océano. 
    - Estructurar linealmente las ideas importantes.
    - Establecer resúmenes parciales.
    - Redactar todos los documentos necesarios para la presentación.
- **Desenlace**

- Delta fluvial como analogía (storytelling rápido).
- Presentar a cada equipo.

## Links Relevantes

Presentaciones Efectivas por El Padrino:

[Presentaciones efectivas 2](https://docs.google.com/presentation/d/1EbDGrR_LKSb8ltAeAaoda0tJcphdyUVnZK82XTa1qwM/edit?usp=drivesdk)

Proceso de Taro:

[https://taro-it.github.io/docs/procesos/P04-proceso-de-presentaciones](https://taro-it.github.io/docs/procesos/P04-proceso-de-presentaciones)

[Presentacion primer avance  ](https://docs.google.com/presentation/d/1N4mnokV3M_3hhVfjA85CSvHMvT-vwWwfQYRLAS5S6VA/edit?usp=drivesdk)

[Manejo de Versiones ](Planear%20Presentacio%CC%81n%20Cierre%20de%20Etapa%205370fc6b9a9348829f655a1a805de9e7/Manejo%20de%20Versiones%206572311d7abf4a18a31a5fc0d1586cb4.md)