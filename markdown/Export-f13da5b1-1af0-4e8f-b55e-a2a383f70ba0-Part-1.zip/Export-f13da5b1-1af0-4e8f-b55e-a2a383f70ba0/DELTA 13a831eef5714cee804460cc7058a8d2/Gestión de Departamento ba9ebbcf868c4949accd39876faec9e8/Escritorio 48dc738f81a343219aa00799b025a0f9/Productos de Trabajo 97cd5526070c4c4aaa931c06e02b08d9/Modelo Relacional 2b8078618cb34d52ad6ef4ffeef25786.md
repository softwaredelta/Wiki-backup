# Modelo Relacional

Assign: Alejandro Mtz. Luna, José Ángel Rico Mendieta, Diego Emilio Barrera Hernández
Propósito: Write a useful description of the item
Proyecto: RAM
Status: In progress
Tags: Fase: Diseño

![Imagen del Modelo Entidad-Relación (MER) ](Modelo%20Relacional%202b8078618cb34d52ad6ef4ffeef25786/Untitled.png)

Imagen del Modelo Entidad-Relación (MER) 

# Modelo Relacional

- Role (idRole, name,  )
    - PK (idRole)

- Privilege (idPrivilege, privilege)
    - PK (idPrivilege)

- RolPrivilege (idRole, idPrivilege)
    - PK(idRole, idPrivilege)
    - FK(idPrivilege) from Privilege (idPrivilege)
    - FK(idRole) from Roles(idRole)

- User (idUser, idOrigen, email, password, mobile, phone, level, registerDate, createDate, urlImage)
    - PK(idUser, idOrigen)
    - FK(idOrigin) from Origin(idOrigin)

- UserRol (idUser, idRole)
    - PK(idUser, idRole)
    - FK(idUser) from User(idUser)
    - FK(idRole) from Role(idRole)

- Groups (idGroup,  timeStamp, nameGroup)
    - PK(idGroup)

 

- GropusUser (idUser, idGroup)
    - PK(idUser, idGroup)
    - FK(idUser) from User(idUser)
    - FK(idGroup) from Group(idGroup)

- Deliveries (idDeliverie, idUser, description, urlImage)
    - PK(idDeliverie, idUser)
    - FK(idUser) from User(idUser)

- DeliverieUser (idDeliverie, idUser,  dateDeliveried, urlFile, status)
    - PK( idDeliverie, idUser,  dateDeliveried)
    - FK(idUser) from User(idUser)
    - FK(idDeliverie) from Deliveries(idDeliverie)
    - FK(idUser) from User(idUser)
    
- Bonus(idBonus, idUser, name)
    - PK(idBonus, idUser)
    - FK(idUser) from User(idUser)
    
- Origin(idOrigin, origin)
    - PK(idOrigin)

- Goal(idGoal, idUser, nameGoal)
    - PK(idGoal, idUser)

- Notifications(idNotification, notification, date, timeStamp)
    - PK(idNotification)

- UserNotification(idUser, idNotifiaction, timeStamp)
    - PK(idUser, idNotifiaction)
    - FK(idNotifiaction) from Notifications(idNotifiaction)
    - FK(idUser) from User(idUser)

- Sell (idSale, policyNum, sellDate, sellDate, status, periodicty, urlEvidence,)
    - PK( idSale, policyNum, sellDate)
    
- AssurenceType (idAssurance, name, timesTamp)
    - PK (idAssurance, name)

---

[Manejo de Versiones](Modelo%20Relacional%202b8078618cb34d52ad6ef4ffeef25786/Manejo%20de%20Versiones%209082e39273794ff99375dfd79eeddb07.md)