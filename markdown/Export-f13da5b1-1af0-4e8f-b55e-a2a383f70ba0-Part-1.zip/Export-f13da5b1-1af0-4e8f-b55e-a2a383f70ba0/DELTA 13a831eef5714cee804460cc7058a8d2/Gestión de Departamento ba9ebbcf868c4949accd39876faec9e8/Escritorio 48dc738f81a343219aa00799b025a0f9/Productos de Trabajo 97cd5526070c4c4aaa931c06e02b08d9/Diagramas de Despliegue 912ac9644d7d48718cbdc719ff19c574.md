# Diagramas de Despliegue

Assign: Kenny Eduard Vercaemer González
Propósito: Especificación de proceso de despliegue para solución Grupo RAM
Proyecto: RAM
Revisión: Monica Ayala
Status: Not started
Tags: Fase: Diseño
Tipo de Producto: Architecture Diagram

---

[Manejo de Versiones](Diagramas%20de%20Despliegue%20912ac9644d7d48718cbdc719ff19c574/Manejo%20de%20Versiones%20387a2d1bf07d42c4839e599b4365d7fa.md)