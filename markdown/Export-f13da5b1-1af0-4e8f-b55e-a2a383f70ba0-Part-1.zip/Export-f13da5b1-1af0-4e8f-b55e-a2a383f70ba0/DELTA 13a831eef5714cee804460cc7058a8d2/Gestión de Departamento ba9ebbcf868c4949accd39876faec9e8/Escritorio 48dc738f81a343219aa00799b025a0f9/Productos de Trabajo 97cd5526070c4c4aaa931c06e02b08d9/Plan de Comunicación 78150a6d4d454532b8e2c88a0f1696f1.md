# Plan de Comunicación

Assign: Jorge Guerrero Díaz
Propósito: Write a useful description of the item
Proyecto: Deltalin
Status: Done
Tags: Maps

---

[Plan de Comunicación Deltalin](https://drive.google.com/file/d/1n2BYkoFLINe3eb8D6ITXX_TMvrqdOKnt/view?usp=drivesdk)

[Manejo de Versiones](Plan%20de%20Comunicacio%CC%81n%2078150a6d4d454532b8e2c88a0f1696f1/Manejo%20de%20Versiones%20bcf8169f2bca4f35b992666f5a75672f.md)