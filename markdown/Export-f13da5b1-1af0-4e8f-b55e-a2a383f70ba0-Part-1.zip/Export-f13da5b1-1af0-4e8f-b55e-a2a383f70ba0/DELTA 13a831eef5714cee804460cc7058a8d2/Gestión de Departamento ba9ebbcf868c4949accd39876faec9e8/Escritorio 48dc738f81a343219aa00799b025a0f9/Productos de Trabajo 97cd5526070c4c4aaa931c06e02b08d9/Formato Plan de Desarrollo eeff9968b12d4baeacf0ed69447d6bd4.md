# Formato Plan de Desarrollo

Assign: Olivia Araceli Morales Quezada, Monica Ayala, Cristian Rico
Propósito: Write a useful description of the item
Proyecto: Departamento
Revisión: Monica Ayala, Jordana Betancourt Menchaca, Ian García González, Emiliano Vásquez Olea, Jorge Guerrero Díaz, Rodrigo Muñoz Guerrero, Kenny Eduard Vercaemer González
Status: Done
Tags: Docs, Fase: Diseño, Formatos
Tipo de Producto: Formato

Para cambiar el texto en portada, doble clic en él y después seleccionar *********“Editar”*********.

---

[Formato de Estrategia de Desarrollo](https://docs.google.com/document/d/19AnGZXf6k4UzC3NbKCXgOU1cdHr0q4dEcFw7FVxoesI/edit?usp=drivesdk)

# Referencias

[Estrategia de desarrollo](https://docs.google.com/document/d/1WffQK9GLzX2kL0MUVcXMbCiW4hOo_Gay0Mx5KcPrhso/edit)

[Manejo de Versiones](Formato%20Plan%20de%20Desarrollo%20eeff9968b12d4baeacf0ed69447d6bd4/Manejo%20de%20Versiones%200b15469dfd964f05b1c699dd640270fd.md)

[Formato Plan de Comunicación](Formato%20Plan%20de%20Desarrollo%20eeff9968b12d4baeacf0ed69447d6bd4/Formato%20Plan%20de%20Comunicacio%CC%81n%203a232c3f544b47619864b763b485f588.md)

[WBS RAM](Formato%20Plan%20de%20Desarrollo%20eeff9968b12d4baeacf0ed69447d6bd4/WBS%20RAM%20692690fcdb9942878cd0d3c25d15e89e.md)