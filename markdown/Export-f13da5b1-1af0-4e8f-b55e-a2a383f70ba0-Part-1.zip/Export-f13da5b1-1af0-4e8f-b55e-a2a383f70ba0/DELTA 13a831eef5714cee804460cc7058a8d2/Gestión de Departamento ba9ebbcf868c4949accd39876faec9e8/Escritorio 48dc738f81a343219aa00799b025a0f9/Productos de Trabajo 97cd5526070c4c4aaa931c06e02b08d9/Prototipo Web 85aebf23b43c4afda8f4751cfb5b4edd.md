# Prototipo Web

Assign: Arisbeth Aguirre Pontaza, Olivia Araceli Morales Quezada, Jorge Guerrero Díaz
Propósito: Prototipo en Web, que cubre las pantallas de Login, Administracion de Usuarios y Puntos de Venta y Preguntas
Proyecto: Deltalin
Status: Done
Tags: Diseños

[https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2F3dDgTkb0525ZHHbXmDk6Vl%2FPrototipo-Interfaz-iPad-y-Web%3Fnode-id%3D10%3A3%26t%3DxeLrAagaIByR8pAV-1](https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2F3dDgTkb0525ZHHbXmDk6Vl%2FPrototipo-Interfaz-iPad-y-Web%3Fnode-id%3D10%3A3%26t%3DxeLrAagaIByR8pAV-1)

## ********Historial de cambios:********

[Manejo de versiones (2)](Prototipo%20Web%2085aebf23b43c4afda8f4751cfb5b4edd/Manejo%20de%20versiones%20(2)%20d786dc847e0446efa4d5906616afb1e0.md)