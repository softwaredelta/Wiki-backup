# Prototipo Móvil

Assign: Ricardo Nuñez Alanis
Propósito: Propuestas del diseño movil en figma, donde se ven las patañas de log in, seleccion de recorrido, exterior, interior y partes del cuestionario
Proyecto: Deltalin
Status: Done
Tags: Diseños

[https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FNncie0oGhxO3XoHBZOtfVc%2FAltoNivelMichelin%3Fnode-id%3D0%3A1%26t%3D5mxoWEJs9fKANJ17-1](https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FNncie0oGhxO3XoHBZOtfVc%2FAltoNivelMichelin%3Fnode-id%3D0%3A1%26t%3D5mxoWEJs9fKANJ17-1)

## ********Historial de cambios:********

[Manejo de versiones (2)](Prototipo%20Mo%CC%81vil%20a0bc380e77754babb1830812b1eaf147/Manejo%20de%20versiones%20(2)%20975406f6262541438bc90cc185c54cdb.md)