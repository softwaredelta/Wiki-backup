# Diseño de Componentes WEB

Assign: Jorge Guerrero Díaz, Arisbeth Aguirre Pontaza
Propósito: Write a useful description of the item
Proyecto: Deltalin
Status: Done

# Componentes

View de Puntos de Venta:

- Tarjetas Puntos de Venta:
    - Nombre: Input de texto
    - Dirección:  (link de google maps y dirección o como)
    - Teléfono: Input de texto, solo aceptara números y símbolos
    - Gerente: Input de texto
    - Imagen: ????

View de Administración Usuarios:

- Usuarios:
    - Zona: Multiselect con los estados de la republica
    - Nombre: Input de texto
    - Correo: Input de texto tipo correo
    - Teléfono: Input de texto, solo aceptara números y símbolos
    - Rol: Select con los 3 diferentes roles
    - Manager: Select con todos los managers registrados

View de Administración Equipos:

- Tarjetas de Equipo:
    - Manager: Campo de texto con el manager lider del equipo
    - TBMs: Lista de los TBMs asignados a ese equipo
    - Zonas: Listado de Zonas que cubren

View de Cuestionario:

- Cuestionario:
    - Sección: Dropdown con tabla de preguntas.
    - Fecha: Campo de texto
    - Preguntas: Tabla con 4 columnas (orden, pregunta, evidencia con cámara y botón no aplica)
        - Orden: Campo de Texto
        - Pregunta: Campo de texto
        - Fotografía: Checkbox deshabilitado
        - No aplica: Checkbox deshabilitado

View de Preguntas:

- Preguntas:
    - Texto: Input de texto
    - No aplica: Checkbox
    - Fotografía: Checkbox
    - Sección: Select del apartado al que pertenece la pregunta
    - Orden: Input de number

View de Historial:

- Rectángulo de Historial:
    - Punto de Venta: Campo de texto
    - TBM: Campo de texto del TBM que realizo esa auditoria
    - Puntuaciones:  Grafica o indicador visual con puntaje
    - Reporte: Link al pdf
    - Fecha:  Formato de DD/MM/AAAA
    - Tiempo: Campo de texto en minutos y segundos

---

[Manejo de Versiones](Disen%CC%83o%20de%20Componentes%20WEB%20267ce3fffcd54118b3f5fee4f7cd55e6/Manejo%20de%20Versiones%20f6423a4aeff14c64b07b9e43a38f7e52.md)