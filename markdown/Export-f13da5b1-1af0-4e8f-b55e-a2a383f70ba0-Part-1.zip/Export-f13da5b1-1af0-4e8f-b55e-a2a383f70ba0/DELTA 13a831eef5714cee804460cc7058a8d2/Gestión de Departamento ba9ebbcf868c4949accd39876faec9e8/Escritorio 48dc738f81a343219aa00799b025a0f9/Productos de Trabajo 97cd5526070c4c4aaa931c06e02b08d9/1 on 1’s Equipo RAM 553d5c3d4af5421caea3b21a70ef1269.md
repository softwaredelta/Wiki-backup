# 1 on 1’s Equipo RAM

Assign: Jordana Betancourt Menchaca
Propósito: Recopilación de reuniones 1 on 1 con integrantes del equipo RAM
Proyecto: RAM
Status: In progress
Tags: Misc

[https://drive.google.com/drive/folders/1Y1ITPlNCyEh2CmbakeYV2j_pXJZhPUhQ?usp=sharing](https://drive.google.com/drive/folders/1Y1ITPlNCyEh2CmbakeYV2j_pXJZhPUhQ?usp=sharing)

---

[Manejo de Versiones](1%20on%201%E2%80%99s%20Equipo%20RAM%20553d5c3d4af5421caea3b21a70ef1269/Manejo%20de%20Versiones%20a0a7cd488a2b49e19c1f4baa0f4f1970.md)