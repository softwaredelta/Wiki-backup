# SCRIPT SQL

Assign: Andres, Fabián Enrique Avilés Cortés
Propósito: Write a useful description of the item
Proyecto: Deltalin
Status: Done

# Script

CREATE TABLE Users(
id_user INT(10) AUTO_INCREMENT,

name VARCHAR(25) NOT NULL,

last_name VARCHAR(25) NOT NULL,

id_manager INT(10) NOT NULL,

mail VARCHAR(50) NOT NULL,

password VARCHAR(20) NOT NULL,

PRIMARY KEY (id_user) );

CREATE TABLE Category(

id_category INT(3) AUTO_INCREMENT,

name VARCHAR(8) NOT NULL,

PRIMARY KEY (id_category)

);

CREATE TABLE Form(

id_form INT(10) AUTO_INCREMENT,

id_category INT(10) NOT NULL,

id_user INT(10) NOT NULL,

exterior_grade INT(3) NOT NULL,

interior_grade INT(3) NOT NULL,

client_grade INT(3) NOT NULL,

store_manager_grade INT (3) NOT NULL,

sp_name VARCHAR(50) NOT NULL,

file_link VARCHAR(255) NOT NULL,

duration TIME NOT NULL,

date DATETIME NOT NULL,

PRIMARY KEY (id_form),

FOREIGN KEY (id_user) REFERENCES Users(id_user),

FOREIGN KEY (id_category) REFERENCES Category(id_category)

);

CREATE TABLE Question(

id_question INT(10) AUTO_INCREMENT,

p_text VARCHAR(255) NOT NULL,

section VARCHAR(50) NOT NULL,

camara VARCHAR(255),

btn_na TINYINT NOT NULL,

picture TINYINT NOT NULL,

q_order INT(4) NOT NULL,

PRIMARY KEY (id_question)

);

CREATE TABLE State(

id_state INT(10) AUTO_INCREMENT,

name VARCHAR(45) NOT NULL,

PRIMARY KEY (id_state)

);

CREATE TABLE SellingPoint(

id_sp INT(10) AUTO_INCREMENT,

id_category INT(3) NOT NULL,

id_state INT(10) NOT NULL,

address VARCHAR(255) NOT NULL,

rating FLOAT(5) NOT NULL,

name VARCHAR(50) NOT NULL,

phone INT(10) NOT NULL,

PRIMARY KEY (id_sp),

FOREIGN KEY (id_state) REFERENCES State(id_state),

FOREIGN KEY (id_category) REFERENCES Category(id_category)

);

CREATE TABLE Role(

id_role INT(2) AUTO_INCREMENT,

name VARCHAR(15) NOT NULL,

PRIMARY KEY (id_role)

);

CREATE TABLE UserRole(

id_user INT(10) NOT NULL,

id_role INT(10) NOT NULL,

CONSTRAINT id_user_role PRIMARY KEY (id_user, id_role),

FOREIGN KEY (id_user) REFERENCES Users(id_user),

FOREIGN KEY (id_role) REFERENCES Role(id_role)

);

CREATE TABLE StateUser(

id_user INT(10) NOT NULL,

id_state INT(10) NOT NULL,

CONSTRAINT id_state_user PRIMARY KEY (id_user, id_state),

FOREIGN KEY (id_user) REFERENCES Users(id_user),

FOREIGN KEY (id_state) REFERENCES State (id_state)

);

CREATE TABLE CategoryQuestion(

id_category INT(3) NOT NULL,

id_question INT(10) NOT NULL,

Constraint id_category_question PRIMARY KEY (id_category, id_question),

FOREIGN KEY (id_category) REFERENCES Category(id_category),

FOREIGN KEY (id_question) REFERENCES Question(id_question)

);

---

[Manejo de Versiones](SCRIPT%20SQL%20359d4d5a597c4fbcabb84a82bf37f07c/Manejo%20de%20Versiones%2097a43b39af7f4629ae496ece745bc173.md)