# Guía de Configuración de Ambiente de Desarrollo

Assign: Kenny Eduard Vercaemer González, Jordana Betancourt Menchaca, Ian García González
Propósito: Manual de miembro de departamento; cómo configurar el ambiente de desarrollo para solución Grupo RAM
Proyecto: RAM
Revisión: Monica Ayala
Status: Not started
Tags: Fase: Construcción, Guía
Tipo de Producto: Guía

---

[Manejo de Versiones](Gui%CC%81a%20de%20Configuracio%CC%81n%20de%20Ambiente%20de%20Desarrollo%202593ce94a53d40ea8b065fedb9fe64f4/Manejo%20de%20Versiones%2058b325ce98e746b29836117b5bf21aaa.md)