# WBS Departamental

Assign: Monica Ayala, Kenny Eduard Vercaemer González, Diego Emilio Barrera Hernández, Olivia Araceli Morales Quezada, Erick Alfredo García Huerta
Propósito: Work breakdown structure basado en áreas de proceso, en constante actualizaciòn
Proyecto: Departamento
Status: Ongoing
Tags: Maps, Procesos
Tipo de Producto: Process Map

[https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FMLxydIsNZP54E1IOcKCnlz%2FWBS%3Ft%3DlnM3qkBrrFJ6xTuR-6](https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FMLxydIsNZP54E1IOcKCnlz%2FWBS%3Ft%3DlnM3qkBrrFJ6xTuR-6)

[Manejo de Versiones ](WBS%20Departamental%20a000e7823a2841fbaf0c3c1aabef58a2/Manejo%20de%20Versiones%20466d6bce3c654453aefaed7dc6a87450.md)