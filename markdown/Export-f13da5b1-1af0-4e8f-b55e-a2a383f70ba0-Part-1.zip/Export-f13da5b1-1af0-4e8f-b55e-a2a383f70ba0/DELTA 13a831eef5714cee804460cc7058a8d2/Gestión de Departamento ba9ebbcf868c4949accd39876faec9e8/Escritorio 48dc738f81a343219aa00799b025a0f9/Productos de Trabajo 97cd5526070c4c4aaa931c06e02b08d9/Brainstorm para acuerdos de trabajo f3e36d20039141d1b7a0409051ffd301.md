# Brainstorm para acuerdos de trabajo

Assign: Monica Ayala
Propósito: Figma con ideas para acuerdos de trabajo
Proyecto: Departamento
Status: Done
Tags: Links
Tipo de Producto: Figjam teamwork templates

<aside>
💡 Todos los miembros del departamento Delta participaron en la creación de acuerdos.

</aside>

### Minuta de la reunión:

[Minuta Delta Dinámica de equipo 22 de febrero](../Minutas%20e965603921e44ffda4d53ea85fd9db3a/Minutas%20Departamentales%208d810c8e772248e3aed9f8e60ffad3e7/Minuta%20Delta%20Dina%CC%81mica%20de%20equipo%2022%20de%20febrero%20668abc617be74063b5c90c3c44d73179.md)

### Artículo base para el diseño de la dinámica:

[Estrategia Acuerdos de trabajo | Atlassian](https://www.atlassian.com/es/team-playbook/plays/working-agreements)

### Los acuerdos consolidados se encuentran en:

[Manejo de Versiones ](Brainstorm%20para%20acuerdos%20de%20trabajo%20f3e36d20039141d1b7a0409051ffd301/Manejo%20de%20Versiones%20f1917000157b40d5adec8890b69ecc84.md)