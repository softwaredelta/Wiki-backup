# Proceso de creación de capacitación técnica

Assign: Alejandro Mtz. Luna, José Ángel Rico Mendieta
Propósito: Generar un apoyo para mejorar las habilidades y conocimientos técnicos de los miembros del equipo acerca de las tecnologías a implementar en el proyecto 
Status: Not started

## ********************************************Objetivo:********************************************

Generar un apoyo para mejorar las habilidades y conocimientos técnicos de los miembros del equipo acerca de las tecnologías a implementar en el proyecto, para trabajar de manera más eficiente y ahorrar tiempo en el proceso. 

## ****************************************Entradas de proceso:****************************************

Tema que se busque ejemplificar y/o aclarar del stack tecnológico elegido para el desarrollo del proyecto.

## **********************************Pasos de proceso:**********************************

[Etapas de proceso (3)](Proceso%20de%20creacio%CC%81n%20de%20capacitacio%CC%81n%20te%CC%81cnica%204cb9a615b6ee4e6fa8b2e9147cc95f91/Etapas%20de%20proceso%20(3)%20691f516d72a24153839c56a5e596eb0b.md)

## **************************************Salidas de proceso:**************************************

Material audiovisual disponible al alcance de los miembros del equipo, así como de carácter público .

## Monitorización o Métricas**************************************:**************************************

1. Los Team Leads y el equipo del CMMI revisan la planeación.

## ********************************************Notas y sugerencias para el futuro:********************************************

1. Agregar áreas del CMMI

---

[Historial de Cambios ](Proceso%20de%20creacio%CC%81n%20de%20capacitacio%CC%81n%20te%CC%81cnica%204cb9a615b6ee4e6fa8b2e9147cc95f91/Historial%20de%20Cambios%20adca2b43baae4f06bbc9feb29e1085ca.md)