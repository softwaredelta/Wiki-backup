# Formato Plan de Pruebas

Assign: Cristian Rico
Propósito: Propuesta de contenido para el Plan de Pruebas
Proyecto: Departamento
Revisión: Monica Ayala, Olivia Araceli Morales Quezada, Jordana Betancourt Menchaca, Ian García González, Arisbeth Aguirre Pontaza, Jorge Guerrero Díaz
Status: Done
Tags: Docs, Fase: Diseño, Formatos
Tipo de Producto: Formato

[Formato para Plan de Pruebas](https://docs.google.com/document/d/1ZUT9klmE6pdx4cedEIfv_ommx6stUc8dAmMivL7ycfY/edit?usp=drivesdk)

---

[Manejo de Versiones](Formato%20Plan%20de%20Pruebas%209e75121b7a9447b5ad80c950f95462e7/Manejo%20de%20Versiones%20454eb580b9a74235a71a1f3b095405b4.md)