# Project Charter RAM

Assign: Jordana Betancourt Menchaca, Ana Karen López Baltazar, Olivia Araceli Morales Quezada, Alejandro Mtz. Luna
Propósito: Project Charter: Grupo de Asesores RAM
Proyecto: RAM
Status: In progress
Tags: Docs
Tipo de Producto: Acta Constitutiva / Project Charter

Liga al documento:

[Project Charter RAM.docx](https://docs.google.com/document/d/1FkV-xZ-sY4xmN3D1ipIwma0IQc3pZzCV/edit?usp=sharing&ouid=103569039125423380255&rtpof=true&sd=true)

---

[Manejo de Versiones](Project%20Charter%20RAM%20d5d19b8c85204b2bad8a63ba2c56d59a/Manejo%20de%20Versiones%200927f840e63b4c76bdd2269aa7f47571.md)