# Acuerdo del Uso de Espacios

Assign: Olivia Araceli Morales Quezada, Monica Ayala
Propósito: Tener una negociación con los PMs del otro departamento para llegar un acuerdo sobre el uso del Salón 2001.
Proyecto: Departamento
Status: In progress
Tags: Acuerdos, External

TODO:

- [x]  Contactar a los PMs.
- [ ]  Generar una propuesta.
- [ ]  Acordar un horario.
- [ ]  Considerar a los profesores y departamento.
- [ ]  Preparar distintos escenarios y argumentos para negociar.

## Inquietudes de otro salón:

- B

## Propuestas:

- Hacer un calendario por solicitud para el uso del salón en los tiempos no asignados.
- Cambio por semana.
- Usar prepa.
- Tener el salón asignado un periodo, con opción de

[Manejo de Versiones ](Acuerdo%20del%20Uso%20de%20Espacios%2053e06bfa91ca4f758e08bdd046b6ba73/Manejo%20de%20Versiones%20d02899c859a04e4ebfbcfbf203943bc8.md)