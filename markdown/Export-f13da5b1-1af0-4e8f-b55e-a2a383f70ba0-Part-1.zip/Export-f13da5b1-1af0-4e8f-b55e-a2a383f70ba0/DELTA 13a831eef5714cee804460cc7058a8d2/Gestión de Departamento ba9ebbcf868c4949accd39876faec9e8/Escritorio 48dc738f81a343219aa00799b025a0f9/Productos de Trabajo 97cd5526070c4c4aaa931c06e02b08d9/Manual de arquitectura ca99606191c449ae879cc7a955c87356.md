# Manual de arquitectura

Assign: Emiliano Vásquez Olea
Propósito: Ubicado en principal de Michelin
Proyecto: Deltalin
Status: Not started

# Título

Este es un producto de trabajo del departamento, asegúrate de iniciar la tabla de versiones al terminar.

Cada vez que se genera una versión, debes copiar el contenido del documento y agregarlo a la entrada correspondiente en la tabla de versiones.

Cada cambio deberá ser revisado por algún otro responsable.

Asegúrate también de asignar el tipo de producto de trabajo en las propiedades de arriba, si no existe puedes crear una. Estos tipos de producto estarán relacionados 1 a 1 en el mapa de procesos de la organización.

---

[Manejo de Versiones](Manual%20de%20arquitectura%20ca99606191c449ae879cc7a955c87356/Manejo%20de%20Versiones%20c68e1dfe06f94418b400f6cc14c87d7e.md)