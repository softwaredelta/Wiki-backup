# Formato Estrategia de Desarrollo

Assign: Cristian Rico
Propósito: Formato para la estrategia de desarrollo de un proyecto
Proyecto: Departamento
Revisión: Monica Ayala
Status: Done
Tags: Docs, Fase: Análisis, Gestión
Tipo de Producto: Formato
URL: https://docs.google.com/document/d/1XNUy4WQy5p6Ml8u4I3aYsCHv4fLtVNf7B5X9RbqI-2w/edit?usp=drivesdk

[Formato de Estrategia de Desarrollo](https://docs.google.com/document/d/19AnGZXf6k4UzC3NbKCXgOU1cdHr0q4dEcFw7FVxoesI/edit?usp=drivesdk)

---

[Manejo de Versiones](Formato%20Estrategia%20de%20Desarrollo%20f41c1e8267b34c0f8a917af3c6d05dfc/Manejo%20de%20Versiones%204a583d0633b143fc90e7edb4dbfe56b9.md)