# Formato para procesos

Assign: Monica Ayala, Kenny Eduard Vercaemer González
Propósito: Formato para la estandarización de procesos
Proyecto: Departamento
Status: Done
Tags: Formatos, Procesos

<aside>
💡 También existe la template en la página de [](../../WoW%2022e4d144a8f047fb836aa77da202a397/Procesos%20fac78b4699564ea0915cdcb6bf4132b2.md)

</aside>

## ********************************************Objetivo********************************************

## ****************************************Entradas de proceso****************************************

## **********************************Pasos de proceso**********************************

[Etapas de proceso (3)](Formato%20para%20procesos%202513507e3e8844109be1a894de59e2a1/Etapas%20de%20proceso%20(3)%20ece33fbb39cd4ce2add36b6bf5e042c4.md)

## **************************************Salidas de proceso**************************************

## Monitorización o Métricas

## ********************************************Notas y sugerencias para el futuro********************************************

## ********Historial de cambios********

[Manejo de versiones (1)](Formato%20para%20procesos%202513507e3e8844109be1a894de59e2a1/Manejo%20de%20versiones%20(1)%209f886c5a84c54596bbc16eda3b428e7e.md)