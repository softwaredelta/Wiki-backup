# Transición de PMs

Assign: Olivia Araceli Morales Quezada
Propósito: Tenemos que encontrar una forma de realizar el cambio de Rol. Tomando en cuenta la iniciativa personal y las consideraciones del departamento. 
Proyecto: Departamento
Status: Ongoing
Tags: Procesos

Este espacio tiene la finalidad de hacer la transición de roles de la manera más idónea posible. 

### Ronda de preguntas

¿Qué inquietudes tienes respecto al rol?

¿Algo te preocupa?

¿Hay algo que pueda hacer en estos momentos para aclarar tus pensamientos?

**Reflexión del PM**

Algunas que cosas que he aprendido.

La primera descripción que recuerdo de este rol es la siguiente:

El trabajo de un PM se enfoca en mejorar el ambiente del departamento, es el encargado de quitar los obstáculos que se presenten en los proyectos y es el que vela por 

Mi rol como PM no se trata de tomar todas la decisiones, a veces la mejor decisión es guiar a otro para que la tome.

[Manejo de Versiones ](Transicio%CC%81n%20de%20PMs%2079f0cc1728124e4eb93ae2b369e599e1/Manejo%20de%20Versiones%202969f261dbb745098c5e85cc1570619a.md)