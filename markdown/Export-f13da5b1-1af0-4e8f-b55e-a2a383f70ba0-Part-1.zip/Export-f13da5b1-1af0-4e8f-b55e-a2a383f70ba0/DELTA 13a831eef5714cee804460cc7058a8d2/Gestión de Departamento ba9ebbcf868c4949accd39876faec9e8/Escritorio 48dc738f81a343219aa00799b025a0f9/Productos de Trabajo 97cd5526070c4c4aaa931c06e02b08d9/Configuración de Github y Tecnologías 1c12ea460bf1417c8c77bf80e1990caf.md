# Configuración de Github y Tecnologías

Assign: Emiliano Vásquez Olea
Propósito: Write a useful description of the item
Proyecto: Deltalin
Status: In progress

## Configuración actual de repositorio de Michelin

- Limitado el acceso a rama Main
- Agrega .gitignore de Node (Aplicación Web)

### Estándares

Branches:

- Nombres con formato MX_HX, con número de (M)ódulo e (H)istoria de usuario
- Ramas develop y main estarán protegidas, solo será posible hacer merge a ellas desde otras ramas (pull requests)

PR (Pull Request):

- Titulo : En ingles, accion principal del PR
- Comment: Lista de los archivos que cambiaron, y que cambio en cada uno

**Ejemplo:**

![Captura de Pantalla 2023-03-08 a la(s) 16.35.47.png](Configuracio%CC%81n%20de%20Github%20y%20Tecnologi%CC%81as%201c12ea460bf1417c8c77bf80e1990caf/Captura_de_Pantalla_2023-03-08_a_la(s)_16.35.47.png)

Issues : 

- Id_issue
- Tags
- Titulo en ingles
- Changelog en lista

Ejemplo:

![Captura de Pantalla 2023-03-08 a la(s) 16.37.08.png](Configuracio%CC%81n%20de%20Github%20y%20Tecnologi%CC%81as%2017084795b1ec493ba1a9c9d17fef44a2/Captura_de_Pantalla_2023-03-08_a_la(s)_16.37.08.png)

Commits:

- Tag
- Mantener descripciones y títulos cortos y precisos sobre el cambio que realizó
- En Inglés

Ejemplo:

![Captura de Pantalla 2023-03-08 a la(s) 16.38.21.png](Configuracio%CC%81n%20de%20Github%20y%20Tecnologi%CC%81as%201c12ea460bf1417c8c77bf80e1990caf/Captura_de_Pantalla_2023-03-08_a_la(s)_16.38.21.png)

---

[Manejo de Versiones](Configuracio%CC%81n%20de%20Github%20y%20Tecnologi%CC%81as%201c12ea460bf1417c8c77bf80e1990caf/Manejo%20de%20Versiones%2024d78a5df8e14ac282691d982b55ca1b.md)