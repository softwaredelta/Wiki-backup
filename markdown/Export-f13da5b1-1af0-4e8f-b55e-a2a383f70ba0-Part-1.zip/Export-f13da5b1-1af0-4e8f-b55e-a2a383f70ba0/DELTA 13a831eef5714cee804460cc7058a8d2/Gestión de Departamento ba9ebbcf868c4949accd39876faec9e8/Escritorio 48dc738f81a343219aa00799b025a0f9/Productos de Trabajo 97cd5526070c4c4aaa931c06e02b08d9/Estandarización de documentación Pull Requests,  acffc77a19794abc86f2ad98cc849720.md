# Estandarización de documentación: Pull Requests, Issues

Assign: Alejandro Mtz. Luna, Ian García González
Propósito: Write a useful description of the item
Proyecto: RAM
Status: Ongoing
Tags: Docs
Tipo de Producto: Guía

# Github Projects

[Github Projects ](Estandarizacio%CC%81n%20de%20documentacio%CC%81n%20Pull%20Requests,%20%20acffc77a19794abc86f2ad98cc849720/Github%20Projects%20bc8831df4cd2463ca98b1523bbdc5121.md)

---

[Manejo de Versiones](Estandarizacio%CC%81n%20de%20documentacio%CC%81n%20Pull%20Requests,%20%20acffc77a19794abc86f2ad98cc849720/Manejo%20de%20Versiones%20f8e65103df4f4f8eba80173e16b25b19.md)