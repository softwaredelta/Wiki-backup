# Draft de la guía para estimación del proyecto

Assign: Monica Ayala, Olivia Araceli Morales Quezada, Cristian Rico
Propósito: Write a useful description of the item
Proyecto: Departamento
Revisión: Jorge Guerrero Díaz, Cristian Rico, Olivia Araceli Morales Quezada
Status: In progress
Tags: Estimación, Formatos, Procesos
Tipo de Producto: Formato

Es muy importante tener las estimaciones del proyecto, para que si les preguntan el tamaño o presupuesto en horas del mismo puedan responder. Para ello están los siguientes pasos:

1. Estimar las actividades del proyecto a GRANDES RASGOS. Esto se puede hacer utilizando el WBS que hicieron y traspasándolo a formato de pila (task pile) para de allí poder hacer el plan de valor ganado. He visto como hicieron su tasks pile y me gustó mucho, la veo sp bien, solo le agregaría a grandes rasgos todas las fases/interaciones del proyecto. Si quieren basarse en la de RAM, les dejo el link: ([https://docs.google.com/spreadsheets/d/12JDmCfbE0bqTtf2y8qr1qal6UvWUoREaz4KtkNTETKc/edit?usp=drivesdk](https://docs.google.com/spreadsheets/d/12JDmCfbE0bqTtf2y8qr1qal6UvWUoREaz4KtkNTETKc/edit?usp=drivesdk))
2. Estimar la disponibilidad del equipo. Esto es, cuantas horas puede su equipo trabajar de manera efectiva en un dado día. Les dejo un link a un formato que pueden usar para hacer los cálculos dinámicos dependiendo del día de la semana. Otras alternativas es decir que todos los días trabajarán x cantidad de hrs, pero recomendamos Oli y yo más la versión dinámica, de la cual luego se sacará un promedio para el plan de valor ganado. Link a potencial formato ([https://docs.google.com/spreadsheets/d/12JDmCfbE0bqTtf2y8qr1qal6UvWUoREaz4KtkNTETKc/edit?usp=drivesdk](https://docs.google.com/spreadsheets/d/12JDmCfbE0bqTtf2y8qr1qal6UvWUoREaz4KtkNTETKc/edit?usp=drivesdk))
3. Convertir sus estimaciones de TAMAÑO (Agile Points) a estimaciones de ESFUERZO (Horas efectivas). Aquí les dejo el formato que usó RAM (link: [https://docs.google.com/spreadsheets/d/1JiViPcaZfIf__h6T8nMRtCNjo9IaxU2T-4b3bOcamy0/edit?usp=sharing](https://docs.google.com/spreadsheets/d/1JiViPcaZfIf__h6T8nMRtCNjo9IaxU2T-4b3bOcamy0/edit?usp=sharing)) donde todos en el equipo dijeron cuanto creen que toma de tiempo en minutos una HU dependiendo de su valor en AP, luego promediaron los valores y finalmente los duplicaron (para mitigar el error de estimación).

Alternativamente les dejo el link que usó ACE, el departamento anterior, para hacer lo mismo pero ahora dependiendo de la tarea (link: [https://docs.google.com/spreadsheets/d/1MRO5T_VGLGJf0tEX8OwmFtHVbBq0HBad/edit?usp=drivesdk&ouid=104685609645227355073&rtpof=true&sd=true](https://docs.google.com/spreadsheets/d/1MRO5T_VGLGJf0tEX8OwmFtHVbBq0HBad/edit?usp=drivesdk&ouid=104685609645227355073&rtpof=true&sd=true)) y ya no es tanto dependiendo de cada uno del equipo, aunque pueden ponerse de acuerdo para decidir cuanto representa en hrs cada actividad de tantos AP.

Finalmente, recuerden que:

- una buena estimación es dada en rangos.
- es importante ajustar las estimaciones después de cierto tiempo de trabajo, reflexionando en los datos históricos.
- esto se hace para poder tener un plan de proyecto claro y factible.

---

[Manejo de Versiones](Draft%20de%20la%20gui%CC%81a%20para%20estimacio%CC%81n%20del%20proyecto%2079b062b5c2e646a4bb96a3171177633e/Manejo%20de%20Versiones%2073355d3c332e45389f9b7709e5c9f6a2.md)