# Diccionario de Datos

Assign: Alejandro Mtz. Luna, José Ángel Rico Mendieta, Diego Emilio Barrera Hernández
Propósito: Documento donde está definido el Diccionario de Datos 
Proyecto: RAM
Status: In progress
Tags: Fase: Diseño
Tipo de Producto: MER
URL: https://docs.google.com/document/d/1QKigzBeJi3-Uc_loyM5WyPP5Rmu-xKPBHVLQfX0eWVA/edit

[](https://docs.google.com/document/d/1QKigzBeJi3-Uc_loyM5WyPP5Rmu-xKPBHVLQfX0eWVA/edit)

---

[Manejo de Versiones](Diccionario%20de%20Datos%2079fead8e8b2848708184742955fab18a/Manejo%20de%20Versiones%205703a44cbdc3494fa222e9ddfdb2cfe8.md)