# Matriz de Trazabilidad

Assign: Andres
Propósito: Write a useful description of the item
Proyecto: Deltalin
Status: Done

---

[Manejo de Versiones](Matriz%20de%20Trazabilidad%208453d017b06042dbbbbc64d7ab86fa75/Manejo%20de%20Versiones%2070817e5f2315437488dd2d1ad6fc4b30.md)