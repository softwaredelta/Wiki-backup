# Diseño de Figma

Assign: Jordana Betancourt Menchaca, Ana Karen López Baltazar, Alejandro Mtz. Luna
Propósito: Prototipo visual inicial 
Proyecto: RAM
Status: Done
Tags: Diseños, Fase: Diseño, Links
Tipo de Producto: UI Design in Figma
URL: https://www.figma.com/file/bBoLNzlrideevYMrwQ18vl/Prototipo-RAM?node-id=0%3A1&t=m2YNhsKIyBLRAMXG-0

[Prototipo RAM](https://www.figma.com/file/bBoLNzlrideevYMrwQ18vl/Prototipo-RAM?node-id=0%3A1&t=m2YNhsKIyBLRAMXG-0)

---

[Manejo de Versiones](Disen%CC%83o%20de%20Figma%20b0136eb7c9f64d3c9b48651e1adc5300/Manejo%20de%20Versiones%208344efcc02834cd4aeed6def37ceabb1.md)