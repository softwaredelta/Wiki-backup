# Plan de Pruebas RAM

Assign: Ian García González, Kenny Eduard Vercaemer González, Erick Alfredo García Huerta
Propósito: Especifica las pruebas que de le harán al sistema.
Proyecto: RAM
Revisión: Jordana Betancourt Menchaca
Status: Review
Tags: Docs, Fase: Diseño
URL: https://docs.google.com/document/d/13Ub3k908YH7pWSOpf6mqaAesZNet_VYGvESK7Xjj7uE/edit?usp=sharing

# Formato a usar

<aside>
💡 Hacer una copia, no editar sobre el ****************formato.****************

</aside>

[Formato para Plan de Pruebas](https://docs.google.com/document/d/1ZUT9klmE6pdx4cedEIfv_ommx6stUc8dAmMivL7ycfY/edit?usp=drivesdk)

---

[Manejo de Versiones](Plan%20de%20Pruebas%20RAM%205d36dccfafce4de6a29f1077d8ccdaea/Manejo%20de%20Versiones%201ef18f60408840808a4c80246afce104.md)