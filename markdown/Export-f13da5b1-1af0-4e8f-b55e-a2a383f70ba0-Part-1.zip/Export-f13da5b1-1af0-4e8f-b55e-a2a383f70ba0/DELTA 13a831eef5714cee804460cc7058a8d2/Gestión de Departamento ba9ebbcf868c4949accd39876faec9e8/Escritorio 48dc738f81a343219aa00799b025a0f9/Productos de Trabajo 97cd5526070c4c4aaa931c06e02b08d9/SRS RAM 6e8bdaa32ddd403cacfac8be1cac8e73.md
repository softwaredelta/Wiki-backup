# SRS RAM

Assign: José Ángel Rico Mendieta, Alejandro Mtz. Luna
Propósito: Documento donde se definen los Software Requirements Specification (SRS)
Proyecto: RAM
Revisión: Jordana Betancourt Menchaca, Rodrigo Muñoz Guerrero
Status: Review
Tags: Formatos
Tipo de Producto: SRS
URL: https://docs.google.com/document/d/1hp85FsOnveH8VG93WsLhZbQDG3BhlJIM/edit

### Documento Base

[SRS+SIA Subrayado.pdf](SRS%20RAM%206e8bdaa32ddd403cacfac8be1cac8e73/SRSSIA_Subrayado.pdf)

# Documento de SRS

[SRS.docx](https://docs.google.com/document/d/1hp85FsOnveH8VG93WsLhZbQDG3BhlJIM/edit?usp=drivesdk&ouid=105373896302172230836&rtpof=true&sd=true)

---

[Manejo de Versiones ](SRS%20RAM%206e8bdaa32ddd403cacfac8be1cac8e73/Manejo%20de%20Versiones%201bfde4dcc3244255bd59300f67312015.md)