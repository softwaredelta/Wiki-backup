# Diagramas de Arquitectura

Assign: Kenny Eduard Vercaemer González, Ian García González, Jordana Betancourt Menchaca
Propósito: Diagramas de arquitectura. Se describe la arquitectura general del sistema. Se describe la arquitectura de load balancing del backend.
Proyecto: RAM
Status: Done
Tags: Fase: Diseño
Tipo de Producto: Architecture Diagram

---

[Historias de Usuario](Diagramas%20de%20Arquitectura%20c0de2687b4e6411787326fdb08b06503/Historias%20de%20Usuario%20e7c293a7a5e84332ab1a8162fff05563.md)

[Plan de Recursos RAM](Diagramas%20de%20Arquitectura%20c0de2687b4e6411787326fdb08b06503/Plan%20de%20Recursos%20RAM%2088f7baadac684fabb786abd0abb23b9b.md)