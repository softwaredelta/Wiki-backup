# Diseño de Componentes Móvil

Assign: Ricardo Nuñez Alanis, Fabián Enrique Avilés Cortés
Propósito: Write a useful description of the item
Proyecto: Deltalin
Revisión: Jorge Guerrero Díaz, Arisbeth Aguirre Pontaza
Status: Done

# Componentes

View de Formulario:

- Punto de interacción: Call to action dentro de la sección del Punto de Venta a revisar.
- Campo pregunta: View con la pregunta sobre punto de venta, cliente o gerente. Incluye los botones semáforo, botón foto y botón siguiente pregunta.
- Botones semáforo: Set de 2 o 3 botones dependiendo de la pregunta. Estos botones son botón verde (si), botón rojo (no) y botón n/a.
- Botón foto: Sólo aplica en caso de que se requiera evidenciar el porque se selecciona el botón rojo del semáforo, para evidenciar esa falta.
- Botón siguiente pregunta: Botón para continuar a la siguiente pregunta o sección del recorrido.

View de Menú Tiendas:

- Botón PDV: Navegar a la siguiente view del PDV seleccionado, este encontrará cual es gracias a la base de datos.

View de Menú Tiendas Historial:

- Botón PDV: Navegar a la siguiente view del PDV seleccionado, este encontrará cual es gracias a la base de datos.
- View de métricas: Este se desplegara del menu y mostrara las métricas del recorrido mas reciente

View Barra de Progreso:

- Preparación: Botón dentro de la barra de progreso que dejará al usuario navegar a la view de Etapa 1: Preparación.
- Interior: Botón dentro de la barra de progreso que dejará al usuario navegar a la view de Etapa 2: Interior.
- Exterior: Botón dentro de la barra de progreso que dejará al usuario navegar a la view de Etapa 3: Exterior.
- Usuario: Botón dentro de la barra de progreso que dejará al usuario navegar a la view de Etapa 4: Usuario.
- Gerente: Botón dentro de la barra de progreso que dejará al usuario navegar a la view de Etapa 5: Gerente.

---

[Manejo de Versiones](Disen%CC%83o%20de%20Componentes%20Mo%CC%81vil%2003186d1d52cc41269c0edbf653be35e3/Manejo%20de%20Versiones%203fc4b2c5de9749eb94c0632b0199ba36.md)