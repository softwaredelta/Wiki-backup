# Formato Requisitos Funcionales

Assign: Mónica Andrea Ayala Marrero, Rodrigo Muñoz Guerrero, Jordana Betancourt Menchaca, Olivia Araceli Morales Quezada, Alejandro Mtz. Luna
Propósito: Especificación de formato para requisitos funcionales de Grupo RAM
Proyecto: RAM
Status: Done
Tags: Fase: Diseño
Tipo de Producto: Formato

[https://docs.google.com/spreadsheets/d/1ijuDjWE1UxtgRoeekSNPiPbB5AByjpyzYiSnwvLzQ4Q/edit?usp=sharing](https://docs.google.com/spreadsheets/d/1ijuDjWE1UxtgRoeekSNPiPbB5AByjpyzYiSnwvLzQ4Q/edit?usp=sharing)

---

[Manejo de Versiones](Formato%20Requisitos%20Funcionales%20afa56b64a44d46d683aebce7ea836740/Manejo%20de%20Versiones%201e89540a50134c9088af374fdaf6a75e.md)