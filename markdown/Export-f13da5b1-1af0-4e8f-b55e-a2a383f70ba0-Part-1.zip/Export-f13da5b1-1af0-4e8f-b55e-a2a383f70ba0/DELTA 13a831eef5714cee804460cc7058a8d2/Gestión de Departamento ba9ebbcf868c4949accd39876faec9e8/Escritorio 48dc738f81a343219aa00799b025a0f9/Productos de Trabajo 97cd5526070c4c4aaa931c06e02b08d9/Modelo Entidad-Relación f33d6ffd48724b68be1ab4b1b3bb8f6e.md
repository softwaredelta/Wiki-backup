# Modelo Entidad-Relación

Assign: Alejandro Mtz. Luna, José Ángel Rico Mendieta, Emiliano Vásquez Olea, Reno, Rodrigo Muñoz Guerrero, Diego Emilio Barrera Hernández
Propósito: Diseño del Modelo Entidad Relación del proyecto
Proyecto: RAM
Status: Review
Tags: Fase: Diseño
Tipo de Producto: MER
URL: https://drive.google.com/file/d/1QBu9MIgf4_5zMc4ZJLQIsPbjNl3I_8Qu/view?usp=sharing

![Untitled](Modelo%20Entidad-Relacio%CC%81n%20f33d6ffd48724b68be1ab4b1b3bb8f6e/Untitled.png)

---

[Manejo de Versiones](Modelo%20Entidad-Relacio%CC%81n%20f33d6ffd48724b68be1ab4b1b3bb8f6e/Manejo%20de%20Versiones%20897798f1abe3404eb406ca02dc702f24.md)