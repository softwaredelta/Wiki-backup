# Presupuesto para pruebas de Arquitectura

Assign: Kenny Eduard Vercaemer González, Rodrigo Muñoz Guerrero
Propósito: Confirmar si se tiene presupuesto para ejecutar pruebas de arquitectura verdaderas con la infraestructura real
Proyecto: RAM
Status: Not started

---

[Manejo de Versiones](Presupuesto%20para%20pruebas%20de%20Arquitectura%208a0614025a7f49029c67fc7b5837e650/Manejo%20de%20Versiones%204ebdef06b752462080b2262bf330782a.md)