# Capacitación técnica necesaria para departamento

Assign: Alejandro Mtz. Luna, José Ángel Rico Mendieta
Propósito: Creación de contenido y documentación de tecnologías que puedan ser usadas por el departamento para la fase de desarrollo 
Proyecto: RAM
Status: Ongoing
Tags: Docs
Tipo de Producto: Guía

[Creando una aplicación web con REACT + VITE + TAILWINDCSS || V00](https://www.youtube.com/watch?v=k-CWnM6UFZw&list=PLi-_uVfvMaGEOs0hMSVTQGpo-VmpVKJj1)

[https://www.youtube.com/watch?v=k-CWnM6UFZw&list=PLi-_uVfvMaGEOs0hMSVTQGpo-VmpVKJj1](https://www.youtube.com/watch?v=k-CWnM6UFZw&list=PLi-_uVfvMaGEOs0hMSVTQGpo-VmpVKJj1)

---

[Manejo de Versiones](Capacitacio%CC%81n%20te%CC%81cnica%20necesaria%20para%20departamento%204e34cd48f5dc4101991a42095a4ab563/Manejo%20de%20Versiones%205772c8e2d6af401b9ff38d54e908376f.md)