# Requerimientos no Funcionales

Assign: Kenny Eduard Vercaemer González, Rodrigo Muñoz Guerrero, Jordana Betancourt Menchaca, Reno
Propósito: Especificación de requerimientos no funcionales para solución de Grupo RAM. Incluye rendimiento, compatibilidad, usabilidad, etc.
Proyecto: RAM
Status: Done
Tags: Fase: Diseño
Tipo de Producto: NFR Spec

********Definiciones:******** Los siguientes términos serán utilizados y compartidos en el resto del documento.

- *********************************INTERACCIÓN*********************************: Se refiere a una acción en la página web. Ejemplos son: hacer click en un botón, enviar un formulario, descargar un archivo, recargar una tabla de datos.
- *********************************************USUARIO ACTIVO*********************************************: Se refiere a un usuario con una sesión activa en la página web. Este usuario no está realizando acciones o interactuando con la página, pero puede estar recibiendo datos continuamente.
- *********************************************************USUARIO INTERACTIVO*********************************************************: Se refiere a un usuario con una sesión activa en la página web. Este usuario realiza acciones continuamente, como pedir una lista de datos, o enviar formularios.
- ***************************************************************UTILIZACIÓN REGULAR***************************************************************: Se refiere a **30 usuarios activos** (pero no realizando acciones, es decir, sólo existen las sesiones activas, sin interacción directa) y **10 usuarios interactivos**.
- *******UTILIZACIÓN ELEVADA*******: Se refiere a **60 usuarios activos** (pero no realizando acciones, es decir, sólo existen las sesiones activas, sin interacción directa) y **15 usuarios interactivos**.

******************************Notas de autor:******************************

- Las secciones en letra color rojo, están pendientes de revisión.

---

## Rendimiento y Escalabilidad

¿Qué tan rápido el sistema arroja resultados?

¿Qué tanto puede cambiar este rendimiento bajo cargas de trabajo elevadas?

**********NFR-RE01.1:********** La carga inicial de la página web - sin importar la página destino - bajo *********************************UTILIZACIÓN REGULAR*********************************, tendrá un **tiempo promedio para interactividad menor a 10 segundos**.

**********NFR-RE01.2:********** La carga inicial de la página web - sin importar la página destino - bajo *********************************UTILIZACIÓN ELEVADA*********************************, tendrá un **tiempo promedio para interactividad menor a 15 segundos**.

******************NFR-RE02.1:****************** El tiempo de carga o actualización después de cualquier interacción en la página web bajo ******************UTILIZACIÓN REGULAR******************, tendrá un **tiempo promedio de resultados menor a 5 segundos**.

******************NFR-RE02.2:****************** El tiempo de carga o actualización después de cualquier interacción en la página web bajo ******************UTILIZACIÓN ELEVADA******************, tendrá un **tiempo promedio de resultados menor a 7 segundos**.

******************NFR-RE03:****************** El tiempo de respuesta promedio de la base de datos bajo *********************************************************UTILIZACIÓN REGULAR*********************************************************, **será menor a 500ms**.

******************NFR-RE04:****************** El sistema de almacenamiento de archivos podrá escalar su capacidad sin la interrupción del sistema principal.

************************NFR-RE05.1:************************ La API del sistema deberá generar respuestas bajo ***************************UTILIZACIÓN REGULAR*************************** **en un tiempo promedio menor a 3 segundos**.

************************NFR-RE05.2:************************ La API del sistema deberá generar respuestas bajo ***************************UTILIZACIÓN ELEVADA********* en un tiempo promedio menor a 5 segundos**.

## Mantenibilidad, Disponibilidad y Fiabilidad

¿Qué tan seguido el sistema experimenta fallas críticas?

¿Cómo se compara el tiempo de disponibilidad del sistema al tiempo de no operación?

********************NFR-MDF01.1:******************** El **tiempo de no operación debido a fallas** de infraestructura será menor al **0.01%**.

**************************NFR-MDF01.2:************************** El **tiempo de no operación debido a fallas por despliegue** de código será menor a 1 hora por incidente. En estos casos,, se recurrirá a un rollback de versiones pasadas para activar el sistema de nuevo temporalmente hasta encontrar una solución.

## Compatibilidad y Portabilidad

¿Qué hardware, software, sistemas operativos, browsers, y sus versiones, serán soportados por el sistema?

******************NFR-CP01:****************** El sistema soportará oficialmente la versión de **Node 16**.

******************NFR-CP02:****************** El sistema soportará oficialmente servidores con sistema operativo **Amazon Linux 2 64bits**.

********************NFR-CP03:******************** El sistema soportará oficialmente únicamente las **últimas versiones de los navegadores de Chromium**.

****************NFR-CP04:**************** El sistema soportará oficialmente una base de datos compatible con ************************Postgres 14.6.************************

## Usabilidad

****************NFR-U01:**************** El usuario promedio tardará menos de **60 segundos** en encontrar el área necesaria para realizar una operación.

## Localización

****************NFR-L01:**************** La página web únicamente soportará el **idioma Español**.

## Seguridad

******NFR-S01******: Todos los archivos almacenados por el sistema, estarán protegidos por pólizas de autenticación y autorización.

**NFR-S02:** La base de datos estará protegida por pólizas de autenticación y autorización.

********NFR-S03:******** El acceso a la página web únicamente será mediante HTTPS.

**NFR-S04:** La autenticación **utilizará tokens de acceso y de refrescamiento** con duraciones apropiadas para la aplicación.

---

[Manejo de Versiones](Requerimientos%20no%20Funcionales%201767fafda93e4cd1a520f99349e4aa09/Manejo%20de%20Versiones%2055e59832917f40f0b2bacd318b04723a.md)