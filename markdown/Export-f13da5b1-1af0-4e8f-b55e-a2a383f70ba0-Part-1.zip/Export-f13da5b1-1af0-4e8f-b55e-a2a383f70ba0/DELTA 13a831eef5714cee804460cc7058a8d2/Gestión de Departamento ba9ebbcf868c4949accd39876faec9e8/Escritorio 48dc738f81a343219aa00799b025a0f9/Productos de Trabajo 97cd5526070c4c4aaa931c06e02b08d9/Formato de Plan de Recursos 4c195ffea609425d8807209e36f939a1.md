# Formato de Plan de Recursos

Assign: Alejandro Mtz. Luna, Olivia Araceli Morales Quezada, Monica Ayala, Andres, Ana Karen López Baltazar, Jordana Betancourt Menchaca
Propósito: Este es el formatito del Plan de Recursos c:
Proyecto: Departamento
Revisión: Monica Ayala, Olivia Araceli Morales Quezada
Status: Done
Tags: Docs
Tipo de Producto: Formato
URL: https://docs.google.com/document/d/1QCW5IU9PJ2H5b7snuE3pDztd_CvQ-8jsebuPLZjsdDU/edit

[Formato Plan de Recursos](https://docs.google.com/document/d/1QCW5IU9PJ2H5b7snuE3pDztd_CvQ-8jsebuPLZjsdDU/edit?usp=drivesdk)

---

[Manejo de Versiones](Formato%20de%20Plan%20de%20Recursos%204c195ffea609425d8807209e36f939a1/Manejo%20de%20Versiones%204f08122d9e804a0e85cb80e2ca0df8c1.md)