# Actualizar Process Map

Assign: Kenny Eduard Vercaemer González, Monica Ayala, Jordana Betancourt Menchaca
Propósito: Actualización constante del mapa de procesos
Proyecto: Departamento
Status: Ongoing
Tags: Maps, Procesos
Tipo de Producto: Process Map

Hasta ahora el mapa de procesos sólo incluye fases de análisis y diseño. Debemos agregarle componentes de planeación, gestión de riesgos y configuración, gestión de procesos en sí, etc.

[Mapa de Procesos Departamentales](Mapa%20de%20Procesos%20Departamentales%20befbdb83f0284d9690f1761beffb29ce.md)

[Manejo de Versiones ](Actualizar%20Process%20Map%20be930cfd4723421799e97a0e6bdfd67f/Manejo%20de%20Versiones%20583b971389524c79b13b9bb4d6fd2f92.md)