# Especificación de Interfaces de la Arquitectura

Assign: Kenny Eduard Vercaemer González
Status: Not started