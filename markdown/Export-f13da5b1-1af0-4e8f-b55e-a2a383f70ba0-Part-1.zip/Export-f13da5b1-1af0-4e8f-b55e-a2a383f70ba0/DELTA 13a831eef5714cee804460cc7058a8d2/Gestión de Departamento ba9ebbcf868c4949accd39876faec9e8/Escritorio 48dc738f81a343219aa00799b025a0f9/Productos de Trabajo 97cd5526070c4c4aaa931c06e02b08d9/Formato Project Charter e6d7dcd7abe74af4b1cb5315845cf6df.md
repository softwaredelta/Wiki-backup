# Formato Project Charter

Assign: Olivia Araceli Morales Quezada, Monica Ayala, Cristian Rico, Ana Karen López Baltazar
Propósito: Write a useful description of the item
Proyecto: Departamento
Status: Done
Tags: Formatos
Tipo de Producto: Formato

### Formato Base:

[Acta de Proyecto V1.docx](Formato%20Project%20Charter%20e6d7dcd7abe74af4b1cb5315845cf6df/Acta_de_Proyecto_V1.docx)

### Referencias Consultadas:

[BKJ_DT04 Acta de proyecto .docx](https://docs.google.com/document/d/1HQuSYqwVtNIdWTU2tgjJ3QOw-vByQjpR/edit)

[https://thedigitalprojectmanager.com/es/temas/como-hacer-documento-inicio-proyecto/](https://thedigitalprojectmanager.com/es/temas/como-hacer-documento-inicio-proyecto/)

[http://www.pmoinformatica.com/2013/06/plantilla-de-acta-de-proyecto.html](http://www.pmoinformatica.com/2013/06/plantilla-de-acta-de-proyecto.html)

---

[Manejo de Versiones](Formato%20Project%20Charter%20e6d7dcd7abe74af4b1cb5315845cf6df/Manejo%20de%20Versiones%20bea3b194b9cf414b84295b1b3460d0f9.md)