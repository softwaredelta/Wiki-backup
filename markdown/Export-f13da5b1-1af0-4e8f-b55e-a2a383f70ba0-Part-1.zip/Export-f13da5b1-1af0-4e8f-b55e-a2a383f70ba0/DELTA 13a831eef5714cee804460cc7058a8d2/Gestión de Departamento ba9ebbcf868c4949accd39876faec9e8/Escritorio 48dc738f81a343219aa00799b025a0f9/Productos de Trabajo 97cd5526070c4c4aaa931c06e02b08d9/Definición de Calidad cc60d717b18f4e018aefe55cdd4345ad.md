# Definición de Calidad

Assign: Cristian Rico
Propósito: Primera aproximación a la definición de esto, orientada a los módulos / historias de usuario del equipo
Proyecto: Deltalin
Revisión: Monica Ayala, Olivia Araceli Morales Quezada, Jorge Guerrero Díaz, Arisbeth Aguirre Pontaza, Ricardo Nuñez Alanis, Fabián Enrique Avilés Cortés
Status: Done

# Aclaraciones

- De momento, esto se trata de una idea a la cuál le ******************************************faltaría ser evaluada******************************************.
- A forma de propuesta, este proceso se llevará a cabo utilizando la ********************Escala de Severidad******************** de la IBM.

![86F1CA4B-66F6-496F-9D11-2225EE0CEBB5.jpeg](Definicio%CC%81n%20de%20Calidad%20cc60d717b18f4e018aefe55cdd4345ad/86F1CA4B-66F6-496F-9D11-2225EE0CEBB5.jpeg)

- Como no sé cuál sea la mejor propuesta, elaboraré estos ejemplos utilizando un módulo e historias de usuario de mi equipo.

# Definición de Calidad

A nivel del proyecto, esta definición debe de estar hecha para que cubra tanto la aplicación *******web******* como *****móvil*****.

## Móvil

- ****************Usable:**************** La interacción con la aplicación no debe de entorpecer en ningún momento el proceso de auditoría. Las vistas deben de ser claras para que en ningún momento los usuarios se pierdan al utilizarla
- **************************Deseable:************************** Una aplicación optimizada para iPad OS que no tenga problemas de rendimiento y que, cuya recepción y envío de datos sea lo más fluido posible.
- **********************Funcional:********************** La aplicación debe de guardar datos registrados de manera local durante el recorrido, una vez que este finalice, esta información se acomodará en un formato y se enviará a los correos indicados.

## Web

- ****************Usable:**************** Las vistas deben de ser claras para que en ningún momento los usuarios se pierdan al utilizarla, la carga de contenido debe de ser lo más fluida posible.
- **************************Deseable:************************** Una aplicación Web que cumpla con todas las funcionalidades que fueron consideradas durante la fase de desarrollo.
- **********************Funcional:********************** La aplicación carga todas las direcciones que incluyen funciones del MVP.

## Desarrollo de mi propuesta con un módulo

Utilizaré el Módulo 2, encargado de la Administración de Puntos de Venta desde la ****************************aplicación web****************************.

### IBM a nivel módulo

- **Severity 1:** Ninguna de las funciones del *************CRUD************* funciona.
- **Severity 2**
    - Una o varias de las funciones del *****CRUD***** no están activas.
    - La eliminación de un dato no se hace correctamente, ya sea una eliminación que ocurre desde la base de datos o un ***********soft delete***********.
    - Una consulta no arroja los resultados que le corresponden al usuario.
    - El registro de información no se hace de forma correcta, a pesar de indicar qué información se muestra en diferentes campos, al final estos no son guardados en la base de datos.
    - La edición no actualiza los datos.
- **Severity 3**
    - Algunos campos de información del *****CRUD***** no se llenan correctamente, por ejemplo, una fecha no se actualiza.
    - Otro ejemplo es que, en caso de querer mostrar una selección de fecha con un formato de calendario, este no se despliega e imposibilita el llenado de este campo.
- **Severity 4:** Algunas interfaces del ***********************************CRUD*********************************** no se despliegan correctamente (a nivel estético).

### IBM a nivel historia de usuario

**************************************************************M2_S1: Registrar Punto de Venta**************************************************************

- **********************Severity 1:********************** El Registro de un Punto de Venta no se puede completar.
- **********************Severity 2**********************
    - Varios campos no pueden llenarse.
    - La información no se registra en la Base de Datos, pero los campos para rellenar funcionan correctamente (Front).
    - La información no es enviada de forma correcta porque los nombres de los campos son diferentes en back y front.
- **********************Severity 3**********************
    - Algunos campos no se pueden llenar.
- **********************Severity 4:********************** Principalmente problemas estéticos, tales como:
    - El botón para enviar la información no es tan visible.
    - El acomodo de los campos puede ser mejorado.