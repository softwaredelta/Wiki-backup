# Diseño Prototipo en Figma para Página Web RAM

Assign: Jorge Guerrero Díaz
Propósito: Prototipo de página web en figma para solución de Grupo RAM
Proyecto: RAM
Status: Done
Tags: Fase: Diseño
Tipo de Producto: UI Design in Figma

---

[Manejo de Versiones](Disen%CC%83o%20Prototipo%20en%20Figma%20para%20Pa%CC%81gina%20Web%20RAM%204e93531d22af41efba39151f2f1c210a/Manejo%20de%20Versiones%209f89a6dcc8584a69be849c88d2044f35.md)