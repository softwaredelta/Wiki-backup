# Plan de comunicación RAM

Assign: Ana Karen López Baltazar, Jordana Betancourt Menchaca
Propósito: Plan de comunicación RAM
Proyecto: RAM
Revisión: Alejandro Mtz. Luna
Status: Done
Tags: Fase: Diseño
Tipo de Producto: Plan de Comunicación

# Plan de Comunicación

Aquí se encuentra el plan de comunicación para el equipo RAM. Este plan está dividido en dos partes. La primera se trata de un análisis de nuestra situación comunicativa (presentación) y el plan en sí, plasmado en un diagrama (draw.io).

A continuación se adjuntan los links a nuestro plan:

[Plan de Comunicación RAM.drawio](https://drive.google.com/file/d/1hO1xCf5xli4fwygMaycfHG-24eHw0X0x/view?usp=sharing)

[Plan de Comunicación RAM](https://docs.google.com/presentation/d/1OqPzQ0O0SpJZ5KT8EQDw1m-FEGllmjTM9_v-2NZbH1E/edit?usp=sharing)

---

[Manejo de Versiones](Plan%20de%20comunicacio%CC%81n%20RAM%20c09cba6011bc41f5800c55d4377fafd0/Manejo%20de%20Versiones%2093b83c8d75bc4c1cb72aff7a50b8c5df.md)