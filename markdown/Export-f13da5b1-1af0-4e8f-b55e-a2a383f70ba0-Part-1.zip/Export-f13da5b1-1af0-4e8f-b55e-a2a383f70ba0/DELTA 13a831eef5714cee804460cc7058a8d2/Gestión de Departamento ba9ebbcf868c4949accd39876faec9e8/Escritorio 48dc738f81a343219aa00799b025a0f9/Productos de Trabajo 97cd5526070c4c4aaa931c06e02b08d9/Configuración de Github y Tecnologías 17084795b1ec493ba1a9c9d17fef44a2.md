# Configuración de Github y Tecnologías

Assign: Jordana Betancourt Menchaca, Erick Alfredo García Huerta, Ian García González, Kenny Eduard Vercaemer González
Proyecto: RAM
Revisión: Ian García González, Kenny Eduard Vercaemer González
Status: In progress
Tags: Lectura
Tipo de Producto: Repositorio

## Configuración actual de repositorio de RAM

- Contribuciones a main solo a través de un Pull Request

### Estándares

Branches:

- Se crearán con un ISSUE.

PR (Pull Request):

- Titulo : En ingles, acción principal del PR
- Comment: Lista de los archivos que cambiaron, y que cambio en cada uno

**Ejemplo:**

![Untitled](Configuracio%CC%81n%20de%20Github%20y%20Tecnologi%CC%81as%2017084795b1ec493ba1a9c9d17fef44a2/Untitled.png)

Issues : 

- Id_issue
- Tags
- Titulo en inglés
- Changelog en lista

Ejemplo:

![Captura de Pantalla 2023-03-08 a la(s) 16.37.08.png](Configuracio%CC%81n%20de%20Github%20y%20Tecnologi%CC%81as%2017084795b1ec493ba1a9c9d17fef44a2/Captura_de_Pantalla_2023-03-08_a_la(s)_16.37.08.png)

Commits:

- Tag [BACKEND] [FRONTEND] [INFRA]
- Mantener descripciones y títulos cortos y precisos sobre el cambio que realizó.
- En Inglés

Ejemplo:

![Untitled](Configuracio%CC%81n%20de%20Github%20y%20Tecnologi%CC%81as%2017084795b1ec493ba1a9c9d17fef44a2/Untitled%201.png)

---

[Manejo de Versiones](Configuracio%CC%81n%20de%20Github%20y%20Tecnologi%CC%81as%2017084795b1ec493ba1a9c9d17fef44a2/Manejo%20de%20Versiones%20bcf07291c11d43c0a7aced3369bb013a.md)