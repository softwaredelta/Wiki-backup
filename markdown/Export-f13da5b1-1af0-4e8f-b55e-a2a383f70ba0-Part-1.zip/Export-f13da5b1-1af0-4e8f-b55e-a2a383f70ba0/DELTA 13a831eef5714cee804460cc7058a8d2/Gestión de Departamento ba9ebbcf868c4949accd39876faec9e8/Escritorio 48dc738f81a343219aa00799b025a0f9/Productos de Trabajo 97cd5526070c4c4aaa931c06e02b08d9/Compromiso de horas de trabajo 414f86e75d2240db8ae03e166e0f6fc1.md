# Compromiso de horas de trabajo

Assign: Alejandro Mtz. Luna, Rodrigo Muñoz Guerrero, José Ángel Rico Mendieta, Jordana Betancourt Menchaca, Kenny Eduard Vercaemer González, Erick Alfredo García Huerta, Ian García González, Reno, Fermín Méndez García, Diego Emilio Barrera Hernández, Ana Karen López Baltazar
Propósito: Documento con concientizar sobre las horas necesarias de trabajo
Proyecto: RAM
Revisión: Monica Ayala
Status: Done
Tags: Acuerdos
Tipo de Producto: Lectura
URL: https://docs.google.com/document/u/1/d/1Cm_L731Q-qedDNed79F-2EhqjF3Fbp7v/edit#heading=h.gjdgxs

### Favor de leer el siguiente documento

[https://docs.google.com/document/u/1/d/1Cm_L731Q-qedDNed79F-2EhqjF3Fbp7v/edit#heading=h.gjdgxs](https://docs.google.com/document/u/1/d/1Cm_L731Q-qedDNed79F-2EhqjF3Fbp7v/edit#heading=h.gjdgxs)

[Compromiso Horas de trabajo.docx](https://docs.google.com/document/u/1/d/1Cm_L731Q-qedDNed79F-2EhqjF3Fbp7v/edit#heading=h.gjdgxs)

---

[Manejo de Versiones ](Compromiso%20de%20horas%20de%20trabajo%20414f86e75d2240db8ae03e166e0f6fc1/Manejo%20de%20Versiones%20b8bf73a51d89451488c3be472f9b0921.md)