# Formato Plan de Adquisición

Assign: Monica Ayala, Olivia Araceli Morales Quezada, Cristian Rico
Propósito: Formato si se requiere adquirir assets económicos
Proyecto: Departamento
Status: Not started
Tags: Fase: Diseño, Formatos, Procesos

---

[Manejo de Versiones](Formato%20Plan%20de%20Adquisicio%CC%81n%200184a9b206bc4f53ae893dcbeb2cadfd/Manejo%20de%20Versiones%2000032a7d0d17424dbcdf9bd9855ce5c5.md)