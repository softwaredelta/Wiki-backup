# Minutas

[Formato minutas](Minutas%20e965603921e44ffda4d53ea85fd9db3a/Formato%20minutas%201916e5ca20bf47a1a38e19f81a0ec780.md)

[Minutas Departamentales](Minutas%20e965603921e44ffda4d53ea85fd9db3a/Minutas%20Departamentales%208d810c8e772248e3aed9f8e60ffad3e7.md)

[Minutas RAM](Minutas%20e965603921e44ffda4d53ea85fd9db3a/Minutas%20RAM%208eb0df1338be45df8384d3b065c15fd6.md)

[Minutas Michelin ](Minutas%20e965603921e44ffda4d53ea85fd9db3a/Minutas%20Michelin%2084758bfddb7f495a82cad69be253c9c5.md)