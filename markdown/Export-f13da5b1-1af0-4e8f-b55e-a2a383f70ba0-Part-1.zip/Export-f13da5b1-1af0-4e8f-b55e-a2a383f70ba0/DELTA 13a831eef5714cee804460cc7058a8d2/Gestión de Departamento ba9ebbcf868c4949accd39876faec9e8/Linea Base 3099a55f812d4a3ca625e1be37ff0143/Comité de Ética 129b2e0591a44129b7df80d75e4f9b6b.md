# Comité de Ética

# Objetivo

<aside>
💘 Propiciar un lugar de trabajo seguro, confiable y sereno en el departamento de Delta.

</aside>

[Happiness Door Resultados](Comite%CC%81%20de%20E%CC%81tica%20129b2e0591a44129b7df80d75e4f9b6b/Happiness%20Door%20Resultados%20ab76cac38d0e4aabb9d28b826e448bdf.md)

[Actividades de Integración](Comite%CC%81%20de%20E%CC%81tica%20129b2e0591a44129b7df80d75e4f9b6b/Actividades%20de%20Integracio%CC%81n%208502bfd7169a46a4916f7efad9dba6ab.md)

# Código de Ética

En este código de ética, los integrantes del departamento de tecnologías de la información Delta establecemos los lineamientos por los cuales regimos nuestro comportamiento y trabajo durante el semestre Febrero - Julio 2023. Este documento es una guía para desarrollarnos académica y profesionalmente.

## Valores

- **Respeto**
    - Escuchar de manera tolerante y digna a los integrantes del departamento, evitando prejuicios y procurando amabilidad entre todos <3.
- **Integridad**
    - Comprometernos a contribuir al bienestar humano, evitando perjudicar a los miembros del departamento y a sus interesados.
- **Honestidad**
    - Hablar y actuar con sinceridad, siempre respetando a todos los interesados e integrantes del departamento.
- **Compromiso**
    - Realizar las tareas de nuestra labor de ingeniería con calidad y hacerse cargo de las consecuencias de las decisiones tomadas.
- **Tolerancia**
    - Respeta las opiniones, ideas o actitudes de los miembros del departamento y guiar de manera responsable.
- **Transparencia**
    - Ser honesto en la comunicación con todos los interesados, así como con los demás miembros del departamento y no ocultar información por conveniencia personal.
- **Empatía**
    - Considerar los puntos de vista, sentimientos y circunstancias de los miembros del departamento y de sus interesados.

# Código de Conducta

## Ambiente de Trabajo

1. **Trato inclusivo**
    1. En Delta respetamos la dignidad de todas la personas independientemente de su género, orientación sexual, color de piel, etnia, condición socioeconómica, entre otras.
2. **Crítica constructiva**
    1. Cualquier crítica debe ser para el desarrollo, aprendizaje, mejora del trabajo y competencias de las personas a las cuales esta siendo dirigida.
    2. El personal que recibe la crítica debe de estar abierto a escuchar y considerar las sugerencias que fueron escritas para elle.
    3. El personal que ofrece la crítica debe de hacerlo con respeto y no de manera irrespetuosa.
3. **Participación activa**
    1. En las reuniones departamentales o de equipo, los integrantes de Delta deben presentar ideas que aporten al objetivo de la reunión y escuchar activamente a los demás.
4. **Reconocimiento del otro**
    1. La salud física y mental de las personas debe ser prioridad. Un miembro de Delta debe actuar si alguien no se encuentra bien.
    

## Responsabilidad Individual

1. **Puntualidad**
    1. Por respeto al tiempo de todas las personas involucradas, la puntualidad es esencial para la convivencia en Delta, tanto en entregas y trabajos como para juntas y reuniones.
2. **Trabajo Individual**
    1. El trabajo individual debe ser realizado siguiendo las guías y procesos definidos por el departamento y deberá ser entregado a tiempo y con calidad.

## Relación con los socios

1. **Trato profesional**
    1. La comunicación con los socios debe ser adecuada, no lenguaje ofensivo.
    2. Informamos de manera clara el plan de trabajo y estado del proyecto.
    3. Llegar a tiempo en las reuniones con socios formadores y respetar el tiempo que se agendó.
    4. La comunicación con los socios debe fomentar respeto, tolerancia, empatía y honestidad, con el fin de tener una relación de trabajo efectiva.

## Canales de comunicación

1. **Buzón (Forms)**
    1. Canal de escucha confidencial o anónimo.
    
    [FORMULARIO](https://forms.gle/1QLbs2UFMwQ5QDdRA)
    
    ![Untitled](Comite%CC%81%20de%20E%CC%81tica%20129b2e0591a44129b7df80d75e4f9b6b/Untitled.png)
    
2. **Post-its**
    1. Creemos que hay conductas pequeñas que se pueden mejorar y hablar con la persona sin interrumpir sus actividades. En este caso el comité comunicará sugerencias a través de un post-it para respetar el tiempo de trabajo de todos. Estos siempre tendrán la estructura : “Observo que”… “esto causa que” …”por lo que te sugerimos”.
    2. Creemos que hay conductas que merecen ser reconocidas. Como miembros de Delta podemos hacerle saber a otro compañero que está haciendo las cosas bien.
3. **One on One (TL)**
    1. Los Team Lead son un canal importante para nosotros. Por eso, para el comité de ética es importante que se hagan estos One on One. Ponte en contacto con tu TL 🙂
4. **En vivo**
    1. Siempre puedes tratar un asunto presencial con algún miembro del comité. Te puedes acercar a:
        1. Olivia
        2. Ricardo
        3. Renato
        4. Fabián
        5. Fermín
5. One on One (Comité)
    1. Si el comité detecta un estado de riesgo puede intervenir haciendo One on One con los involucrados. 

# Reglamento

1. ***[REGLAMENTO TECNOLOGICO DE MONTERREY](https://portalrep.itesm.mx/na/normatividad_academica/documentos/reglamento/general/reglamento_general_estudiantes_esp.pdf)***

# Proceso de Resolución de Conflictos

### **Proceso sugerido (El de Lalo)**

1. Reunirse con las partes en conflicto. Describir la situación y el sentimiento que genera.
2. Pedir una acción concreta que se desea de la otra parte.
3. Preguntar a cada una de las partes si desea una acción concreta.
4. Si no hay acuerdo, se puede repetir el proceso con el comité.

[Actividades](Comite%CC%81%20de%20E%CC%81tica%20129b2e0591a44129b7df80d75e4f9b6b/Actividades%20cc9f4f614a884bd6b44dfe4bba011e20.md)

## Historial de Cambios

[Manejo de versiones (3)](Comite%CC%81%20de%20E%CC%81tica%20129b2e0591a44129b7df80d75e4f9b6b/Manejo%20de%20versiones%20(3)%20b2be9b4d261d4c238c5d3f32abd66aa5.md)