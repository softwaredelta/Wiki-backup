# Bitácora del Departamento

Date: February 23, 2023

- Se reunió el equipo **Michelin** para definir sus módulos, priorizarlos, definir el alcance y MVP.
- Se creó el documento formato de **Validación de Propuesta**.
- Se comenzó la creación de la wiki en **Notion**, así como la migración de la fuente de verdad.
- Se reunió el equipo ******RAM******. Se definieron los módulos de trabajo que se presentarán a los clientes.
- Se agregan **repositorios** para soluciones de clientes a la base de datos de productos de trabajo.