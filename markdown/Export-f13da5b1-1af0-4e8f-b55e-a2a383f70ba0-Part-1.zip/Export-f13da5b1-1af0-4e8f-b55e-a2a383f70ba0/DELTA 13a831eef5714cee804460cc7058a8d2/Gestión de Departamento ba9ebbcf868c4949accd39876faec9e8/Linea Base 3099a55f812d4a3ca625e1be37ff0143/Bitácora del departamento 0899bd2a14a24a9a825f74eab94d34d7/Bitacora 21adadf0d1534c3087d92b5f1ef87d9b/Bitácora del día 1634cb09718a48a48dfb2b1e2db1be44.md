# Bitácora del día

Date: February 20, 2023

- Presentación de las líneas de vida de los miembros del departamento.
- Se realizó la primera reunión con los socio-formadores **Grupo Asesores RAM**. Con ellos se establecieron las reuniones recurrentes todos los viernes, así como una segunda reunión el martes y el viernes (de esta misma semana) para la validación de la **propuesta de Arquitectura, Alcance y MVP**.
- Clase con Carlos sobre características de calidad. Teoría sobre estándares, modelos, metodologías, etc.
- Clase con Claud, introducción a Requirements Engineering.
- Se establecieron nuevos canales en el servidor de discord para aumentar la comunicación.