# Bitácora del día

Date: February 17, 2023

- Se estableció un sistema inicial de procesos. Como procesos iniciales, se busca consolidar nuestra documentación - minutas y bitácora - y planeación - pendientes y actividades -. También se iniciará un proceso de retroalimentación basado en **Celebration Grid 's**, por medio del cual analizaremos los procesos y su efectividad.
- Se inicia la **bitácora**.
- Se inicia la **planeación**.
- Se establecieron los objetivos iniciales de reuniones con socios y definición de requerimientos.