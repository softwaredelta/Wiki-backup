# Bitácora del día

Date: March 6, 2023

- Deltram y Deltalín tuvieron una sesión de planeación.
- Deltram estimo la complejidad de sus HU.
- Se inició a planear la presentación final.
- Se crearon los PT provicionales del plan de trabajo, acta constitutiva, plan de comunicación.
- Se comenzó a trabajar el WBS.