# Bitácora del día

Date: March 7, 2023

- Se consolidó el comité de ética.
- Se tuvo una junta departamental para ver las metas que debemos cumplir para llegar a nuestro objetivo final.
- Se acordó que el viernes 10 de marzo ambos equipos presentarán una PPT en la que hablen de lo que llevan.
- Se comenzó a definir el formato de Acta Constitutiva.
- Se terminó el WBS de DELTRAM y del Departamento (sujeto a revisión).
- Lalo dio una clase de Plan de Valor Ganado usando el ejemplo de DELTRAM.
- Se definió que ahora las revisiones serán aleatorias.
- Se comenzó a definir un plan de comunicación.
- Deltalín se reunió para hablar con el socio.