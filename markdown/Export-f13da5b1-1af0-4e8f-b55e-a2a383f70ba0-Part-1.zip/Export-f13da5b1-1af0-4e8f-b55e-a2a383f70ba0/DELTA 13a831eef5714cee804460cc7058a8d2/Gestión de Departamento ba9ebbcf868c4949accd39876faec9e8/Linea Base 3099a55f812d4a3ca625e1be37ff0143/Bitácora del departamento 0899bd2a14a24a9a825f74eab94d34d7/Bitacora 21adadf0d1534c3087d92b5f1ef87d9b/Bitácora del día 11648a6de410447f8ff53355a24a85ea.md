# Bitácora del día

Date: February 21, 2023

- Segunda reunión con **Grupo Asesores RAM**. Discusión sobre procesos de inducción, campañas, bonos, ventas, etc.
- Primera reunión por Zoom con el representante de **Michelín**. Se aclararon requisitos del proyecto y se solicitaron diferentes recursos como estándares, formularios y ejemplos. Se agendaron reuniones recurrentes los martes a las 12:00 PM y una el viernes de esta misma semana para presentar la propuesta de proyecto.
- Los Product Owners y Team Leads de cada proyecto comenzaron a utilizar el excel de **Planeación y Entregables** para estimar sus tiempos y repartir su trabajo.
- Reunión de equipo RAM para definición inicial de propuestas de requerimientos.
- Clase introductoria al **CMMI**.
- Reunión de **Michelin,** se generaron el **Impact Mapping** y el **Gain/Pain Map** para integrar los módulos.