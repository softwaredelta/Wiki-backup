# Bitácora del día

Date: February 27, 2023

- El rol de **Olivia Morales** cambió a Program Manager para el primer periodo.
- Se reunió con el profesor Eduardo Juarez para discutir sobre la propuesta de **Michelin** para tener Proveedores.
- Se comenzó a definir la matriz de SCAMPI en notion para llevar acabo que productos de trabajo y procesos usamos para cada práctica específica de un área de proceso.
- El equipo de Grupo Asesores RAM acordó el miércoles de 10am-12pm para la reunión con el socioformador.