# Bitácora del día

Date: March 2, 2023

- Se tuvo una junta con el equipo CMMI en el que se definió la Matriz RACI a ser usada para saber quién [Matriz RACI CMMI](https://docs.google.com/spreadsheets/d/19yI-NPQQVjO3kzdbDmYF9dPO7SqSGOXRm3zGwtVRZL0/edit#gid=0).
- Se definió el Proceso para la definición de Experimentos.
- Se implementaron templates para Guías, Experimentos y Procesos.
- Se fusionaron los Acuerdos de Trabajo con las Políticas.
- Se creó un nuevo apartado fuera de Controlado y Escritorio.
    - Se migró el SCAMPI, Experimentos y la Matriz de Configuración
- Se pasaron las minutas a experimentos.
- Se comenzaron a definir experimentos.
- Se implementó el SPI y CPI en la planeación de Excel de ambos equipos.
- Formalmente se cambiaron los nombres de equipo Michelin → Deltalín y equipo RAM → Deltram.