# Bitácora del día

Date: February 18, 2023

- Se estableció la versión calendarizada en excel de la **planeación general**.
- Se definieron los objetivos, preguntas y recursos a preguntarle a los **socios formadores.**
- Se crearon los **repositorios** de proyectos en GitHub en el repositorio del departamento. Se creó la template de Issues.
- Se creó el documento de **experimentos**.
- Se añadió **control de cambios** al documento de **procesos**.