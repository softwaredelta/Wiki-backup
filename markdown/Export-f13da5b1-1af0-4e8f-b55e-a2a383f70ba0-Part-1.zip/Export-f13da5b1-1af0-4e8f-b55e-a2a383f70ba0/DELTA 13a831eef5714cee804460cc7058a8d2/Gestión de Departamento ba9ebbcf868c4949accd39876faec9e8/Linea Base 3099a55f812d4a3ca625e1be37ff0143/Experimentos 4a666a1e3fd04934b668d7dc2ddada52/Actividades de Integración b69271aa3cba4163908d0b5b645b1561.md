# Actividades de Integración

Estado: En progreso
Fecha evaluación: March 11, 2023
Fecha inicio: March 1, 2023
Grupo: Departamento
Hipótesis: Si generamos una lista de las actividades con mayor votación e implementamos estas, entonces la confianza entre el departamento Delta aumentará.
Responsable(s): Ricardo Nuñez Alanis
Tags: Convivencia, Integración
¿Se probó la hipótesis?: No

## Involucrados

1. Departamento Delta

## Descripción

1. Se pregunto miembro por miembro que nombraran dos actividades que les gustaría realizar para integrar al departamento.
2. Se creo un formulario con las actividades previamente establecidas con la intención de encontrar cual de estas podrían ser usadas para integración.
    1. Para esta versión se utilizo un google forms para un método de votación anonima.
        
        ![Inte.PNG](Actividades%20de%20Integracio%CC%81n%20b69271aa3cba4163908d0b5b645b1561/Inte.png)
        
3. Con estos resultados se tomo la decisión de solo tomar los resultados con un valor superior a 10, para que la mayoría del departamento este dispuesto a asistir.
    1. Se decidirá que a ser en la semana con una rueda de la fortuna.
    
    [Wheel of Names](https://wheelofnames.com/ccj-53p)
    

## **Criterios de éxito**

Lograr que el departamento asista a las actividades de integración y observar un aumento en confianza, honestidad y amistad entre el personal.

## **Resultado**

## Historial **de cambios**

[Manejo de versiones](Actividades%20de%20Integracio%CC%81n%20b69271aa3cba4163908d0b5b645b1561/Manejo%20de%20versiones%209423f1273e1a41378748668814ef4a68.md)