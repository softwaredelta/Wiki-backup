# Retroalimentación con Happiness Door

Estado: En progreso
Fecha evaluación: March 11, 2023
Fecha inicio: March 3, 2023
Grupo: Departamento
Hipótesis: Si se le da al departamento Delta una herramienta para expresar como se sienten, entonces podremos identificar los conflictos dentro del departamento.
Responsable(s): Ricardo Nuñez Alanis
Tags: Bienestar, Productividad
¿Se probó la hipótesis?: No

## Involucrados

1. Comité de Ética
2. Departamento Delta

## Descripción

1. A través de la plataforma MENTI se genero una presentación con las siguientes preguntas.
    1. Escribe cómo te has sentido estas últimas semanas dentro de DELTA.
    2. Esta parte es completamente anónima, algún comentario del departamento.
2. Al finalizar la presentación y conseguir los resultados otorgados por el departamento, el comité de ética se encargara de analizar los datos y encontrar soluciones para resolver conflictos encontrados en los datos.

## **Criterios de éxito**

Lograr que el departamento conteste con confianza y honestidad las preguntas realizadas en el Happiness Door, para así encontrar maneras de mejorar la manera de trabajo dentro del departamento. 

## **Resultado**

## Historial **de cambios**

[Manejo de versiones](Retroalimentacio%CC%81n%20con%20Happiness%20Door%2044cbbd2d6b954c75b1014e5345dac8f1/Manejo%20de%20versiones%20eeb1e3a3ab6c4194822b0fc52c8e4189.md)