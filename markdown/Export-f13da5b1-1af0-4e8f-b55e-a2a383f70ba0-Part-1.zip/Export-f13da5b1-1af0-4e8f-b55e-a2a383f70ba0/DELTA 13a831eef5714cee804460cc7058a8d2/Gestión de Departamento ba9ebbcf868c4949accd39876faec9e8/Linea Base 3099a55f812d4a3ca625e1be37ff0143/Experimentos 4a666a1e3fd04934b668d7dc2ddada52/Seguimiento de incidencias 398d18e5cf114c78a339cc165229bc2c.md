# Seguimiento de incidencias

Estado: Sin iniciar
Hipótesis: El registrar las incidencias que ocurren en el departamento nos ayudará a darle seguimiento a las acciones que se hicieron para corregirlas y 
¿Se probó la hipótesis?: No

## Involucrados

1. 

## Descripción

## **Criterios de éxito**

## **Resultado**

## Historial **de cambios**

[Manejo de versiones](Seguimiento%20de%20incidencias%20398d18e5cf114c78a339cc165229bc2c/Manejo%20de%20versiones%206c43b77204b9422aa8b2bc8e6fffda2d.md)