# 3

Acrónimos: RD, SG2
Completado: Yes
Prácticas: Establish and maintain product and product-component requirements, which are based on the customer requirements.