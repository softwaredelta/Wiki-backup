# 3

Acrónimos: OPD, SG1
Completado: No
Prácticas: Establish and maintain descriptions of the life-cycle models approved for use in the organization.