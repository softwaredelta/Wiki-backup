# Actividades

# Bitácora

Enlistamos las intervenciones que ha tenido el comité

| Fecha | Intervención |
| --- | --- |
| 08/03/23 | Firma de código de ética y conductual con los miembros del departamento. Se dan a conocer los canales de comunicación y comenzamos con la práctica de los Post-its |
|  |  |
|  |  |

-