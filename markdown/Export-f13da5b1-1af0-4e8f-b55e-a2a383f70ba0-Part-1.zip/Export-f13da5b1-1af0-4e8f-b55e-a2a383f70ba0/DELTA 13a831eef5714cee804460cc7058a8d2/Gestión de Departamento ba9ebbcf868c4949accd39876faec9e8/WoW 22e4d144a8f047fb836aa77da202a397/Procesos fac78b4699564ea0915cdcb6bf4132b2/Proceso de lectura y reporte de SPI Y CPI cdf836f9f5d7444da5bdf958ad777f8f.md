# Proceso de lectura y reporte de SPI Y CPI

Número: 8

## ********************************************Objetivo:********************************************

## ****************************************Entradas de proceso:****************************************

## **********************************Pasos de proceso:**********************************

[Etapas de proceso (2)](Proceso%20de%20lectura%20y%20reporte%20de%20SPI%20Y%20CPI%20cdf836f9f5d7444da5bdf958ad777f8f/Etapas%20de%20proceso%20(2)%202640f85c08e24b60911b667e8e3af875.md)

## **************************************Salidas de proceso:**************************************

## Monitorización o Métricas**************************************:**************************************

## ********************************************Notas y sugerencias para el futuro:********************************************

## ********Historial de cambios:********

[Manejo de versiones (1)](Proceso%20de%20lectura%20y%20reporte%20de%20SPI%20Y%20CPI%20cdf836f9f5d7444da5bdf958ad777f8f/Manejo%20de%20versiones%20(1)%208e6ee8e1aed14c54bdd1d1654a19e3dd.md)