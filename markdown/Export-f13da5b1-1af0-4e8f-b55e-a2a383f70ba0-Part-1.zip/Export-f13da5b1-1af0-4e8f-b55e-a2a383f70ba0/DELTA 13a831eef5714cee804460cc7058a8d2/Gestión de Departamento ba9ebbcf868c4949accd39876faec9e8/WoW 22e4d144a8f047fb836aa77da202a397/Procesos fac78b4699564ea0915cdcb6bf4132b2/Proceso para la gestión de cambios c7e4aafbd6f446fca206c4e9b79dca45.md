# Proceso para la gestión de cambios

Número: 10

## ********************************************Objetivo:********************************************

## ****************************************Entradas de proceso:****************************************

## **********************************Pasos de proceso:**********************************

[Etapas de proceso (2)](Proceso%20para%20la%20gestio%CC%81n%20de%20cambios%20c7e4aafbd6f446fca206c4e9b79dca45/Etapas%20de%20proceso%20(2)%20fa931b8227ef41eba20b52dcb43855f4.md)

## **************************************Salidas de proceso:**************************************

## Monitorización o Métricas**************************************:**************************************

## ********************************************Notas y sugerencias para el futuro:********************************************

## ********Historial de cambios:********

[Manejo de versiones (1)](Proceso%20para%20la%20gestio%CC%81n%20de%20cambios%20c7e4aafbd6f446fca206c4e9b79dca45/Manejo%20de%20versiones%20(1)%201620ff293a0642e495569e8f03cf7a1e.md)