# Proceso para la definición de experimentos

Número: 1
Propósito: Tener una forma organizada de seleccionar aquellas practicas que generen resultados en nuestra forma de trabajo como departamento.
Tags: Documentación, Experimentos

## ********************************************Objetivo:********************************************

Tener una forma organizada de seleccionar aquellas practicas que generen resultados en nuestra forma de trabajo como departamento.

## ****************************************Entradas de proceso:****************************************

1. Necesidad previamente identificada de generar un acuerdo de trabajo.

## **********************************Pasos de proceso:**********************************

[Etapas de proceso](Proceso%20para%20la%20definicio%CC%81n%20de%20experimentos%20fb0474ad3b6a46ee88c7f13b2c6fed03/Etapas%20de%20proceso%204e34d24b60d14288aa31f081b319f1d0.md)

## **************************************Salidas de proceso:**************************************

1. Una nueva practica aceptada .
2. Actualización de la Matriz de configuración.

## Monitorización o Métricas**************************************:**************************************

Dependiendo de la hipótesis.

## ********************************************Notas y sugerencias para el futuro:********************************************

1. 

## ********Historial de cambios:********

[Manejo de versiones ](Proceso%20para%20la%20definicio%CC%81n%20de%20experimentos%20fb0474ad3b6a46ee88c7f13b2c6fed03/Manejo%20de%20versiones%20f1abe343910c419e987fe900ddf29763.md)