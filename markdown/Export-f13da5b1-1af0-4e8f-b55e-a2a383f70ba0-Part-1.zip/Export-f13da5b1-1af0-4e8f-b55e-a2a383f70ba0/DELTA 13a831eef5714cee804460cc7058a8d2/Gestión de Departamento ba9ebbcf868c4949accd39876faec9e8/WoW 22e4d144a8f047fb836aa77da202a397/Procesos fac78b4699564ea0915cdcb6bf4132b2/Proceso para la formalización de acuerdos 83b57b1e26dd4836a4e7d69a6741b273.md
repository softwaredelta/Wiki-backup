# Proceso para la formalización de acuerdos

Número: 2
Tags: Documentación, WIP

## ********************************************Objetivo:********************************************

## ****************************************Entradas de proceso:****************************************

## **********************************Pasos de proceso:**********************************

[Etapas de proceso (2)](Proceso%20para%20la%20formalizacio%CC%81n%20de%20acuerdos%2083b57b1e26dd4836a4e7d69a6741b273/Etapas%20de%20proceso%20(2)%201a83b2ecd2da444cb08169ea9c48210e.md)

## **************************************Salidas de proceso:**************************************

## Monitorización o Métricas**************************************:**************************************

## ********************************************Notas y sugerencias para el futuro:********************************************

## ********Historial de cambios:********

[Manejo de versiones (1)](Proceso%20para%20la%20formalizacio%CC%81n%20de%20acuerdos%2083b57b1e26dd4836a4e7d69a6741b273/Manejo%20de%20versiones%20(1)%20f163ba0fa8be4d389f0a132f2fa6fce6.md)