# Documentación

Actividades: Modificar o agregar la información de la HU en su lugar correspondiente. Seguir la guía   https://www.notion.so/638cc52e59414835b4bfce35adfa651c y la guía [link a definición de una HU y como diseñar/ejecutar pruebas] para mayor información.