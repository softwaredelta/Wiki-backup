# Revisión

Actividades: Leer la información de la HU, verificar que todo esté en orden y ortográficamente correcto.