# Monitorización

Actividades: Constantemente verificar que a medida que se actualiza el progreso de una HU, también se documente de manera consistente.