# Proceso para la creación de métricas SPI y CPI, en el calendario

Guias: ../Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Como%20LLENAR%20y%20LEER%20las%20tablas%20y%20las%20graficas%20para%20%20796befd2de26494f8e51c3aa1b7588da.md 
../Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358.md 
Número: 7
Propósito: Medir el costo, tiempo y alcance de los tres proyectos de forma sencilla y así tomar decisiones tanto en los equipos de trabajo, como en el departamento.
Tags: CPI, Monitorización, SPI

## ********************************************Objetivo:********************************************

Medir el costo, tiempo y alcance de los tres proyectos de forma sencilla y así tomar decisiones tanto en los equipos de trabajo, como en el departamento.

## ****************************************Entradas de proceso:****************************************

1. Task y objetivos del proyecto
2. Personas asignadas
3. Tiempos estimados
4. AP`s estimados
5. Fechas estimadas

## **********************************Pasos de proceso:l**********************************

[Etapas de proceso (2)](Proceso%20para%20la%20creacio%CC%81n%20de%20me%CC%81tricas%20SPI%20y%20CPI,%20%20767c833726a640c8a8a4421b347599c3/Etapas%20de%20proceso%20(2)%20150bf2b724ea44469100f9413d31ee19.md)

## **************************************Salidas de proceso:**************************************

Una planeación semanal siguiendo el formato de Google Sheets [Calendario - Planeación General](https://docs.google.com/spreadsheets/d/1HZrmGn_cKk6wFRo-s0_ZsMpfMxow5rXOvBgHTPeQA0U/edit#gid=27041093)

## Monitorización o Métricas**************************************:**************************************

1. [métricas de SPI y CMI](https://docs.google.com/spreadsheets/d/1HZrmGn_cKk6wFRo-s0_ZsMpfMxow5rXOvBgHTPeQA0U/edit#gid=111647789) para ver el progreso de la planeación. Guía correspondiente: [Cómo HACER las tablas y las graficas para el cálculo del SPI y CPI](../Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358.md) y [Como LLENAR y LEER las tablas y las graficas para el cálculo del SPI y CPI](../Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Como%20LLENAR%20y%20LEER%20las%20tablas%20y%20las%20graficas%20para%20%20796befd2de26494f8e51c3aa1b7588da.md) 

## ********************************************Notas y sugerencias para el futuro:********************************************

1. Dependiendo los resultados de nuestras métricas, se deberá de ajustar las estimaciones. Guía correspondiente: [Cómo ajustar las estimaciones del calendario](../Gui%CC%81as%20668cce30f3ef485aba72c8a43d40849d/Co%CC%81mo%20ajustar%20las%20estimaciones%20del%20calendario%20ec42623b533e49a281c7272e7bc4d048.md) 

## ********Historial de cambios:********

[Manejo de versiones (1)](Proceso%20para%20la%20creacio%CC%81n%20de%20me%CC%81tricas%20SPI%20y%20CPI,%20%20767c833726a640c8a8a4421b347599c3/Manejo%20de%20versiones%20(1)%206dd06a45a53945bfa7efd5ff4932bf31.md)

PP 1.2