# Evaluación constante

Actividades: Segun los Agile Points y las previas estimaciones, definir el costo de tiempo (horas) que tendrá la task.
CMMI: MA, PP
Subpractica: PP 1.2