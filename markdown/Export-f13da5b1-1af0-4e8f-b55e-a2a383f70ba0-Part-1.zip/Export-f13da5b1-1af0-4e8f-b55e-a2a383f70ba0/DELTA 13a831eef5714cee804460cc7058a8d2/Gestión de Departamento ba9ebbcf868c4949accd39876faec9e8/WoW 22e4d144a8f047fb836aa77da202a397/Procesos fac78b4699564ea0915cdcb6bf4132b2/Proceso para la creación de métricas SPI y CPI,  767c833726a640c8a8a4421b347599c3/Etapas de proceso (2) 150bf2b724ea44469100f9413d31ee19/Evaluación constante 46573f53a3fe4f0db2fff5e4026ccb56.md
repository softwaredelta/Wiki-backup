# Evaluación constante

Actividades: A partir de las personas asignadas, definir la cantidad  de Agile Points de la task en forma de serie Fibonacci.
Esta definición deberá basarse en las siguientes preguntas:
1. ¿Qué tanto esfuerzo necesitamos?
2. ¿Qué tanto tiempo necesitamos?
3. ¿Qué tan complejo será?
4. ¿Qué tanto riesgo tendrá?
CMMI: MA, PP
Subpractica: PP 1.2