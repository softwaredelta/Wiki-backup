# Evaluación constante

Actividades: Dependiendo los Agile Points y el costo definir una fecha objetivo para la finalización de la task.
CMMI: MA, PP
Subpractica: PP 1.2