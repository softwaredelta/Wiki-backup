# Evaluación constante

Actividades: Definir los asignados necesarios por cada task.
CMMI: MA, PP
Subpractica: PP 1.2