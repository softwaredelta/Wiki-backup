# Evaluación constante

Actividades: Especificar el progreso que se lleva de la task, puede ser: Upcoming, Progress, Review ó Complete.
CMMI: MA, PP
Subpractica: PP 1.2