# Validación

Actividades: Consultar con los Team Leads, POs e incluso otros miembros. Esto para saber si la carga de trabajo es muy poca o demasiada, si agregarían o eliminarían algún elemento.