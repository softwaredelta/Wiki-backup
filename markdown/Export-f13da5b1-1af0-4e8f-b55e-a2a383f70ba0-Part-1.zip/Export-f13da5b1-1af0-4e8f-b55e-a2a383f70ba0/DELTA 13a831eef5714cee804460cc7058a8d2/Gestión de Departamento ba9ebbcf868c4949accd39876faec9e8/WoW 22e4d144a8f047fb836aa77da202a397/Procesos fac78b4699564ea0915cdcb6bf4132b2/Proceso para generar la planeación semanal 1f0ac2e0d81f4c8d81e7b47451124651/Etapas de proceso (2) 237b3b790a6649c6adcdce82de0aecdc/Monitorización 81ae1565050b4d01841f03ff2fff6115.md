# Monitorización

Actividades: A lo largo de la semana revisar que la planeación sea adecuada comparandola al objetivo que se quiere llevar. Pasado el tiempo, ver si se cumplió el objetivo y que áreas de oportunidad hubieron en la planeación.