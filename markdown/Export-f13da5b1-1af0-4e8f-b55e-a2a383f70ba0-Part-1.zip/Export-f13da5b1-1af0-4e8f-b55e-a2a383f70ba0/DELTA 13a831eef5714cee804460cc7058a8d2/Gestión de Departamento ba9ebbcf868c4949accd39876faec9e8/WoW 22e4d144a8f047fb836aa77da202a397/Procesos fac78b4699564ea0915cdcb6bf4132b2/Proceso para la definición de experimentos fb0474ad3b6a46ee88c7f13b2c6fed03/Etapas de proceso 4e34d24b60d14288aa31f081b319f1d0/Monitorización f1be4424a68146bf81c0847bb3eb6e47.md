# Monitorización

Actividades: Después de notificar a todos los miembros del departamento del nuevo elemento y que este sea institucionalizado, se debe de monitorear el cumplimiento de la practica. Se pueden usar métricas de ser aplicable.
CMMI: PMC