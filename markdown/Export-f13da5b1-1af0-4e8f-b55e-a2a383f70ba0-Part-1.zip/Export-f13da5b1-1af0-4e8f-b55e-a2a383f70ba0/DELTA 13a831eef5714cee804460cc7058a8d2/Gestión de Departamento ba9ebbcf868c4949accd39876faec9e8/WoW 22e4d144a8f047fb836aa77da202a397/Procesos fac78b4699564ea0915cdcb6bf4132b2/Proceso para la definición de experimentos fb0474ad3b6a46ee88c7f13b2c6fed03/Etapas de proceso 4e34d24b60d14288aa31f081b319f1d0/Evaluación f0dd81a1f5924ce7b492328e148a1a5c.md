# Evaluación

Actividades: [Reunión o ceremonia] Se analizan los resultados y sensaciones obtenidos para determinar si se descarta o se institucionaliza el experimento.