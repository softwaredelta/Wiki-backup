# Cómo HACER las tablas y las graficas para el cálculo del SPI y CPI

Autor: Diego Emilio Barrera Hernández
Date: March 1, 2023
ID: 1
Tags: CPI, Monitorización, SPI

### Documentos relacionados.

| Guía para LEER las tablas y las graficas para el cálculo del SPI y CPI | Como%20LLENAR%20y%20LEER%20las%20tablas%20y%20las%20graficas%20para%20%20796befd2de26494f8e51c3aa1b7588da.md  |
| --- | --- |
| Proceso de las graficas | TO DO |
| Proceso de las gestión de métricas | TO DO |

# Editando las tablas de calendario

1. Primero tenemos que agregar las columnas que nos ayudaran a hacer las gráficas y dichos cálculos para el SPI y CPI
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled.png)
    

1. Una vez que agregamos dichas columnas haremos las configuraciones necesarias para que estas no edite de manera negativa los cálculos que anteriormente ya se hicieron.
    1. Un ejemplo podrías ser la barra de trabajo que se tiene por cada semana.
        
        ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%201.png)
        
    2. Otro ejemplo son los aspectos condicionales de cada celda. En la siguiente imagen podemos ver que la columna de “real time” tiene varios colores
        
        ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%202.png)
        
        Esto se debe porque previamente se establecieron condiciones.
        
        ## Editando formato condicional
        
        Para poder editar estas configuraciones primero debes posicionarte en alguna celda donde se encuentre este formato y después hacer lo siguiente
        
        ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%203.png)
        
        Se deberá ver de la siguiente manera:
        
        ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%204.png)
        
        Una vez aquí ya podremos crear algún aspecto condicional o editar los que ya existen.
        
        *NOTA: Para ver si una celda tiene o no tiene formato condicional se deberá ver de la siguiente manera:*
        
        ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%205.png)
        
        *Aquí vemos como se seleccionó una celda donde no existe dicho formato condicional y en nuestra ventana de “Reglas de formato condicional” observamos que no hay ninguno.*
        

1. Comúnmente las columnas de las fechas no tienen un formato establecido tipo “Fecha”, por lo tanto, debemos de hacerlo. Seleccionamos la columna que queremos que tenga este formato y hacemos lo siguiente:
    
    *NOTA: No se preocupen si en esta tabla no ven el “Real AP`s”, se me fue ponerlo aquí, pero ustedes **SI** deberían tenerlo.*
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%206.png)
    
2. Después arreglaremos las fechas, ya que el equipo DELTA esta acostumbrado a escribir las fechas de la siguiente manera.
    
    ### mes/día/año
    
    Y nosotros la necesitamos de la siguiente manera, para que las graficas tomen ese dato como fecha y no como un dato cualquiera.
    
    ### día/mes/año
    
3. Ahora llenaremos las columnas “Estimated Value” y “Real value”.
    1. En el caso “Estimated Value” únicamente llenaremos esa columna con 1`s
    2. En el caso de “Real value” pondremos una condición que diga “Si la tarea ya está completada entonces que se escriba 1, de lo contrario que se escriba 0”
        
        *NOTA: No se preocupen si en esta tabla no ven el “Real AP`s”, se me fue ponerlo aquí, pero ustedes **SI** deberían tenerlo.*
        
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%207.png)
    

# Tablas dinámicas

1. Para hacer las graficas necesitaremos crear tablas dinámicas.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%208.png)
    

1. Nos pedirá seleccionar los intervalos de datos. Aquí seleccionaremos nuestra tabla, desde los títulos de las columnas hasta el último dato que tengamos.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%209.png)
    

1. Por último le picaremos a insertar a nueva hoja para que no nos estorben nuestras tablas dinámicas.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2010.png)
    

1. En nuestra hoja nueva seleccionaremos las filas y los valores en el “Editor de tablas dinámicas”.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2011.png)
    
    1. Aquí nos deberá quedar este apartado de la siguiente manera
        
        ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2012.png)
        
    2. Ahora haremos una columna (Aps acumulados) que ayudará a realizar las gráficas.
        1. El primer valor valdrá lo mismo que el valor de la izquierda
        2. Del segundo en adelante tendrá el valor de [celda arriba + celda izquierda]
            
            ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2013.png)
            
            *N0TA: LA CANTIDAD DE CELDAS QUE ARRASTRARAS PARA CALCULAR ESTA COLUMNA DEPENDERA DE LA CANTIDAD DE FECHAS QUE SE PONGAN. En este caso baje hasta la fila 11 porque sé que no habrá tantas fechas, pues yo estaré manejando estas graficas por semanal y el rango de extension de tiempo puede ser mínimo.*
            
2. Repetiremos este proceso 3 veces más, con la parte de “Real AP`s”, “Duration(hrs)” y “Real time”. Recomiendo que estas tablas las dejemos en una misma hoja; para eso seleccionaremos la siguiente opción al momento de configurar la tabla dinámica.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2014.png)
    
    Finalmente, estas serían las tablas que tendríamos.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2015.png)
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2016.png)
    

# Graficas

1. Para hacer las graficas tendremos que seleccionar lo siguiente.

![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2017.png)

1. Se mostrara una ventana y aquí seleccionaremos los intervalos.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2018.png)
    
    1. Serían 3 intervalos, “APs acumulados”, “Real APs acum” y “End”. De cada uno de los intervalos se seleccionarán un mínimo de 10 celdas; esto por si los datos estimados llegan a extenderse más en fechas.
        
        ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2019.png)
        
        ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2020.png)
        
        ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2021.png)
        

1. Ahora copiaremos la siguiente configuración de la gráfica.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2022.png)
    
2. Lo siguiente será personalizar nuestra grafica. Deberán tomar en cuenta las siguientes personalizaciones.

1. Primero le pondremos un título a nuestra grafica
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2023.png)
    
2. Después estableceremos un diseño (en la sección de “Serie”) de la gráfica para poder entender nuestros datos más fácilmente.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2024.png)
    
3. Por último editaremos el “El eje vertical” de la siguiente manera.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2025.png)
    
1. Para finalizar, haremos la segunda gráfica. Replicaremos los pasos desde el **paso 1,** pero ahora seleccionaremos los siguientes 3 intervalos, “Horas estimadas”, “Horas reales” y “End”. Es necesario recordar que se deben seleccionar un mínimo de 10 celdas por si crecen las fechas de entrega.
    
    Quedaría de la siguiente manera.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2026.png)
    
                                                   **¡¡FELICIDADES, YA TIENEN SUS GRAFICAS!!**
    
                                                             **Ahora toca hacer el SPI y CPI**
    

# SPI y CPI

1. Para empezar debemos de copiar esta plantilla a lado de nuestra tabla.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2027.png)
    
2. Necesitaremos establecer los totales en las columnas “Real APs”, “Estimated value” y “Real value”.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2028.png)
    
3. Finalmente, tendremos que llenar la tabla de la siguiente manera.
    
    ![Untitled](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Untitled%2029.png)
    
                                                **¡¡FELICIDADES YA TIENES LOS CALCULOS SPI Y CPI!!**
    

[Manejo de versiones](Co%CC%81mo%20HACER%20las%20tablas%20y%20las%20graficas%20para%20el%20ca%CC%81l%20d14a21a34f6749d292e3e3d6cc78e358/Manejo%20de%20versiones%20699d77d740a243229f7f52490273efe2.md)