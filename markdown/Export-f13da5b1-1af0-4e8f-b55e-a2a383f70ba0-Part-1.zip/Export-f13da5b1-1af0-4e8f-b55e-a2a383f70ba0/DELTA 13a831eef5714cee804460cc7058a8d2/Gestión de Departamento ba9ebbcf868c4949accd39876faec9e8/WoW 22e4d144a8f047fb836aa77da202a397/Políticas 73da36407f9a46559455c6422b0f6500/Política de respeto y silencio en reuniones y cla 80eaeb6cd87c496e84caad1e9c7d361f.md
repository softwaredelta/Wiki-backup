# Política de respeto y silencio en reuniones y clases

Descripción: Como miembro del departamento no debo de interrumpir o interferir mientras alguien tenga la palabra en una reunión o mientras los profesores esten impartiendo clase. No prohiben conversaciones cortas, sin embargo es necesario ser prudente al tenerlas.
Número: 4
Tipo: Convivencia