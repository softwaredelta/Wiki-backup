# Política de acuerdo con procesos y objetivos del departamento

Descripción: Como miembro del departamento, existe un compromiso con los objetivos.

Toda actividad, acción, propuesta, diálogo, interacción con los sistemas del departamento y otros miembros, deberá regirse por las políticas y procesos del departamento.
Número: 1
Tipo: Convivencia