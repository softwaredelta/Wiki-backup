# Política de responsabilidad con el proyecto

Descripción: Como miembro del equipo, en caso de que mis actividades dejan de aportar al proyecto, tengo la responsabilidad de buscar nuevas actividades de valor y comunicarme con mi equipo.
Número: 13
Tipo: Responsabilidad