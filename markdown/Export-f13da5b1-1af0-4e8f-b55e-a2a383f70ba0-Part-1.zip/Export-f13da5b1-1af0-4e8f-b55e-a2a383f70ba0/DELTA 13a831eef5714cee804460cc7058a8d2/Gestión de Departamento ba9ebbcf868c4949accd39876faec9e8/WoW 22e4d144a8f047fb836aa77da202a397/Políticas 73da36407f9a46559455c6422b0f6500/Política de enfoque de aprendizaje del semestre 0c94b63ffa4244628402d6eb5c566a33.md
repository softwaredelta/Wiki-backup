# Política de enfoque de aprendizaje del semestre.

Descripción: Como miembro del departamento reconozco el hecho de que nos encontramos en una experiencia de aprendizaje, por lo que se espera comprensión y acompañamiento los unos de los otros, así como respeto por nuestras iniciativas e intereses a lo largo del semestre.
Número: 9
Tipo: Valores