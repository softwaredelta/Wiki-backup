# Política de reuniones de integración

Descripción: Como miembro del departamento existe el compromiso a tener al menos una reunión de integración al mes. Es decir, un día de jugar juegos, comer pizza, salir a una plaza, ir a una fiesta, etcétera.
Número: 6
Tipo: Convivencia