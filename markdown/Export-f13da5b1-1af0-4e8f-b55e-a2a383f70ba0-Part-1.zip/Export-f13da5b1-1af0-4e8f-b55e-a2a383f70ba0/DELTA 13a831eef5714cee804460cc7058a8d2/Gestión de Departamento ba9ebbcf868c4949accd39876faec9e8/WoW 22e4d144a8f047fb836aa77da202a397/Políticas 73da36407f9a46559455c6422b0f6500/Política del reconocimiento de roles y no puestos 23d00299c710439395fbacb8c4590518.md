# Política del reconocimiento de roles y no puestos.

Descripción: Como miembro del departamento, reconozco los roles de los distintos miembros de los equipos y que cada miembro de Delta tiene distinta responsabilidad. Sin embargo, estos son cambiantes a lo largo del semestre y no implican una jerarquía, todos somos pares. 
Número: 12
Tipo: Convivencia