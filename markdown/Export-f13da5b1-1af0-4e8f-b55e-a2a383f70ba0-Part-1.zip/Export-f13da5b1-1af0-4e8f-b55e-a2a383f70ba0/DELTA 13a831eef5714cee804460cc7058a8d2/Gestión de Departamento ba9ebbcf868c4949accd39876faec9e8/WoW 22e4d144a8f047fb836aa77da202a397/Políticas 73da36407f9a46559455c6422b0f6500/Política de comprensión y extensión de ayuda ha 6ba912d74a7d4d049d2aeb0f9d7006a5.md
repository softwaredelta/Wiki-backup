# Política de comprensión y extensión de ayuda hacia los miembros de Delta.

Descripción: Como miembro de equipo, reconozco que de contar con conocimientos sobre las distintas tecnologías, debo compartirlos con mis compañeros con amabilidad, comprensión y respeto.
Número: 10
Tipo: Responsabilidad