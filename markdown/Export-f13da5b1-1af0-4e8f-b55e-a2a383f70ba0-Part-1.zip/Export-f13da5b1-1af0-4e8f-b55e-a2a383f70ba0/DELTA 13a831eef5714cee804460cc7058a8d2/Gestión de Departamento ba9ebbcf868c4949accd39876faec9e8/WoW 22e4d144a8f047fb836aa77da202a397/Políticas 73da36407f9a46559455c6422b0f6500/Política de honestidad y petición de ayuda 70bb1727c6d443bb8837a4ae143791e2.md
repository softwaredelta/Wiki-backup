# Política de honestidad y petición de ayuda

Descripción: Como miembro de equipo reconozco que en caso de necesitar apoyo con mis actividades, se espera que las comunique adecuadamente ya sea con profesores, miembros de la comunidad de apoyo o colegas.
Número: 11
Tipo: Responsabilidad