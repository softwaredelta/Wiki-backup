# Política de reuniones departamentales

Descripción: Como miembro de equipo se espera que asistas semanalmente a las reuniones departamentales planeadas. El acuerdo departamental es que mínimamente se realizará una por semana el viernes, esto con la finalidad de hacer la retrospectiva semanal.
Número: 8
Tipo: Plan departamental