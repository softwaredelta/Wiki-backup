# Política de apego con los códigos de ética y conducta.

Descripción: Como miembro del departamento, me comprometo a actuar en acorde con el Código de Ética y Código de Conducta. En caso de observar una interacción dónde los valores de la organización sean incumplidos, dirigirse con el Comité de Ética.
Número: 14
Tipo: Valores