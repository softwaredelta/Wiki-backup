# Knowledge Base sobre los Roles

Created by: Monica Ayala
Last edited by: Ana Karen López Baltazar
Tags: Todo

# Sobre el rol de Program Manager

@Olivia Araceli Morales Quezada @Monica Ayala 

# Sobre el rol de Architecture Owner

@Ian García González @Emiliano Vásquez Olea 

# Sobre el rol de Team Leader

@Jordana Betancourt Menchaca @Jorge Guerrero Díaz 

# Sobre el rol de Product Owner

@Rodrigo Muñoz Guerrero @Arisbeth Aguirre Pontaza