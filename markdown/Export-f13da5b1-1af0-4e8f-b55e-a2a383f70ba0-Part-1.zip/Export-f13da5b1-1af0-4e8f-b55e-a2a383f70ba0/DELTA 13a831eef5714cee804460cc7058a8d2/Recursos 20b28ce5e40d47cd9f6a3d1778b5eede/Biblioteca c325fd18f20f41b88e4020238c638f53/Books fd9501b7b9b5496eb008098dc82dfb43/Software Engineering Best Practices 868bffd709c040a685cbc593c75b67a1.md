# Software Engineering Best Practices

Files & media: Software_Engineering_Best_Practices.pdf
Tags: Procesos, Project Management, Proyectos