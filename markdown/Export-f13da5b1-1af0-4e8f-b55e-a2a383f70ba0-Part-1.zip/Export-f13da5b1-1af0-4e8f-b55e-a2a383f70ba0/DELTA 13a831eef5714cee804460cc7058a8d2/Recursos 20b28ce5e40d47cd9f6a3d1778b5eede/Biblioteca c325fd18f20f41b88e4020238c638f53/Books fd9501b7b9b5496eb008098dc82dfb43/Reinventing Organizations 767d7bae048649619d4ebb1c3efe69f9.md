# Reinventing Organizations

Files & media: Reinventing_Organizations.pdf
Idioma: English
Tags: Organizaciones